#include <stdio.h>
#include <stdlib.h>
#include "Produto.h"
#include "ABinaria.h"
/*
Aula T11: 15/05/2025

*/

int main()
{
    printf("Arvores Binarias - Versao 1!\n");
    ABinaria *ARV;
    ARV = CriarABinaria();
    AddABinaria(ARV, CriarProduto(20, "Arroz"));
    AddABinaria(ARV, CriarProduto(10, "Massa"));
    AddABinaria(ARV, CriarProduto(40, "Maca"));
    AddABinaria(ARV, CriarProduto(50, "Pera"));

    ShowABinaria(ARV);
    int ALT = AlturaABinaria(ARV);
    printf("Altura AB = %d\n", ALT);
    int NFOLHAS = ContarFolhas(ARV);
    printf("ContarFolhas = %d\n", NFOLHAS);
    int EQUI = Equilibrada(ARV);
    printf("Equilibrada = %d\n", EQUI);

    DestruirABinaria(ARV);
    return 0;
}
