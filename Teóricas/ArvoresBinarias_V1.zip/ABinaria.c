
#include "ABinaria.h"

ABinaria *CriarABinaria()
{
    ABinaria *Arv = (ABinaria *)malloc(sizeof(ABinaria));
    Arv->Inicio = NULL;
    Arv->NEL = 0;
    return Arv;
}
NOBinario *AddNosAB(NOBinario *P, Produto *X, int *ins)
{
    if (!P)
    {
        NOBinario *Novo = (NOBinario *)malloc(sizeof(NOBinario));
        Novo->DIR = Novo->ESQ = NULL;
        Novo->Info = X;
        *ins = 1;
        return Novo;
    }
    if (X->ID > P->Info->ID)
        P->DIR = AddNosAB(P->DIR, X, ins);
    else
        if (X->ID < P->Info->ID)
            P->ESQ = AddNosAB(P->ESQ, X, ins);
    return P;
}

void AddABinaria(ABinaria *A, Produto *X)
{
    if (A)
    {
        int ins = 0;
        A->Inicio = AddNosAB(A->Inicio, X, &ins);
        if (ins == 1) A->NEL++;
    }
}

void MostrarNosAB(NOBinario *P)
{
    if (!P) return;
    MostrarNosAB(P->ESQ);
    MostrarProduto(P->Info);
    MostrarNosAB(P->DIR);
}
void ShowABinaria(ABinaria *A)
{
    if (A)
        MostrarNosAB(A->Inicio);
}
void DestruirNosAB(NOBinario *P)
{
    if (!P) return;
    DestruirNosAB(P->ESQ);
    DestruirNosAB(P->DIR);
    DestruirProduto(P->Info);
    free(P);
}
void DestruirABinaria(ABinaria *A)
{
    if (!A) return;
    DestruirNosAB(A->Inicio);
    free(A);
}
Produto *PesquisarNosABinaria(NOBinario *P, int cod)
{
    if (!P) return NULL;
    if (P->Info->ID == cod) return P->Info;
    if (cod < P->Info->ID) return PesquisarNosABinaria(P->ESQ, cod);
    return PesquisarNosABinaria(P->DIR, cod);
}
Produto *PesquisarABinaria(ABinaria *Pinheiro, int cod)
{
    if (!Pinheiro) return NULL;
    return PesquisarNosABinaria(Pinheiro->Inicio, cod);
}
int ContarNosABinaria(ABinaria *A)
{
    if (!A) return -1;
    return A->NEL;
}

int AlturaNosABinaria(NOBinario *P)
{
    if (!P) return 0;
    int AltEsq = AlturaNosABinaria(P->ESQ);
    int AltDir = AlturaNosABinaria(P->DIR);
    return 1 + Maximo(AltEsq, AltDir);

    //return 1 + Maximo(AlturaNosABinaria(P->ESQ), AlturaNosABinaria(P->DIR));
}

int AlturaABinaria(ABinaria *A)
{
    if (!A) return 0;
    return AlturaNosABinaria(A->Inicio);
}
int ContarNosFolhas(NOBinario *P)
{
    if (!P) return 0;
    if (!P->ESQ && !P->DIR) return 1;
    int cfe = ContarNosFolhas(P->ESQ);
    int cfd = ContarNosFolhas(P->DIR);

    return cfe + cfd;
}
int ContarFolhas(ABinaria *A)
{
    if (!A) return 0;
    return ContarNosFolhas(A->Inicio);
}
NOBinario *RemoverNo(NOBinario *P, int cod, int *Removido)
{
    if (!P) return NULL;
    if (cod == P->Info->ID)
    {
        if (!P->DIR && !P->ESQ) // Perante uma Folha
        {
            DestruirProduto(P->Info);
            free(P);
            *Removido = 1;
            return NULL;
        }
        else
        {
            if (P->ESQ)
            {
                NOBinario *Maior_Menores = Maior(P->ESQ);
                // Trocar as Informa��es P->Info com Maior_Menores->Info
                Produto *aux = P->Info;
                P->Info = Maior_Menores->Info;
                Maior_Menores->Info = aux;
                P->ESQ = RemoverNo(P->ESQ, cod, Removido);
            }
            // DIR
        }
    }
    else
    {
        if (cod < P->Info->ID)
            P->ESQ = RemoverNo(P->ESQ, cod, Removido);
        else
            P->DIR = RemoverNo(P->DIR, cod, Removido);
    }
    return P;
}
void RemoverABinaria(ABinaria *A, int cod)
{
    if (A)
    {
        int Removido = 0;
        A->Inicio = RemoverNo(A->Inicio, cod, &Removido);
        // Aten��o ser� que removeu?
        if (Removido) A->NEL--;
    }
}

NOBinario *Maior(NOBinario *P)
{
    if (!P) return NULL;
    if (!P->DIR) return P;
    return Maior(P->DIR);
}
NOBinario *Menor(NOBinario *P)
{
    if (!P) return NULL;
    NOBinario *Aux = P;
    while (Aux->ESQ)
        Aux = Aux->ESQ;
    return Aux;
}


int Maximo(int X, int Y)
{
    if (X > Y) return X;
    return Y;
}
int Modulo(int X)
{
    if (X < 0) return -X;
    return X;
}
int EquilibrioNOS(NOBinario *P)
{
    if (!P) return 1;
    int AE = AlturaNosABinaria(P->ESQ);
    int AD = AlturaNosABinaria(P->DIR);
    if (Modulo(AE-AD) > 1) return 0;

    int Eq_ESQ = EquilibrioNOS(P->ESQ);
    if (Eq_ESQ == 0) return 0;
    int Eq_DIR = EquilibrioNOS(P->DIR);
    return Eq_DIR;
    /*
    int Eq_ESQ = EquilibrioNOS(P->ESQ);
    int Eq_DIR = EquilibrioNOS(P->DIR);
    return Eq_ESQ && Eq_DIR;
    */
}
int Equilibrada(ABinaria *A)
{
    if (!A) return 1;
    return EquilibrioNOS(A->Inicio);
}
