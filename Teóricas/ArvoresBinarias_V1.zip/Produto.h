#ifndef PRODUTO_H_INCLUDED
#define PRODUTO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int ID;
    char *NOME;
}Produto;

Produto *CriarProduto(int _id, char *_nome);
void MostrarProduto(Produto *P);
void DestruirProduto(Produto *P);


#endif // PRODUTO_H_INCLUDED
