#include "Carro.h"

Carro *CriarCarro(char *Mat, int Ano)
{
    Carro *X = (Carro *)malloc(sizeof(Carro));
    strcpy(X->Matricula, Mat);
    X->Ano = Ano;
    return X;
}
void DestruirCarro(Carro *X)
{
    if (X) free(X);
}

void MostrarCarro(Carro *X)
{
    if (!X) return;
    printf("CARRO\n");
    printf("\t MATRICULA: [%s]\n", X->Matricula);
    printf("\t ANO: %d\n", X->Ano);
}

void GravarFicheiroCarro(FILE *F, Carro *X)
{
    fprintf(F, "CARRO\n");
    fprintf(F, "\t MATRICULA: [%s]\n", X->Matricula);
    fprintf(F, "\t ANO: %d\n", X->Ano);
}

int MemoriaCarro(Carro *X)
{
    return sizeof(*X);
}


