#include "ListaGenerica.h"



ListaGenerica *CriarLG()
{
    ListaGenerica *L = (ListaGenerica *)malloc(sizeof(ListaGenerica));
    L->Inicio = NULL;
    L->NEL = 0;
    return L;
}

int Add_LG_Inicio(ListaGenerica *L, void *X)
{
    if (!X) return 0;
    if (!L) return 0;
    NO_G *Aux = (NO_G *)malloc(sizeof(NO_G));
    if (!Aux) return 0;
    Aux->Info = X;
    Aux->Prox = L->Inicio;
    L->Inicio = Aux;
    L->NEL++;
    return 1;
}

void MostrarListaLG(ListaGenerica *L, void (*func)(void *obj))
{
    if (!L) return;
    NO_G *P = L->Inicio;
    while (P)
    {
        (*func)(P->Info);
        P = P->Prox;
    }
}
