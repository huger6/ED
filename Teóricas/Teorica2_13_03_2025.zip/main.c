#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "Carro.h"
#include "Lista.h"
#include "ListaGenerica.h"

extern void wait ( int mlseconds );
//--------------------------------------

void Exemplo_Tempo()
{
    wait (5300);
}

void ExperienciaGenerica()
{
    void *P;
    P = CriarCarro("ola", 1992);
    //P = (int *)malloc(sizeof(int));
    MostrarCarro((Carro *)P);
    //printf("P->Matricula = [%]\n", ((Carro *)P)->);
}

void FuncaoMostrarCarro(void *obj)
{
    Carro *X = (Carro *)obj;
    printf("X->Matricula = [%s]\n", X->Matricula);
}
void ExperienciaListaGenerica()
{
    ListaGenerica *LG = CriarLG();
    Carro *X = CriarCarro("dfdf", 1992);
    Add_LG_Inicio(LG, X);
    MostrarListaLG(LG, FuncaoMostrarCarro);
}
int main()
{
    printf("Aula Te�rica 4 : 13/03/2025!\n");
    //ExperienciaGenerica();
    ExperienciaListaGenerica();
    return 1;
    //Exemplo_Tempo();
   // return 1;
    Lista *LC;
    LC = CriarLista();
    Carro *X = CriarCarro("45-56-ZM", 2004);
    AddInicio(LC, X);
    MostrarLista(LC);

    X = CriarCarro("67-56-BG", 1992);
    AddInicio(LC, X);
    MostrarLista(LC);

    GravarFicheiro(LC, "dados.txt");

    int MEMORIA = MemoriaLista(LC);
    printf("MEMORIA = %d\n", MEMORIA);

    DestruirLista(LC);
    return 0;
}
