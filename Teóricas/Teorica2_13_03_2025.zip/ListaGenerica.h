#ifndef LISTAGENERICA_H_INCLUDED
#define LISTAGENERICA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


typedef struct no_g
{
   void *Info;
   struct no_g *Prox;
}NO_G;

typedef struct
{
    NO_G *Inicio;
    int NEL;
}ListaGenerica;

ListaGenerica *CriarLG();
int Add_LG_Inicio(ListaGenerica *L, void *X);

void MostrarListaLG(ListaGenerica *L, void (*func)(void *obj));
/*
void DestruirLista(ListaGenerica *L);
int GravarFicheiro(ListaGenerica *L, char *ficheiro);
int MemoriaLista(ListaGenerica *L);
*/

#endif // LISTAGENERICA_H_INCLUDED
