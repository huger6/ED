
#include "Produto.h"
extern float LerFloat(char *txt);
extern int Aleatorio(int min, int max);

Produto *CriarLerProduto()
{
    printf("Um dia vou fazer esta funcao %s\n", __FUNCTION__);
    Produto *X = (Produto *)malloc(sizeof(Produto));
    /*
    printf("NOME = ");
    scanf("%s", X->NOME);
    X->PRECO = LerFloat("Preco ?");
    */
    sprintf(X->NOME, "Nome Produto %d", Aleatorio(100, 200));
    X->PRECO = Aleatorio(2, 10);
    return X;
}
void MostrarProduto(Produto *X)
{
    //printf("Um dia vou fazer esta funcao %s\n", __FUNCTION__);
    if (!X) return;
    printf("Produto:\n");
    printf("\t NOME: %s\n", X->NOME);
    printf("\t PRECO: %f\n", X->PRECO);
}
void AumentarIvaProduto(Produto *X, float iva)
{
    //printf("Um dia vou fazer esta funcao %s\n", __FUNCTION__);
    if (!X) return;
    X->PRECO *= (1 + iva);
}


void LibertarProduto(Produto *X)
{
    printf("Um dia vou fazer esta funcao %s\n", __FUNCTION__);
    printf("Que esta na linha %d\n", __LINE__);
    printf("Do ficheiro %s\n", __FILE__);
    if (X) free (X);
}
