
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int LerInteiro(char *txt)
{
    printf("%s", txt);
    int X;
    scanf("%d", &X);
    return X;
}
float LerFloat(char *txt)
{
    printf("IPV: %s", txt);
    float X;
    scanf("%f", &X);
    return X;
}

int Aleatorio(int min, int max)
{
    return min + rand() % (max - min + 1);
}

int Soma(int x, int y)
{
    return x + y;
}

