#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Funcoes_Menus.h"
#include "Produto.h"
#include "Produto.h"
#include "Produto.h"
#include "Produto.h"
#include "Produto.h"
#include "Produto.h"


//----------------------------------------
extern int LerInteiro(char *txt);
extern int Aleatorio(int min, int max);
extern int Soma(int x, int y);
//----------------------------------------


int main()
{
    printf("Aula 1!\n");
    srand(time(NULL));
/*
    int A = Aleatorio(2, 10);
    printf("Idade?");
    int id;
    scanf("%d", &id);

    int X = LerInteiro("Qual a Idade?");
    printf("Idade = %d\n", X);
    X = LerInteiro("PESO?");
    printf("Pesito = %d\n", X);

    Menu_Principal();
system("pause > null");
    */

    Produto *P = CriarLerProduto();
    MostrarProduto(P);
    LibertarProduto(P);

    return 0;
}
