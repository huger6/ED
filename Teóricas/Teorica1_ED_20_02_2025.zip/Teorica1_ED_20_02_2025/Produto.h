#ifndef __PRODUTO__
#define __PRODUTO__

#include <stdio.h>
#include <stdlib.h>

#define MAX_NOME 50

typedef struct{
    char NOME[MAX_NOME];
    float PRECO;
}Produto;

Produto *CriarLerProduto();
void MostrarProduto(Produto *X);
void AumentarIvaProduto(Produto *X, float iva);
void LibertarProduto(Produto *X);


#endif // __PRODUTO__
