#ifndef FUNCOES_MENUS_H_INCLUDED
#define FUNCOES_MENUS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void Menu_Principal();
void Menu_Clientes();


#endif // FUNCOES_MENUS_H_INCLUDED
