
#include "Funcoes_Menus.h"

void Menu_Principal()
{
    printf("Menu Principal\n");
    printf("1 - Ler Dados\n");
    printf("0 - Sair\n");
}

void Menu_Clientes()
{
    printf("Menu Cliente\n");
    printf("1 - Ler Dadcvcxvcxvos\n");
    printf("0 - Sair\n");
}
