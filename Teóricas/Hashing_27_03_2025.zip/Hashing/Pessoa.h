#ifndef PESSOA_H_INCLUDED
#define PESSOA_H_INCLUDED

#include "Definicoes.h"

typedef struct
{
    char NOME[100];
    int Ano;
    char *CIDADE;
}Pessoa;

Pessoa *CriarPessoa(char *_nome, int _ano, char *_cidade);
void MostrarPessoa(Pessoa *X);
void DestruirPessoa(Pessoa *X);
int MemoriaPessoa(Pessoa *X);


#endif // PESSOA_H_INCLUDED
