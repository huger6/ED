#ifndef CARRO_H_INCLUDED
#define CARRO_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Definicoes.h"

typedef struct
{
    char Matricula[9];
    int Ano;
    char MARCA[20];
}Carro;

Carro *CriarCarro(char *Mat, int Ano, char *_marca);
void DestruirCarro(Carro *X);
void MostrarCarro(Carro *X);
void GravarFicheiroCarro(FILE *F, Carro *X);
int MemoriaCarro(Carro *X);

#endif // CARRO_H_INCLUDED
