#ifndef HASHING_H_INCLUDED
#define HASHING_H_INCLUDED

#include "Carro.h"
#include "Lista.h"

typedef struct no_chave
{
    char *CHAVE;
    Lista *Dados;
    struct no_chave *Prox;
}NO_CHAVE;

typedef struct
{
    NO_CHAVE *Inicio;
    int N_CHAVES;
}HASHING;

HASHING *CriarHASHING();
NO_CHAVE *FuncaoHASHING(HASHING *H, Carro *X);
int AddHASHING(HASHING *H, Carro *X);
void MostrarHASHING(HASHING *H);
void DestruirHASHING(HASHING *H);
char *GetChaveMaisEntradas(HASHING *H);


#endif // HASHING_H_INCLUDED
