#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Carro.h"

typedef struct no
{
   Carro *Info;
   struct no *Prox;
}NO;

typedef struct
{
    NO *Inicio;
    int NEL;
}Lista;


Lista *CriarLista();
int AddInicio(Lista *L, Carro *X);
void MostrarLista(Lista *L);
void DestruirLista(Lista *L);
Carro *Pesquisar(Lista *L, char *Matricula);
int GravarFicheiro(Lista *L, char *ficheiro);
int MemoriaLista(Lista *L);

int Size(Lista *L);

void AddOrd(Lista *L, Carro *X);
int Remover(Lista *L, char *mat);


#endif // LISTA_H_INCLUDED
