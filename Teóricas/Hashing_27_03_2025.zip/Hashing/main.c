#include <stdio.h>
#include <stdlib.h>
#include "Carro.h"
#include "Pessoa.h"
#include "Lista.h"
#include "ListaGenerica.h"
#include "Hashing.h"

int main()
{
    printf("Sobre Hashing!\n");
    HASHING *HAS = CriarHASHING();

    Carro *X = CriarCarro("ER-TY-56", 2050, "XIONG");
    AddHASHING(HAS, X);

    X = CriarCarro("67-89-56", 2030, "OPEL");
    AddHASHING(HAS, X);

    X = CriarCarro("ER-89-56", 2030, "XIONG");
    AddHASHING(HAS, X);

    X = CriarCarro("ER-78-56", 2030, "XIONG");
    AddHASHING(HAS, X);

    X = CriarCarro("67-89-YU", 2034, "OPEL");
    AddHASHING(HAS, X);

    X = CriarCarro("67-TT-YU", 2034, "TOYOTA");
    AddHASHING(HAS, X);

    MostrarHASHING(HAS);

    char *CME = GetChaveMaisEntradas(HAS);
    printf("Chave Mais Entradas = [%s]\n", CME);

    return 0;
}
