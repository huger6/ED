#ifndef DEFINICOES_H_INCLUDED
#define DEFINICOES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCESSO 1
#define INSUCESSO 0


#endif // DEFINICOES_H_INCLUDED
