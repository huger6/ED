
#include "ABinaria.h"

ABinaria *CriarABinaria()
{
    ABinaria *Arv = (ABinaria *)malloc(sizeof(ABinaria));
    Arv->Inicio = NULL;
    Arv->NEL = 0;
    return Arv;
}
NOBinario *AddNO(NOBinario *P, Produto *X)
{
    return NULL;
}
void AddABinaria(ABinaria *A, Produto *X)
{

}

void MostrarNosAB(NOBinario *P)
{
    if (!P) return;
    MostrarProduto(P->Info);
    MostrarNosAB(P->ESQ);
    MostrarNosAB(P->DIR);
}
void ShowABinaria(ABinaria *A)
{
    if (A)
        MostrarNosAB(A->Inicio);
}
void DestruirNosAB(NOBinario *P)
{
    if (!P) return;
    DestruirNosAB(P->ESQ);
    DestruirNosAB(P->DIR);
    DestruirProduto(P->Info);
    free(P);
}
void DestruirABinaria(ABinaria *A)
{
    if (!A) return;
    DestruirNosAB(A->Inicio);
    free(A);
}
Produto *PesquisarNosABinaria(NOBinario *P, int cod)
{
    if (!P) return NULL;
    if (P->Info->ID == cod) return P->Info;
    if (cod < P->Info->ID) return PesquisarNosABinaria(P->ESQ, cod);
    return PesquisarNosABinaria(P->DIR, cod);
}
Produto *PesquisarABinaria(ABinaria *Pinheiro, int cod)
{
    if (!Pinheiro) return NULL;
    return PesquisarNosABinaria(Pinheiro->Inicio, cod);
}
int ContarNosABinaria(ABinaria *A)
{
    if (!A) return -1;
    return A->NEL;
}

int AlturaNosABinaria(NOBinario *P)
{
    if (!P) return 0;
    int AltEsq = AlturaNosABinaria(P->ESQ);
    int AltDir = AlturaNosABinaria(P->DIR);
    return 1 + Maximo(AltEsq, AltDir);

    //return 1 + Maximo(AlturaNosABinaria(P->ESQ), AlturaNosABinaria(P->DIR));
}

int AlturaABinaria(ABinaria *A)
{
    if (!A) return 0;
    return AlturaNosABinaria(A->Inicio);
}
int ContarNosFolhas(NOBinario *P)
{
    if (!P) return 0;
    if (!P->ESQ && !P->DIR) return 1;
    int cfe = ContarNosFolhas(P->ESQ);
    int cfd = ContarNosFolhas(P->DIR);

    return cfe + cfd;
}
int ContarFolhas(ABinaria *A)
{
    if (!A) return 0;
    return ContarNosFolhas(A->Inicio);
}
NOBinario *RemoverNo(NOBinario *P, int cod, int *Removido)
{
        return NULL;
}
void RemoverABinaria(ABinaria *A, int cod)
{

}

NOBinario *Maior(NOBinario *P)
{
       return NULL;
}
NOBinario *Menor(NOBinario *P)
{
       return NULL;
}


int Maximo(int X, int Y)
{
    if (X > Y) return X;
    return Y;
}
