#ifndef ABINARIA_H_INCLUDED
#define ABINARIA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Produto.h"

typedef struct nob
{
    Produto *Info;
    struct nob *ESQ, *DIR;
    //struct nob *FILHOS[10];
}NOBinario;

typedef struct
{
    NOBinario *Inicio;
    int NEL;
}ABinaria;

ABinaria *CriarABinaria();
void ShowABinaria(ABinaria *A);
void DestruirABinaria(ABinaria *A);
Produto *PesquisarABinaria(ABinaria *A, int cod);
int ContarNosABinaria(ABinaria *A);
int ContarFolhas(ABinaria *A);
int AlturaABinaria(ABinaria *A);
void AddABinaria(ABinaria *A, Produto *X);
void RemoverABinaria(ABinaria *A, int cod);

NOBinario *Maior(NOBinario *P);
NOBinario *Menor(NOBinario *P);


#endif // ABINARIA_H_INCLUDED
