
#include "Produto.h"

Produto *CriarProduto(int _id, char *_nome)
{
    Produto *P = (Produto *)malloc(sizeof(Produto));
    P->ID = _id;
    P->NOME = (char *)malloc((strlen(_nome) + 1)*sizeof(char));
    strcpy(P->NOME, _nome);
    return P;
}
void MostrarProduto(Produto *P)
{
    printf("PRODUTO: %d : [%s]\n", P->ID, P->NOME);
}

void DestruirProduto(Produto *P)
{
    free(P->NOME);
    free(P);
}
