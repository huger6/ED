#include <stdio.h>
#include <stdlib.h>
#include "Produto.h"
/*
Aula T10: 08/05/2025

*/

int main()
{
    printf("Arvores Binarias - Versao 0!\n");
    return 0;
}
