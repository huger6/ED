#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "Carro.h"
#include "Lista.h"
#include "ListaGenerica.h"
#include "Pessoa.h"

//--------------------------------------
//--------------------------------------
extern void wait ( int mlseconds );
//--------------------------------------
//--------------------------------------
void Exemplo_Tempo()
{
    wait (5300);
}
//-----------
void ExperienciaGenerica()
{
    void *P;
    P = CriarCarro("ola", 1992);
    //P = (int *)malloc(sizeof(int));
    MostrarCarro((Carro *)P);
    //printf("P->Matricula = [%]\n", ((Carro *)P)->);
}
//-----------
void FuncaoMostrarCarroLG(void *obj)
{
    Carro *X = (Carro *)obj;
    printf("Matricula = [%s] ANO: %d\n", X->Matricula, X->Ano);
}
void FuncaoDestruirCarroLG(void *obj)
{
    Carro *X = (Carro *)obj;
    //free(X->Matricula);
    free(X);
}
int FuncaoCompAnoLG(void *X, void *Y)
{
    Carro *C = (Carro *)X;
    char *st = (char *)Y;
    int _anito = atoi(st);
    if (C->Ano == _anito) return 1;
    return 0;
}
//-----------
void FuncaoMostrarPessoaLG(void *obj)
{
    Pessoa *X = (Pessoa *)obj;
    printf("NOME = [%s] ANO: %d\n", X->NOME, X->Ano);
}
//-----------
void FuncaoMostrarPessoaLG_V1(void *obj)
{
    Pessoa *X = (Pessoa *)obj;
    printf("NOME = [%s]\n", X->NOME);
}
void FuncaoDestruirPessoaLG(void *obj)
{
    Pessoa *X = (Pessoa *)obj;
    //free(X->NOME);
    free(X);
}
int FuncaoCompNomeLG(void *X, void *Y)
{
    Pessoa *P = (Pessoa *)X;
    char *st = (char *)Y;
    if (strcmp(P->NOME, st) == 0) return 1;
    return 0;
}
//-----------
int main()
{
    printf("Aula Te�rica 5 - Listas Gen�ricas: 20/03/2025!\n");
    ListaGenerica *LGCarros = CriarLG();
    //----------
    Carro *X = CriarCarro("Opel", 1992);
    Add_LG_Inicio(LGCarros, X);
    X = CriarCarro("BMW", 2020);
    Add_LG_Inicio(LGCarros, X);
    X = CriarCarro("Tesla", 2024);
    Add_LG_Inicio(LGCarros, X);
    //----------
    MostrarListaLG(LGCarros, FuncaoMostrarCarroLG);

    int ret = PesquisarLG(LGCarros, FuncaoCompAnoLG, "2028");
    printf("Ret = %d\n", ret);
    //DestruirListaLG(LGCarros, FuncaoDestruirCarroLG);
    //-------------------------------------
    ListaGenerica *LP = CriarLG();
    Pessoa *P = CriarPessoa("Ze", 2000);
    Add_LG_Inicio(LP, P);
    MostrarListaLG(LP, FuncaoMostrarPessoaLG);
    MostrarListaLG(LP, FuncaoMostrarPessoaLG_V1);

    ret = PesquisarLG(LP, FuncaoCompNomeLG, "Ze");
    printf("Ret = %d\n", ret);

    DestruirListaLG(LP, FuncaoDestruirPessoaLG);

    return 0;
}
