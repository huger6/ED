#ifndef CARRO_H_INCLUDED
#define CARRO_H_INCLUDED

#include "Definicoes.h"

typedef struct
{
    char Matricula[9];
    int Ano;
}Carro;

Carro *CriarCarro(char *Mat, int Ano);
void DestruirCarro(Carro *X);
void MostrarCarro(Carro *X);
void GravarFicheiroCarro(FILE *F, Carro *X);
int MemoriaCarro(Carro *X);

#endif // CARRO_H_INCLUDED
