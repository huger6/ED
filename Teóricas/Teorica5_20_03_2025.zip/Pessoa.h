#ifndef PESSOA_H_INCLUDED
#define PESSOA_H_INCLUDED

#include "Definicoes.h"

typedef struct
{
    char NOME[100];
    int Ano;
}Pessoa;

Pessoa *CriarPessoa(char *_nome, int _ano);
void MostrarPessoa(Pessoa *X);

#endif // PESSOA_H_INCLUDED
