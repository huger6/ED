
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Ficheiro onde se devem colocar fun��es �teis para qualquer projecto

int LerInteiro(char *txt)
{
    printf("%s", txt);
    int X;
    scanf("%d", &X);
    return X;
}
float LerFloat(char *txt)
{
    printf("%s", txt);
    float X;
    scanf("%f", &X);
    return X;
}

int Aleatorio(int min, int max)
{
    return min + rand() % (max - min + 1);
}

void wait ( int mlseconds )
{
    clock_t endwait;
    endwait = clock () + mlseconds;
    while (clock() < endwait);
}
void wait_segundos ( int seconds )
{
    clock_t endwait;
    endwait = clock () + seconds * CLOCKS_PER_SEC;
    while (clock() < endwait);
}
