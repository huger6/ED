
#include "Pessoa.h"

Pessoa *CriarPessoa(char *_nome, int _ano)
{
    Pessoa *X = (Pessoa *)malloc(sizeof(Pessoa));
    strcpy(X->NOME, _nome);
    X->Ano = _ano;
    return X;
}
void MostrarPessoa(Pessoa *X)
{
    if (!X) return;
    printf("PESSOA\n");
    printf("\t NOME: [%s]\n", X->NOME);
    printf("\t ANO: %d\n", X->Ano);
}
