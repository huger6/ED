#include "Lista.h"

//-------------------------------------
//-------------------------------------
extern void wait ( int mlseconds );
//-------------------------------------
//-------------------------------------
//-------------------------------------
Lista *CriarLista()
{
    Lista *L = (Lista *)malloc(sizeof(Lista));
    L->Inicio = NULL;
    L->NEL = 0;
    return L;
}
int AddInicio(Lista *L, Carro *X)
{
    if (!X) return INSUCESSO;
    if (!L) return INSUCESSO;
    NO *Aux = (NO *)malloc(sizeof(NO));
    if (!Aux) return INSUCESSO;
    Aux->Info = X;
    Aux->Prox = L->Inicio;
    L->Inicio = Aux;
    L->NEL++;
    return SUCESSO;
}
void MostrarLista(Lista *L)
{
    if (!L) return;
    NO *P = L->Inicio;
    while (P)
    {
        MostrarCarro(P->Info);
        P = P->Prox;
    }
}

Carro *Pesquisar(Lista *L, char *Matricula)
{
    if (!L) return NULL;
    NO *P = L->Inicio;
    while (P)
    {
        if (stricmp(P->Info->Matricula, Matricula) == 0)
            return P->Info;
        P = P->Prox;
    }
    return NULL;
}
void DestruirLista(Lista *L)
{
    if (!L) return;
    NO *P = L->Inicio;
    NO *Q;
    while (P)
    {
        DestruirCarro(P->Info);
        Q = P->Prox;
        free(P);
        P = Q;
    }
    free(L);
}
int GravarFicheiro(Lista *L, char *ficheiro)
{
    clock_t T0 = clock();
    if (!L) return INSUCESSO;
    FILE *F = fopen(ficheiro, "w");
    if (!F) return INSUCESSO;
    NO *P = L->Inicio;
    while (P)
    {
        GravarFicheiroCarro(F, P->Info);
        P = P->Prox;
    }
    fclose(F);
    wait (2);
    clock_t T1 = clock();
    double DT = (double)((T1 - T0)) / CLOCKS_PER_SEC;
    FILE *ftempos = fopen("performance.csv", "a");
    fprintf(ftempos, "%s;%f\n", __FUNCTION__, DT);
    fclose(ftempos);
    return SUCESSO;
}
int MemoriaLista(Lista *L)
{
    if (!L) return 0;
    int mem = sizeof(Lista);
    NO *P = L->Inicio;
    while (P)
    {
        mem += sizeof(NO);
        mem += MemoriaCarro(P->Info);
        P = P->Prox;
    }
    return mem;
}

int Size(Lista *L)
{
    return L->NEL;
}


void AddOrd(Lista *L, Carro *X)
{
    NO *Caixa = (NO *)malloc(sizeof(NO));
    Caixa->Info = X;
    Caixa->Prox = NULL;
    NO *Ant = NULL;
    NO *P = L->Inicio;
    int STOP = 0;
    while(!STOP && P)
    {
        if (X->Ano > P->Info->Ano)
        {
            Ant = P;
            P = P->Prox;
        }
        else
            STOP = 1; // � para inserir entre o Ant e P
    }
    // � para inserir entre o Ant e P
    if (Ant)
        Ant->Prox = Caixa;
    else // Inserir no inicio
        L->Inicio = Caixa;
    Caixa->Prox = P;
    L->NEL++;
}

int Remover(Lista *L, char *mat)
{
    // encontrar o elemento
    // refazer as liga��es
    NO *Ant = NULL;
    NO *P = L->Inicio;
    int PARAR = 0;
    while (!PARAR && P)
    {
        if (strcmp(P->Info->Matricula, mat) == 0)
            PARAR = 1;
        else
        {
            Ant = P;
            P = P->Prox;
        }
    }
    if (PARAR)
    {
        if (Ant)
            Ant->Prox = P->Prox;
        else // Remover no inicio!
            L->Inicio = P->Prox;
        //Destruir o P
        DestruirCarro(P->Info);
        free(P);
        L->NEL--;
    }
    return PARAR;
}
