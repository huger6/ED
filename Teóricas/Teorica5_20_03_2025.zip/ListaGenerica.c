#include "ListaGenerica.h"


ListaGenerica *CriarLG()
{
    ListaGenerica *L = (ListaGenerica *)malloc(sizeof(ListaGenerica));
    L->Inicio = NULL;
    L->NEL = 0;
    return L;
}

int Add_LG_Inicio(ListaGenerica *L, void *X)
{
    if (!X) return 0;
    if (!L) return 0;
    NO_G *Aux = (NO_G *)malloc(sizeof(NO_G));
    if (!Aux) return 0;
    Aux->Info = X;
    Aux->Prox = L->Inicio;
    L->Inicio = Aux;
    L->NEL++;
    return 1;
}

void MostrarListaLG(ListaGenerica *L, void (*func)(void *obj))
{
    if (!L) return;
    NO_G *P = L->Inicio;
    while (P)
    {
        (*func)(P->Info);
        P = P->Prox;
    }
}

void DestruirListaLG(ListaGenerica *L, void (*Fdest)(void *obj))
{
    if (!L) return;
    NO_G *P = L->Inicio;
    NO_G *S;
    while (P)
    {
        S = P->Prox;
        (*Fdest)(P->Info);
        free(P);
        P = S;
    }
    free(L);
}

//Pesquisar(L, FcompNome, "Zezito");
int PesquisarLG(ListaGenerica *L, int (*fcomp)(void *X, void *Y), void *Obj)
{
    if (!L) return 0;
    if (!L->Inicio) return 0;
    NO_G *P = L->Inicio;
    while (P)
    {
        if ((*fcomp)(P->Info, Obj) == 1)
            return 1; // return P->Info
        P = P->Prox;
    }
    return 0;
}

void OrdenarLG(ListaGenerica *L, int (*fcomp)(void *X, void *Y))
{
/*
    if ((*comp)(P->Info, Q->Info) > 1)
    {

    }
    */
}
