
#include "Hashing.h"

HASHING *CriarHASHING(int flag)
{
    printf("Funcao <%s> a Fazer!\n", __FUNCTION__);
    HASHING *Has = (HASHING *)malloc(sizeof(HASHING));
    Has->Inicio = NULL;
    Has->N_CHAVES = 0;
    Has->Flag_Destruir = flag;
    return Has;
}
NO_CHAVE *FuncaoHASHING(HASHING *H, Carro *X)
{
    NO_CHAVE *P = H->Inicio;
    while(P)
    {
        if (strcmp(P->CHAVE, X->MARCA) == 0) // Encontrei
            return P;
        P = P->Prox;
    }
    return NULL;
}
int AddHASHING(HASHING *H, Carro *X)
{
    NO_CHAVE *P = FuncaoHASHING(H, X);
    if (!P)
    {
        P = (NO_CHAVE *)malloc(sizeof(NO_CHAVE));
        P->CHAVE = (char *)malloc((strlen(X->MARCA)+1)*sizeof(char));
        strcpy(P->CHAVE, X->MARCA);
        P->Dados = CriarLista();
        P->Prox = H->Inicio;
        H->Inicio = P;
    }
    AddInicio(P->Dados, X);
    return SUCESSO;
}
void MostrarHASHING(HASHING *H)
{
    printf("Funcao <%s> a Fazer!\n", __FUNCTION__);
    NO_CHAVE *P = H->Inicio;
    while(P)
    {
        MostrarLista(P->Dados);
        P = P->Prox;
    }
}
void DestruirHASHING(HASHING *H)
{
    printf("Funcao <%s> a Fazer!\n", __FUNCTION__);
    //if (Flag_Destruir == 1)
}

char *GetChaveMaisEntradas(HASHING *H)
{
    NO_CHAVE *P = H->Inicio;
    int Maximo = 0;
    char *P_Chave_Max = NULL;
    while(P)
    {
        if (P->Dados->NEL > Maximo)
        {
            Maximo = P->Dados->NEL;
            P_Chave_Max = P->CHAVE;
        }
        P = P->Prox;
    }
    return P_Chave_Max;
}
