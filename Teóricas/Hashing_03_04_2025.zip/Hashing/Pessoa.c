
#include "Pessoa.h"

Pessoa *CriarPessoa(char *_nome, int _ano, char *_cidade)
{
    Pessoa *X = (Pessoa *)malloc(sizeof(Pessoa));
    strcpy(X->NOME, _nome);
    X->CIDADE = (char *)malloc((strlen(_cidade) + 1) * sizeof(char));
    strcpy(X->CIDADE, _cidade);
    X->Ano = _ano;
    return X;
}
void MostrarPessoa(Pessoa *X)
{
    if (!X) return;
    printf("PESSOA\n");
    printf("\t NOME: [%s]\n", X->NOME);
    printf("\t ANO: %d\n", X->Ano);
    printf("\t CIDADE: [%s]\n", X->CIDADE);
}

void DestruirPessoa(Pessoa *X)
{
    if (!X) return;
    free(X->CIDADE);
    free(X);
}

int MemoriaPessoa(Pessoa *X)
{
    return sizeof(*X) + (strlen(X->CIDADE) + 1)*sizeof(char);
}
