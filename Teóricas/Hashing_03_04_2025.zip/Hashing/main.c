#include <stdio.h>
#include <stdlib.h>
#include "Carro.h"
#include "Pessoa.h"
#include "Lista.h"
#include "ListaGenerica.h"
#include "Hashing.h"

int FCompMARCA(void *X, void *Y);
int FCompANO(void *X, void *Y);
int FCompCARRO(void *X, void *Y);

int main()
{
    printf("Sobre Hashing!\n");

    ListaGenerica *LG = CriarLG();
    Carro *X = CriarCarro("67-TT-YU", 2034, "TOYOTA");
    Add_LG_Inicio(LG, X);

    void *Ptr1 = PesquisarLG(LG, FCompMARCA, "TOYOTA");
    if (Ptr1)
    {
       MostrarCarro((Carro *)Ptr1);
    }
    else
        printf("Nao existe\n");

    int ANO = 2034;
    void *Ptr2 = PesquisarLG(LG, FCompANO, &ANO);
    //-----------------
    Carro *Carro_XPTO = CriarCarro("67-TT-YU", 2034, "TOYOTA");
    void *Ptr3 = PesquisarLG(LG, FCompCARRO, Carro_XPTO);


    //DestruirListaLG(LG, DestruirCarro);
    //DestruirListaLG(LG_1, NULL);

    return 0;
}

int FCompMARCA(void *X, void *Y)
{
    Carro *C = (Carro *)X;
    char *M = (char *)Y;
    if (strcmp(C->MARCA, M) == 0) return 1;
    return 0;
}
int FCompANO(void *X, void *Y)
{
    Carro *C = (Carro *)X;
    int *M = (int *)Y;
    if (C->Ano == *M) return 1;
    return 0;
}
int FCompCARRO(void *X, void *Y)
{
    Carro *C = (Carro *)X;
    Carro *M = (Carro *)Y;
    if (strcmp(C->Matricula, M->Matricula) == 0) return 1;
    return 0;
}


