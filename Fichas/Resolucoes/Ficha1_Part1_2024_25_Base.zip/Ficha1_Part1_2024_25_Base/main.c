//
//  main.c
//  Ficha1_Part1_2024_25_Base
//
//

#include "Structs.h"

#include "Includes.h"

#include "Funcs.h"

#define GERAR_FICHEIRO 1

int main(void)
{
	setlocale(LC_ALL,"Portuguese"); /* para usar caracteres acentuados   */
	// variáveis para time.h
	clock_t start, end;
	double elapsed=0.0;
	
	int vectOrig=0; // se existe o dado edOrig e respectivo vector
	int vectCopia=0; // se existe o dado edCopia e vector respectivo
	int vectOrd=0; // se o vector de edCopia foi ordenado

	int opcao;
	FILE *F=NULL;
	EDADOS *edOrig=NULL, *edCopia=NULL; // edOrig - Estrutura de dados com os dados originais (lidos do ficheiro);
	edOrig = criarEDados();   // é criada a estrutura da dados origem
	// edCopia - Estrutura de dados copiados da etOrig, usada depois para as ordenações
	// gerar os dados e gravá-los no ficheiro
	int teste=1;
	if(GERAR_FICHEIRO){  // se GERAR_FICHEIRO = 1, devem ser gerados os dados dos utilizadores
		// e gravados no ficheiro. Depois do fich. ter os dados que se pretendem,
		// colocar GERAR_FICHEIRO a 0.
		
	// Atenção: na pasta (ou directório) onde está o programa executável
	// deve existir o ficheiro "nome.txt" (que contém 10000 nomes) que foi fornecido no
	// .zip onde existem também os ficheiros que constituem este projecto.
		gerarFicheiro("Utilizadores.dat");
	}
	do {
		opcao = menu();
		switch(opcao) {
			case 1:
			{
				// Start measuring time
				start = clock();
				
				// Colocar aqui a invocação da função apropriada e respectivo(s) parâmetro(s) para ler o ficheiro

				printf("Opção ainda não implementada!\n");
				printf("Digite uma tecla para continuar... ");
				getchar();	getchar();
				printf("\n");
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				//printf("Time measured: %.3f seconds.\n", elapsed);
				F = fopen("Tempos.csv", "a");
				fprintf(F,"Acao; Tempo de execucao. \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F,"Leitura do ficheiro Utilizadores.dat; Executada em %f segundos. \n", elapsed);
				fclose(F);
				break;
			}
			case 2:
			{
				if (vectCopia == 1) // se vectCopia estiver a true,
					// o dado edCopia é apagado e recriado,
					// sendo, naturalmente, colocado vectCopia a false.
					// Estas operações apresentam-se infra:
				{
					libertarMemoria(edCopia);
					vectCopia=0;
				}
				// Colocar aqui a invocação da função apropriada e respectivo(s) parâmetro(s)
				// para criar o novo dado (edCopia)
				
				printf("Opção ainda não implementada!\n");
				printf("Digite uma tecla para continuar... ");
				getchar();	getchar();
				printf("\n");
				
				// Colocar infra, a invocação da função duplicaDados para duplicar os dados e
				// respectivo(s) parâmetro(s), ou seja,
				// copiar os dados originais (do edOrig) para a copia (o edCopia)
	
				
				
				vectCopia=1; // já foi criado o edCopia e copiados os dados para ele
				vectOrd=0;  // o vectCopia ainda não foi ordenado
				break;
			}
			case 3:
			{
				// Start measuring time
				start = clock();
				if(vectCopia){
					// colocar aqui a invocação da função ordenarDados que irá
					// ordenar os dados do dado apropriado e respectivo(s) parâmetro(s)
					// Obs.: não esquecer de colocar a true o dado que indica
					//       que a operação de ordenação já foi executada
					
					
					printf("Opção ainda não implementada!\n");
					printf("Digite uma tecla para continuar... ");
					getchar();	getchar();
					printf("\n");
					
					
					vectOrd=1;
				}
				else{
					printf("\nNão foi executada a opção 2, para criar a estrutura de dados edCopia e copiados os dados para lá.");
					printf("\nProceda à sua criação e cópia dos dados para ela, executando depois esta opção.");
					break;
				}
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				//printf("Time measured: %.3f seconds.\n", elapsed);
				F = fopen("Tempos.csv", "a");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F,"Ordenação por número de acessos usando Bubble Sort; Executada em %f segundos. \n", elapsed);
				fclose(F);
				break;
			}
			case 4:
			{
				if(vectCopia){ // se vectCopia estiver a true, significa que
					// edCopia existe e também o respectivo vector
					printf("\nA função libertar memória da estrutura edCopia devolveu o valor %d\n", teste);
					// Na linha anterior, substituir "teste" pela invocação da função
					// libertarMemoria e respectivo(s) parâmetro(s)
					vectCopia=0; // indica que já não existe o vectCop
					vectOrd=0;   // obviamente, se vectCop não existe, ele não pode estar ordenado
				}
				
				if(vectOrig){ // se existir o dado edOrig, deve libertar-se toda a memória alocada
					printf("\nA função libertar memória da estrutura edOrig devolveu o valor %d\n", teste); //
					// Na linha anterior, substituir "teste" pela invocação da função
					// libertarMemoria e respectivo(s) parâmetro(s)
					vectOrig=0; // indica que já não existe o vectOrig
				}
				
				printf("Apesar das mensagens, esta opção ainda não foi implementada!\n");
				printf("Digite uma tecla para continuar... ");
				getchar(); getchar();
				printf("\n");
				
				break;
			}
			case 5:
			{
				// Colocar aqui a invocação da função listarDados, para listar os dados origem
				// e respectivo(s) argumentos
				
				break;
			}
			case 6:
			{
				if(vectCopia && vectOrd){  // só serão listados os utilizadores ordenados
					// se o dado edCopia tiver dados e estes tiverem sido ordenados
					teste=1;
					// Colocar aqui a invocação da função listarDados, para listar os dados copia
					// e respectivo(s) argumentos
					
					
					printf("Opção ainda não implementada!\n");
					printf("Digite uma tecla para continuar... ");
					getchar();	getchar();
					printf("\n");
				}
				else{
					printf("\nOu não existem os dados cópia ou, se existirem, ainda não foram ordenados!! ");
					printf("\nProceda à sua criação e/ou ordenação da forma pretendida e liste depois.");
				}
				break;
			}
			case 0: printf("\n ###### FIM ######\n"); break;
			default:
				break;
		}
	} while( opcao != 0 );
	// destriuir as estruturas de dados criadas para guardar os dados em memória
	if (vectOrd==1)  // se a estrutura de dados de utilizadores para ordenar foi criada
		// Colocar aqui a invocação da função apropriada e respectivo(s) parâmetro(s)
		// para libertar a memória respectiva
		
	if (vectOrig==1)  // se a estrutura de dados de utilizadores (edOrig) foi criada e tem dados
		// colocar aqui a invocação da função libertarMemoria e respectivo(s) parâmetro(s)
		// para libertar a memória respectiva
		
	return 0;
}

