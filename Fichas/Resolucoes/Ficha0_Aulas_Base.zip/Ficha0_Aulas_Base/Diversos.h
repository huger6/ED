//
//  Diversos.h
//  Ficha0_Aulas_Base
//

#ifndef Diversos_h
#define Diversos_h

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

// Ex. 2
typedef struct musica
{
	char titulo[50];
	char interprete[50];
	short ano;
	short single;
	int nDownloads;
} Musica;

// Ex. 3
typedef struct uc{
	char nome[20];
	float aval;
}UC;

typedef struct estudante {
	char nome[30];
	int num;
	UC unidCurr[5];
}Estudante;

// Ex. 4
typedef struct data
{
	int dia, mes, ano;
} Data;

typedef struct indiv
{
	int CC;
	Data nasc;
	float massa, alt;
	char genero;
} Indiv;

void retiraEnterString(char *S);

#endif /* Diversos_h */
