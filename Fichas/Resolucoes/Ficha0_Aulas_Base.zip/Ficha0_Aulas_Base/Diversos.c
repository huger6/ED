//
//  Diversos.c
//  Ficha0_Aulas_Base
//

#include "Diversos.h"
// Função que vai retirar o Enter que fica no final da string aceite pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte
// A função procura o final de string ('\0'), e coloca outro ('\0') a sobrepôr o caracter anterior,
// onde está o Enter, eliminando-o.
void retiraEnterString(char *S){
	while(*S!='\0')
		S++;
	*(--S)='\0';
}
