//
//  Funcs.h
//  Ficha0_Aulas_Base
//

#ifndef Funcs_h
#define Funcs_h

#include "Diversos.h"
#include "Funcs.h"

// Protitipos das funções invocadas no main()
// Criação, preenchimento com valores aleatórios e destruicão da matriz
int *criarPreencherMatriz(int M, int N);
void mostrarMatriz(int *mat, int M, int N);
void destruirMatriz(int *mat);

// Ex. 1
int esparsa(int *Matriz, int M, int N, float percentagem);

// Ex. 2
int numMusicasCantor(Musica *lista, int n, char *cantor);
void musicasDownLoad(Musica *lista, int n, int numD, int *nMusicasMaisNumDownloads);
float gravaFichMusicas(Musica *lista, int n, int ano, char *nFichNome, char tpMeio);

// Ex. 3
int qtosPassam (Estudante *lista, int n);
float numUcInfLim(Estudante *lista, int n, int lim);
void listaNotas(Estudante *lista, int n, int val, char *nomeFich);

// Ex. 4
int indSaudaveis(Indiv *vet_ind, int n);
float mediaMassCorp(Indiv *vet_ind, int n, int anoInf, int anoSup);
int removeIndiv(Indiv *vet_ind, int *n, int nCC);

#endif /* Funcs_h */
