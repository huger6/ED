//
//  main.c
//  Ficha0_Aulas_Base
//

#include "Diversos.h"
#include "Funcs.h"

int main(int argc, const char * argv[]) {
	setlocale(LC_ALL,"Portuguese");
	
	printf("\nCriação e preenchimento da matriz com valores aleatórios.......\n");
	// Criação e carregamento da matriz
	int nLin, nCol;  // nLin - número de linhas da matriz; nCol - número de colunas da matriz
	float perc; // percentagem mínima a considerar para considerar a matriz como esparsa
	
	do{
		printf("\nQual o número de linhas que terá a matriz? ");
		scanf("%d", &nLin);
	}while(nLin<2 || nLin>100);
	do{
		printf("\nQual o número de colunas que terá a matriz? ");
		scanf("%d", &nCol);
	}while(nCol<2 || nCol>100);
	
	printf("NLin=%d, NCol=%d", nLin, nCol);
	
	srand((unsigned int)time(NULL));
	int *mat = NULL;

	// Gerar e preencher a matriz
	mat = criarPreencherMatriz(nLin, nCol);
	// Mostrar a matriz gerada
	mostrarMatriz(mat, nLin, nCol);
	
	printf("n\n Início da execução do Exercício 1....\n");
	
	printf("\nIntroduza o limite para que a matriz possa considerar-se como esparsa (em %%): ");
	scanf("%f.2", &perc);
	/*
	if (esparsa(...)) // colocar os parâmetros para invocar a função
		printf("\nA matriz é esparsa!");
	else
		printf("\nA matriz não é esparsa!");
	 */
	// libertar a memória
	
	// invocar a função criada para libertar a memória
	// (colocar aqui a função)
	fseek(stdin, 0, 2);
	printf("\n\nDigite <Enter> para iniciar o teste do exercício 2: ");
	getchar();
	
	// Ex. 2
	printf("\n\n Início da execução do Exercício 2....\n");
	int nMusicas=4;
	// 2.a)
	
	// Declarar o ponteiro para o vector de músicas e efectuar a respectiva alocação da memória
	// (colocar aqui a(s) instruções)
	
	// 2.b)
	// Inserir no vector os dados de algumas canções
	   strcpy(musicas->titulo, "Hello");
	   strcpy(musicas->interprete, "Lionel Ritchie");
	   musicas->ano=1985;
	   musicas->single=1;
	   musicas->nDownloads=290;
	   
	   strcpy((musicas+1)->titulo, "Hotel California");
	   strcpy((musicas+1)->interprete, "Eagles");
	   (musicas+1)->ano=1980;
	   (musicas+1)->single=0;
	   (musicas+1)->nDownloads=429;
	   
	   strcpy((musicas+2)->titulo, "Confortably Numb");
	   strcpy((musicas+2)->interprete, "Pink Floyd");
	   (musicas+2)->ano=1987;
	   (musicas+2)->single=1;
	   (musicas+2)->nDownloads=1390;
	   
	   strcpy((musicas+3)->titulo, "Money");
	   strcpy((musicas+3)->interprete, "Pink Floyd");
	   (musicas+3)->ano=1975;
	   (musicas+1)->single=0;
	   (musicas+3)->nDownloads=1429;

	printf("\n\nExecução da alínea 2.b)\n");
	int nMusDown=0, numMinDown=0;
	char cantor[100];
	char tpMeio=' ';
	fseek(stdin, 0, 2);
	do{
		printf("\nIntroduza o número de downloads mínimo que devem ter as músicas para que sejam apresentadas: ");
		scanf("%d", &numMinDown);
	} while(numMinDown <1 || numMinDown>1000000000);
	
	// invocar a função criada para calcular as músicas que tiveram mais
	// de um número de downloads especificado
	// (colocar aqui a função)

	printf("\n\nExercício 2.b) O Número de músicas que tiveram mais de %d downloads foi: %d\n", numMinDown, nMusDown);
	
	// 2.c)
	printf("\n\n Execução da alínea 2.c)\n");
	fseek(stdin, 0, 2);
	printf("\nIntroduza o cantor ou grupo cujas músicas devem ser mostradas: ");
	if (fgets(cantor, sizeof(cantor), stdin) != NULL) {
		retiraEnterString(cantor);  // retirar o <Enter> que o fgets coloca também na string que aceita
		printf("\nFoi inserido o texto: %s\n", cantor);
	} else {
		printf("\nHouve um erro na leitura dos dados de entrada.");
		fseek(stdin, 0, 2);
		printf("\nDigite <Enter> para continuar...");
		getchar();
	}
   
	printf("\nO número de músicas do cantor ou grupo %s é %d", cantor, numMusicasCantor(musicas, nMusicas, cantor));
	
	// 2.d)
	printf("\n\n Execução da alínea 2.d)\n");
	int nAno=1980;
	fseek(stdin, 0, 2);
	do{
		printf("\nIntroduza o ano a partir do qual devem ser consideradas as músicas a gravar no fich. binário: ");
		scanf("%d", &nAno);
	}while(nAno<1900 || nAno>2050);
	fseek(stdin, 0, 2);
	do{
		printf("\nQual o tipo de suporte da música que pretende gravar no fich. binário (s-single; n-não single; a-ambos: ");
		scanf("%c", &tpMeio);
	}while(!(tpMeio=='s' || tpMeio=='n' || tpMeio == 'a'));
	char nFich[20]="FichMusicas.dat";
	gravaFichMusicas(musicas, nMusicas, nAno, nFich, tpMeio);
	// libertar a memória
	free (musicas);
	fseek(stdin, 0, 2);
	printf("\nDigite <Enter> para continuar...");
	getchar();
	
	// Ex. 3
	printf("\n\n Exercício 3....\n");
	// 3.a)
	printf("\n\n Execução da alínea 3.a)\n");
	int nReg,i,j;
	char *fich = "Fich";
	Estudante *listEstud;
	fseek(stdin, 0, 2);
	printf("\nQuantos Estudantes? ");
	scanf("%d", &nReg);
	listEstud = (Estudante*)malloc(sizeof(Estudante)*nReg);
	
	//3.b)
	printf("\n\n Execução da alínea 3.b)\n");
	char s[30];
	for (i = 0; i < nReg; i++)
	{
		strcpy((listEstud+i)->nome, "abel");
		(listEstud+i)->num = i + 5010;
		for (j = 0; j < 5; j++)
		{
			if(i%2)
				(listEstud+i)->unidCurr[j].aval = 8 + (j);
			else
				(listEstud+i)->unidCurr[j].aval = 6 + (j);
			sprintf(s, "UC %d", j+1);
			strcpy((listEstud+i)->unidCurr[j].nome, s);
		}
	}
	printf("Obtiveram aprovação %d \n", qtosPassam(listEstud, nReg));
	
	// 3.c)
	printf("\n\n Execução da alínea 3.c)\n");
	printf("Média de UC: %f\n", numUcInfLim(listEstud, nReg, 9));
	
	// 3.d)
	printf("\n\n Execução da alínea 3.d)\n");
	listaNotas(listEstud, nReg, 10, fich);
	// libertar a memória
	free (listEstud);
	
	// Ex. 4
	printf("\n\n Exercício 4....\n");
	
	// 4.a)
	printf("\n\n Execução da alínea 4.a)\n");
	int nReg1, nCC;
	Indiv *ListIndiv;
	int anoInf, anoSup;
	anoInf=1920;
	anoSup=2030;
	fseek(stdin, 0, 2);
	printf("\nQual o número  de indivíduos a registar? ");
	scanf("%d", &nReg1);
	ListIndiv = (Indiv*)malloc(sizeof(Indiv)*nReg1);
	
	for (i = 0; i < nReg1; i++)
	{
		printf("\nCC, alt, peso? ");
		scanf("%d%f%f", &(ListIndiv+i)->CC, &(ListIndiv+i)->alt, &(ListIndiv+i)->massa);
		printf("\ndia, mes, ano: ");
		scanf("%d%d%d", &(ListIndiv+i)->nasc.dia, &(ListIndiv+i)->nasc.mes, &(ListIndiv+i)->nasc.ano);
		fseek(stdin, 0, 2);
		do{
			printf("\nGénero: ");
			scanf(" %c", &(ListIndiv+i)->genero);
		}while(!((ListIndiv+i)->genero == 'M' || (ListIndiv+i)->genero == 'F' || (ListIndiv+i)->genero == 'O'));
	}
	// 4.b)
	printf("\n\nExecução da alínea 4.b)\n");
	
	printf("\nNúmero de indivíduos saudáveis: %d\n", indSaudaveis(ListIndiv, nReg1));
	printf("\nDigite <Enter> para continuar...");
	fseek(stdin, 0, 2);
	getchar();
	// 4.c)
	printf("\n\nExecução da alínea 4.c)\n");

	do{
		printf("Quais os anos a considerar para intervalo de anos de nasciento de individuos a considerar (ano inf. ano sup.)? ");
		fseek(stdin, 0, 2);
		scanf("%d, %d", &anoInf, &anoSup);
	}while((anoInf<1920 || anoSup > 2030) || (anoInf > anoSup));
	
	// Invocação da função que calcula a média da massa corporal dos indivíduos que obedecem
	// aos valores do filtro especificado
	// Apresentar o valor, invocando a função na instrução printf()
	// (Colocar aqui a instrução que realiza as operações referidas nos comentários acima)
	
	printf("\nDigite <Enter> para continuar...");
	fseek(stdin, 0, 2);
	getchar();
	
	// 4.d)
	printf("\n\nExecução da alínea 4.d)\n");
	do{
		fseek(stdin, 0, 2);
		printf("\nQual o CC do indivíduo que pretende remover (max. 9 dígitos)? ");
		scanf(" %d", &nCC);
	}while(nCC<0 || nCC >999999999);
	
	if(removeIndiv(ListIndiv, &nReg1, nCC))
		printf("\nO individuo cujo CC era [%d] foi removido com sucesso.", nCC);
	else
		printf("\nO individuo cujo CC é [%d] não foi encontrado.", nCC);
	fseek(stdin, 0, 2);
	printf("\nDigite <Enter> para continuar...");
	getchar();
	
	// libertar a memória
	free (ListIndiv);
	return 0;
}
