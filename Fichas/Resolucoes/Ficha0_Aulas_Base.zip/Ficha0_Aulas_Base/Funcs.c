//
//  Funcs.c
//  Ficha0_Aulas_Base
//

#include "Funcs.h"

/** \brief Geração de dados aleatórios
 *
 * \param min int: Valor do número mínimo a gerar
 * \param max int: Valor do número máximo a gerar
 * \return valor int
 *
 */
int aleatorio(int min, int max)
{
	int valor = min + rand() % (max - min + 1);
	return valor;
}

/** \brief Criar a matriz e preenchê-la com dados gerados aleatoriamente
 *
 * \param M int : Número de linhas da matriz
 * \param N int : Número de colunas da matriz
 * \return mat int *
 *
 */
int *criarPreencherMatriz(int M, int N)
{
   // printf("Um dia vou fazer...CriarPreencherMatriz.\n");
	int i, nAleat;
	int *mat = (int *) malloc(M * N * sizeof(int));
	if(mat == NULL){
		printf("\nNão foi possível alocar memória para a matriz!!");
		return 0;
	}
	for (i = 0; i < M*N; i++){
		nAleat = aleatorio(0, 5);
		printf("\n i=%d, nAleat=%d", i, nAleat);
		*(mat+i) = nAleat;
	}
	return mat;
}

/** \brief Mostra uma matriz
 *
 * \param mat int* : Matriz de entrada
 * \param M int : Número de linhas de mat
 * \param N int : Número de colunas de mat
 *
 */
void mostrarMatriz(int *mat, int M, int N)
{
	if (!mat) { printf("Oh pá! Cuidado a matriz e NULA!\n"); return; }
	int cont = 0;
	printf("\n\nA matriz mat tem %d linhas e %d colunas. O seu conteúdo é:\n", M, N);
	for (int i = 0; i < M; i++)
	{
		for (int j = 0; j < N; j++)
			printf(" %d", mat[cont++]);
	   printf("\n");
   }
}

/** \brief Destrói uma matriz
 *
 * \param mat int* : Matriz a destruir
 *
 */
void destruirMatriz(int *mat)
{
	if (mat != NULL) free(mat);
}

// Ex. 1

int esparsa(int *Matriz, int M, int N, float percentagem)
{
	// Inserir o código aqui


	
	
	
	return 1;
}

// Ex. 2
// alínea b)
void musicasDownLoad(Musica *lista, int n, int numD, int *nMusicasMaisNumDownloads)
{
	// Inserir o código aqui
	
	
	
	
}

// alínea c)
int numMusicasCantor(Musica *lista, int n, char *cantor)
{
	// Inserir o código aqui
	
	
	
	return 0;
}

// alínea d)
float gravaFichMusicas(Musica *lista, int n, int ano, char *nFichNome, char tpMeio)
{
	// Inserir o código aqui
	
	
	
	
	return 0.0;
}

// Ex. 3
// alínea b)
//Solução 1
//
int qtosPassam (Estudante *lista, int n)
{
	// Inserir o código aqui

	
	
	
	
	return 1;
}

// alínea c)
float numUcInfLim(Estudante *lista, int n, int lim)
{
	// Inserir o código aqui
	
	
	
	return 0.0;}

// alínea d)
void listaNotas(Estudante *lista, int n, int val, char *nomeFich)
{
	// Inserir o código aqui
	
	
	
	
}

// Ex. 4
// alínea b)
int indSaudaveis(Indiv *vet_ind, int n)
{
	// Inserir o código aqui
	
	
	
	
	return 0;
}

// alínea c)

float mediaMassCorp(Indiv *vet_ind, int n, int anoInf, int anoSup)
{
	// Inserir o código aqui
	
	
	
	return 0.0;
}


// alínea d)
int removeIndiv(Indiv *vet_ind, int *n, int nCC)
{
	// Inserir o código aqui
	
	
	
	
	
	
	return 0; // significa que o indivíduo não foi encontrado
}



