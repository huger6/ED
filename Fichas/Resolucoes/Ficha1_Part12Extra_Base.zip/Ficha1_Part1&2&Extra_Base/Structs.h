//
//  Structs.h
//  Ficha1_Part1&2&Extra_Base
//
//  Created by Jorge Loureiro on 04/03/2025.
//

#ifndef Structs_h
#define Structs_h

typedef struct
{
	int dia;
	int mes;
	int ano;
}DATA;

typedef struct
{
	char nome[70];
	char utilizador[20];
	char password[20];
	float joia;
	DATA data_registo;
	char email[30];
	char pagina_web_pessoal[50];
	int telemovel;
	int numero_acessos;
	DATA data_ultimo_acesso;
}REGISTO_UTILIZADORES, USER;

typedef struct edados
{
	int nElem;
	USER *dados;
}EDADOS;

typedef struct vNomes{
	char nome[70];
} V_NOMES;

#endif /* Structs_h */
