//
//  main.c
//  Ficha1_Part1&2&Extra_Base
//
//  Created by Jorge Loureiro on 04/03/2025.
//

#include "Structs.h"

#include "Includes.h"

#include "Funcs.h"

#define GERAR_FICHEIRO 1
#define NUM_REGISTOS_GERAR 10000

int main(void)
{
	setlocale(LC_ALL,"Portuguese"); /* para usar caracteres acentuados   */
	// variáveis para time.h
	clock_t start, end;
	double elapsed=0.0;
	//
	//ponteiro para struct que armazena data e hora
	struct tm *data_hora_atual;
	
	//variável do tipo time_t para armazenar o tempo em segundos
	time_t segundos;
	
	//obtendo o tempo em segundos
	time(&segundos);
	
	//para converter de segundos para o tempo local
	//utilizamos a função localtime
	data_hora_atual = localtime(&segundos);
	
	//para acessar os membros de uma struct usando o ponteiro
	//utilizamos o operador -> no nosso caso temos:
	//data_hora_atual->membro_da_struct
	
	//Acessando dados convertidos para a struct data_hora_atual
	printf("\nDia..........: %d\n", data_hora_atual->tm_mday);
	
	//para retornar o mês corretamente devemos adicionar +1
	//como vemos abaixo
	printf("\nMes..........: %d\n", data_hora_atual->tm_mon+1);
	
	//para retornar o ano corretamente devemos adicionar 1900
	//como vemos abaixo
	printf("\nAno..........: %d\n\n", data_hora_atual->tm_year+1900);
	
	printf("\nDia do ano...: %d\n", data_hora_atual->tm_yday);
	printf("\nDia da semana: %d\n\n", data_hora_atual->tm_wday);
	
	/* Obtendo os valores da struct data_hora_atual
	 e formatando a saída de dados no formato
	 hora: minuto: segundo
	 
	 Para não ficar um printf muito longo em uma única linha
	 de comando, quebrei a impressão em 3 partes mostrando
	 uma informação em cada linha
	 */
	printf("\nHora ........: %d:",data_hora_atual->tm_hour);//hora
	printf("%d:",data_hora_atual->tm_min);//minuto
	printf("%d\n",data_hora_atual->tm_sec);//segundo
	
	/* Obtendo os valores da struct data_hora_atual
	 e formatando a saída de dados no formato dia/mes/ano
	 
	 Para não ficar um printf muito longo em uma única
	 linha de comando, quebrei a impressão em 3 partes
	 sendo uma informação em cada linha
	 */
	//dia do mês
	printf("\nData ........: %d/", data_hora_atual->tm_mday);
	printf("%d/",data_hora_atual->tm_mon+1); //mês
	printf("%d\n\n",data_hora_atual->tm_year+1900); //ano
	
	int vectOrig=0; // se existe o dado edOrig e respectivo vector
	int vectCopia=0; // se existe o dado edCopia e vector respectivo
	int vectOrd=0; // se o vector de edCopia foi ordenado
	int opcao;
	int ano;
	
	char codUtil[20], nome[70], tpOrd;
	
	FILE *F=NULL;
	EDADOS *edOrig=NULL, *edCopia=NULL; // edOrig - Estrutura de dados com os dados originais (lidos do ficheiro);
	edOrig = criarEDados();   // é criada a estrutura da dados origem
	// edCopia - Estrutura de dados copiados da etOrig, usada depois para as ordenações
	// gerar os dados e gravá-los no ficheiro
	vectOrig=1;
	
	if(GERAR_FICHEIRO){  // se GERAR_FICHEIRO = 1, devem ser gerados os dados dos utilizadores e gravados no ficheiro
						 // depois do fich. ter os dados que se pretendem, colocar GERAR_FICHEIRO a 0.
		
		// gerarFicheiroSoParaTestes("Utilizadores.dat"); // Função criada para gerar os dados
		// dos utilizadores, neste caso, gerando todos os campos do utilizador, criando strings
		// concatenando strings pré-determinadas e rand()s ou rand()s (para campos numéricos).
		// Esta função não é utilizada, tendo sido substituída
		// pela função gerarFicheiro que utiliza nomes mais adequados, utilizando o ficheiro "nome.txt".
		
		// Atenção: na pasta (ou directório) onde está o programa executável
		// deve existir o ficheiro "nome.txt" (que contém 10000 nomes) que foi fornecido no
		// .zip onde existem também os ficheiros que constituem este projecto.
		gerarFicheiro("Utilizadores.dat");  // // Função criada para gerar os dados dos utilizadores
		//  neste caso, lendo o fich. nome.txt com 100000 nomes para utilizar como
		// nome dos nomes dos utilizadores (pois são mais adequados do que os gerados
		// com um nome simples (string base), à quela é acrescentado um dado aleatório).
		// Os restantes campos gerados criando strings, concatenando strings pré-determinadas
		// e rand()s ou apenas rand()s, se os campos forem numéricos.
	}
	
	do {  // ciclo que vai mostrar o menu sucessivamente e aceitar a opção,
		  // sendo depois activado o case correspondente à opção seleccionada
		opcao = menu_v2();
		switch(opcao)
		{
			case 1:
			{
				// Start measuring time
				start = clock();
				
				lerFicheiro(edOrig, (char *) "Utilizadores.dat");
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				//printf("Time measured: %.3f seconds.\n", elapsed);
				
				// Abrir o fich. "Tempos.csv" que se destina a guardar as estatístas relativas ao
				// tempo de execução das viversas funcionlidades.
				// Como esta é a primeira vez que o ficheiro é aberto no programa, ele é aberto em
				// modo de escrita, pois deverá ser recriado, se já existir, para que fique
				// a conter apenas as estatísticas relativas à execução actual da aplicação.
				F = fopen("Tempos.csv", "w");
				
				// Vai gravar as diversas estatísticas no ficheiro .csv
				
				//obter o tempo em segundos
				time(&segundos);
				
				//para converter de segundos para o tempo local
				//utiliza-se a função localtime
				data_hora_atual = localtime(&segundos);
				
				//Aceder aos dados convertidos para a struct data_hora_atual
				printf("\nDia..........: %d\n", data_hora_atual->tm_mday);
				
				//para retornar o mês corretamente deve-se adicionar +1
				printf("\nMes..........: %d\n", data_hora_atual->tm_mon+1);
				
				//para retornar o ano corretamente deve-se adicionar 1900
				printf("\nAno..........: %d\n\n", data_hora_atual->tm_year+1900);
				
				printf("\nHora ........: %d:",data_hora_atual->tm_hour);//hora
				printf("%d:",data_hora_atual->tm_min);//minuto
				printf("%d\n",data_hora_atual->tm_sec);//segundo
				
				fprintf(F,"Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao.\n");
				fprintf(F, "Acao.................................................\n");
				fprintf(F, "Execução do Programa na Data (AAAA/MM/DD): ; %4d/%2d/%2d\n", data_hora_atual->tm_year+1900, data_hora_atual->tm_mon+1, data_hora_atual->tm_mday);
				fprintf(F, "Executada sobre um vector com um num. de utilizadores; %d\n", NUM_REGISTOS_GERAR);
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao. \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Leitura do ficheiro Utilizadores.dat; %2d:%2d:%2d; Executada em %f segundos.\n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				fclose(F);
				break;
			}
			case 2:
			{
				if (vectCopia == 1) // se vectCopia estiver a true, o dado edCopia é apagado e recriado,
					// sendo, naturalmente, colocado vectCopia a false.
					// Estas operações apresentam-se infra:
				{
					libertarMemoria(edCopia);
					vectCopia=0;
				}
				
				// Start measuring time
				start = clock();
				
				// Colocar aqui a invocação da função apropriada e respectivo(s) parâmetro(s)
				// para criar o novo dado (edCopia)
				edCopia = criarEDados();
				
				// Colocar infra, a invocação da função duplicaDados para duplicar os dados e
				// respectivo(s) parâmetro(s), ou seja, copiar os dados originais
				// (do edOrig) para a copia (o edCopia)
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Cópia do vector lido do fich. ......; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				vectCopia=1; // já foi criado o edCopia e copiados os dados para ele
				vectOrd=0;  // o vectCopia ainda não foi ordenado
				break;
			}
			case 3:
			{
				// Start measuring time
				start = clock();
				if(vectCopia){
					// colocar aqui a invocação da função ordenarDados que irá
					// ordenar os dados do dado apropriado e respectivo(s) parâmetro(s)
					ordenarDados1(edCopia);
					// Obs.: não esquecer de colocar a true o dado que indica
					//       que a operação de ordenação já foi executada
					vectOrd=1;
				}
				else{
					printf("\nNão foi executada a opção 2, para criar a estrutura de dados edCopia e copiados os dados para lá.");
					printf("\nProceda à sua criação e cópia dos dados para ela, executando a opção.");
					break;
				}
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				F = fopen("Tempos.csv", "a"); // Abrir o fich. para append
				
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Orden. p/num. acessos c/ Bubble Sort; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				break;
			}
			case 4:
			{
				if(vectCopia==1){ // se vectCopia estiver a true, significa que
					// edCopia existe e também o respectivo vector
					// Vai-se libertar a memória que foi alocada para edCopia e o seu vector
					printf("\nA função libertar memória da estrutura edCopia devolveu o valor %d\n", libertarMemoria(edCopia));
					vectCopia=0; // indica que já não existe o edCopia
					vectOrd=0; // obviamente, se edCopia não existe, ele não pode estar ordenado
				}
				if(vectOrig){ // se vectOrig estiver a true, significa que
					// edOrig existe e também o respectivo vector
					// Vai-se libertar a memória que foi alocada para edOring e o seu vector
					printf("\nA função libertar memória da estrutura edOrig devolveu o valor %d\n", libertarMemoria(edOrig));
					vectOrig=0;  // o
				}
				// Obs.: Não se escrevem estatísticas, pois esta
				//       funcinalidade tem um tempo de execução irrelevante
				break;
			}
			case 5: // Listar dados do vector Origem (utilizadores lidos do ficheiro binário)
			{
				// Start measuring time
				start = clock();
				
				// Colocar aqui a invocação da função listarDados e respectivo(s) argumentos,
				// para listar os dados origem
				listarDados(edOrig, edOrig->nElem);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				//printf("Time measured: %.3f seconds.\n", elapsed);
				F = fopen("Tempos.csv", "a");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F,"Listagem dos utilizadores dos dados origem. Executada em %f segundos. \n", elapsed);
				fclose(F);
				break;
			}
			case 6: // Listar dados do vector Cópia (cópia do vector Origem, para executar as operações de ordenação, etc.)
			{
				{
					if(vectCopia && vectOrd){ // só serão listados os utilizadores ordenados
						// se o dado edCopia tiver dados e estes tiverem sido ordenados
						
						// Start measuring time
						start = clock();
						
						// Colocar infra a invocação da função listarDados, para listar os dados copia
						// e respectivo(s) argumentos
						listarDados(edCopia, edCopia->nElem);
						
						// Stop measuring time and calculate the elapsed time
						end = clock();
						elapsed = (double) (end - start)/CLOCKS_PER_SEC;
						
						//printf("Time measured: %.3f seconds.\n", elapsed);
						F = fopen("Tempos.csv", "a");
						//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
						fprintf(F,"Listagem dos utilizadores dos dados origem. Executada em %f segundos. \n", elapsed);
						fclose(F);
					}
					else{
						printf("\nOu não existem os dados cópia ou, se existirem, ainda não foram ordenados!! ");
						printf("\nProceda à sua criação e/ou ordenação da forma pretendida e liste depois.");
						limparBuffer;
						printf("\nDigite <Enter> para continuar...");
						getchar();
					}
					break;
				}
			}
				
			case 7:  // Contar o número de utilizadores que fizeram o último acesso num determinado ano
			{
				do{
					printf("Qual o ano de último acesso pretendido de que se pretenda sejam contados os utilizadores? ");
					scanf("%d", &ano);
				} while (ano<2010 && ano >2040);
				printf("\n");
				contarPessoasAcessoAno(edOrig, ano);
				limparBuffer;
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
			case 8: // Pesquisar utilizador por código (pesquisa linear)
			{
				printf("Qual o código do Utilizador? ");
				limparBuffer;
				fgets(codUtil, 19, stdin);
				// printf("\nTeste1... Cod. Utilizador: [%s]\n", codUtil);
				subst_CR_ou_LF_por_NULL_String(codUtil);
				// printf("\nTeste2... Cod. Utilizador: [%s]\n", codUtil);
				
				// Start measuring time
				start = clock();
				
				pesquisaLinearCod(edOrig, codUtil);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisa p/Cod, com pesquisa linear ; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				break;
			}
				
			case 9: // Pesquisar utilizador por nome (pesquisa linear)
			{
				printf("Qual o nome do Utilizador? ");
				limparBuffer;  // só para limpar o buffer do teclado
				fgets(nome, 70, stdin);
				subst_CR_ou_LF_por_NULL_String(nome);
				printf("\nOpção 9 - Nome do utilizador: [%s]\n", nome);
				
				// Start measuring time
				start = clock();
				
				pesquisaLinearNome(edOrig, nome);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisa p/Nome, com pesquisa linear; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				break;
			}
				
			case 10:  // Determinar a pessoa que fez mais acessos
			{
				pessoaMaisAcessos(edOrig);
				limparBuffer;
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
			case 11:  // Determinar a soma das jóias de todos os utilizadores
			{
				somarJoias(edOrig);
				limparBuffer;
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
			case 12: // Mês em que houve mais acessos
			{
				mesMaisAcessos(edOrig);
				limparBuffer;
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
				//-----------------------------------------------------------------------------
				// Funções para responder às alíneas b) e c) da parte Extras ------------------
				//-----------------------------------------------------------------------------
				
			case 13: // Ordenação por código (algoritmo Selecção Directa)
			{
				printf("Ordenação (a)scendente ou (d)escendente? ");
				scanf(" %c", &tpOrd);
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				
				// Start measuring time
				start = clock();
				
				sortSelecaoDirectaPCod(edCopia, tpOrd);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisar p/Cod., com Selec. Directa; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(edCopia->nElem<=1000)
				{
					listarDados(edCopia, edCopia->nElem);
					limparBuffer;
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				break;
			}
				
			case 14: // Ordenação por nome (algoritmo Selecção Directa)
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				
				printf("Ordenação (a)scendente ou (d)escendente? ");
				scanf(" %c", &tpOrd);
				
				// Start measuring time
				start = clock();
				
				sortSelecaoDirectaPNome(edCopia, tpOrd);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisar p/Nome, com Selec. Directa; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(edCopia->nElem<=1000)
				{
					listarDados(edCopia, edCopia->nElem);
					limparBuffer;
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				break;
			}
				
			case 15: // Ordenação por nome (algoritmo Inserção Directa)
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				printf("Ordenação (a)scendente ou (d)escendente? ");
				scanf(" %c", &tpOrd);
				
				// Start measuring time
				start = clock();
				
				sortInsercaoDirectaPNome(edCopia, edCopia->nElem, tpOrd);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisar p/Nome, com Inser. Directa; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(edCopia->nElem<=1000)
				{
					listarDados(edCopia, edCopia->nElem);
					limparBuffer;
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				
				break;
			}
				
			case 16: // Ordenação por código (algoritmo Shell Sort)
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				printf("Ordenação (a)scendente ou (d)escendente? ");
				scanf(" %c", &tpOrd);
				
				// Start measuring time
				start = clock();
				
				ShellSortV1PCod(edCopia, edCopia->nElem, tpOrd);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Ordenar p/Código, com Shell Sort....; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(edCopia->nElem<=1000)
				{
					listarDados(edCopia, 1000);
					limparBuffer;
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				break;
			}
				
			case 17: // Ordenação por nome (algoritmo Shell Sort)
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				printf("Ordenação (a)scendente ou (d)escendente? ");
				scanf(" %c", &tpOrd);
				
				// Start measuring time
				start = clock();
				
				ShellSortV1PNome(edCopia, edCopia->nElem, tpOrd);
				char a;
				scanf("%c", &a); // só para limpar o buffer do teclado
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Ordenar p/Nome, com Shell Sort......; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				if(edCopia->nElem<=1000)
				{
					listarDados(edCopia, 1000);
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				
				fclose(F);
				break;
			}
				
			case 18: // Pesquisa de um vector de forma binária iterativa por nome
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				tpOrd='a';
				ShellSortV1PNome(edCopia, edCopia->nElem, tpOrd); // executa a ordenação por nome, ascendente
				int index;
				char a;
				scanf("%c", &a); // só para limpar o buffer do teclado
				//gets(codUtil);
				printf("Qual o nome do Utilizador? ");
				fgets(nome, 70, stdin);
				subst_CR_ou_LF_por_NULL_String(nome);
				
				// Start measuring time
				start = clock();
				
				index=PesquisaBinariaPNome(edCopia, edCopia->nElem, nome);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisa p/Nome, pesq. bin. iterati.; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(index)
				{
					printf("\n--------------------------------------------\n");
					printf("Dados do utilizador de nome %s\n", edCopia->dados[index].nome);
					mostrarRegisto(&(edCopia->dados[index]));
				}
				//printf("O utilizador de código %s foi encontrado na posição %d do vector.\n", codUtil, index+1);
				else
				{
					printf("O utilizador de nome %s não foi encontrado!\n", nome);
				}
				
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
			case 19: // Pesquisa de um vector de forma binária recursiva por codigo
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				char tpOrd='a';
				ShellSortV1PCod(edCopia, edCopia->nElem, tpOrd); // executa a ordenação por código, ascendente
				int index;
				char a;
				scanf("%c", &a); // só para limpar o buffer do teclado
				printf("Qual o código do Utilizador? ");
				//gets(codUtil);
				fgets(codUtil, 19, stdin);
				subst_CR_ou_LF_por_NULL_String(codUtil);
				
				// Start measuring time
				start = clock();
				
				index=PesquisaBinariaRecPCod(edCopia, edCopia->nElem, 0, edCopia->nElem-1, codUtil);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisa p/Cod., pesq. bin. recursiva; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				
				if(index)
				{
					printf("\n--------------------------------------------\n");
					printf("Dados do utilizador de código %s\n", edCopia->dados[index].utilizador);
					mostrarRegisto(&(edCopia->dados[index]));
				}
				//printf("O utilizador de código %s foi encontrado na posição %d do vector.\n", codUtil, index+1);
				else
				{
					printf("O utilizador de código %s não foi encontrado!\n", codUtil);
				}
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
			case 20:
			{
				if (vectOrd == 1)
				{
					libertarMemoria(edCopia);
					vectOrd=0;
				}
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				vectOrd=1;
				char tpOrd='a';
				ShellSortV1PNome(edCopia, edCopia->nElem, tpOrd); // executa a ordenação por nome, ascendente
				int index;
				char a;
				scanf("%c", &a); // só para limpar o buffer do teclado
				printf("Qual o nome do Utilizador? ");
				// gets(nome);
				fgets(nome, 70, stdin);
				subst_CR_ou_LF_por_NULL_String(nome);
				// Start measuring time
				start = clock();
				
				index=PesquisaBinariaRecPNome(edCopia, edCopia->nElem, 0, edCopia->nElem-1, nome);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Tempos.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................; Hora de Início (HH:MM:SS); Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Pesquisa p/Nome, pesq. bin. recursiva; %2d:%2d:%2d; Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				//printf("Time measured: %.3f seconds.\n", elapsed);
				FILE *F = fopen("Tempos.csv", "a");
				fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F,"Pesquisa por nome de utilizador usando pesquisa binária recursiva; Executada em %f segundos. \n", elapsed);
				fclose(F);
				
				if(index)
				{
					printf("\n--------------------------------------------\n");
					printf("Dados do utilizador de nome %s\n", edCopia->dados[index].nome);
					mostrarRegisto(&(edCopia->dados[index]));
				}
				//printf("O utilizador de código %s foi encontrado na posição %d do vector.\n", codUtil, index+1);
				else
				{
					printf("O utilizador de nome %s não foi encontrado.\n", nome);
				}
				printf("\nDigite <Enter> para continuar...");
				getchar();
				break;
			}
				
			case 0:
			{
				printf("\n ###### FIM ######\n");
				break;
			}
				
			default:
			{
				break;
			}
		}
	} while( opcao != 0 );
	
	// destriuir as estruturas de dados criadas para guardar os dados em memória
	if (vectCopia==1)  // se a estrutura de dados de utilizadores (edCopia) foi criada e tem dados
		// colocar aqui a invocação da função libertarMemoria e respectivo(s) parâmetro(s)
		// para libertar a memória respectiva
		libertarMemoria(edCopia);
	if (vectOrig==1)  // se a estrutura de dados de utilizadores (edOrig) foi criada e tem dados
		// colocar aqui a invocação da função libertarMemoria e respectivo(s) parâmetro(s)
		// para libertar a memória respectiva
		libertarMemoria(edOrig);

	return 0;

}
