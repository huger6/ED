//
//  Includes.h
//  Ficha1_Part1&2&Extra
//
//  Created by Jorge Loureiro on 03/03/2025.
//

#ifndef Includes_h
#define Includes_h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <locale.h>

#endif /* Includes_h */
