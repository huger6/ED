//
//  funcs.c
//  Ficha1_Part1&2&Extra
//
//  Created by Jorge Loureiro on 03/03/2025.
//

#include "Structs.h"
#include "Includes.h"
#define NUM_REGISTOS_GERAR 10000


// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
//--------------------------------------
int gerarFicheiroSoParaTestes(char *nficheiro)
{
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < NUM_REGISTOS_GERAR; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%31;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 0: strcpy(nomeUt, "Rui_Correia"); break;
			case 1: strcpy(nomeUt, "Joao_Coelho"); break;
			case 2: strcpy(nomeUt, "Manuel_Abrantes"); break;
			case 3: strcpy(nomeUt, "Rui_Ferreira"); break;
			case 4: strcpy(nomeUt, "Alexandre_Pereira"); break;
			case 5: strcpy(nomeUt, "Ricardo_Leao"); break;
			case 6: strcpy(nomeUt, "Diana_Loureiro"); break;
			case 7: strcpy(nomeUt, "Rafaela_Tomas"); break;
			case 8: strcpy(nomeUt, "Dalila_do_Carmo"); break;
			case 9: strcpy(nomeUt, "Bruna_Lombardi"); break;
			case 10: strcpy(nomeUt, "Marilyn_Monroe"); break;
			case 11: strcpy(nomeUt, "Nicolau_da_Viola"); break;
			case 12: strcpy(nomeUt, "Rodrigo_Leao"); break;
			case 13: strcpy(nomeUt, "Carolina_Micaelis"); break;
			case 14: strcpy(nomeUt, "Mariana_Castelo"); break;
			case 15: strcpy(nomeUt, "Helena_Coelho"); break;
			case 16: strcpy(nomeUt, "Pedro_Mota"); break;
			case 17: strcpy(nomeUt, "Artur_Manuel"); break;
			case 18: strcpy(nomeUt, "Paulo_Albuquerque"); break;
			case 19: strcpy(nomeUt, "Hipocrates_Jurado"); break;
			case 20: strcpy(nomeUt, "David_Golias"); break;
			case 21: strcpy(nomeUt, "Rafael_Boino"); break;
			case 22: strcpy(nomeUt, "Jorge_Albuquerque"); break;
			case 23: strcpy(nomeUt, "Manuel_Cardoso"); break;
			case 24: strcpy(nomeUt, "Joana_Ferreira"); break;
			case 25: strcpy(nomeUt, "Teresa_do_Rosario"); break;
			case 26: strcpy(nomeUt, "Joaquim_Tome"); break;
			case 27: strcpy(nomeUt, "Paulo_Ribeiro"); break;
			case 28: strcpy(nomeUt, "Mariana_do_Chao"); break;
			case 29: strcpy(nomeUt, "Helena_de_Micenas"); break;
			case 30: strcpy(nomeUt, "Ulisses_o_Grego"); break;
			default: strcpy(nomeUt, "UmQualquer"); break;
		}
		sprintf(R->nome, "%s - %d", nomeUt, rand()%10000);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%14;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}


// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário - Versão 2
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
// Esta versão usa um ficheiro nomes.txt com 10000 nomes para ir buscar nomes para os utilizadores
//--------------------------------------
int geraChar(void){
	int nRand;
	do{
		nRand=rand()%123;
	} while(nRand>=33 && nRand <=122);
	printf("\nRand=%d", nRand);
	return nRand;
}

// Função que vai retirar o Enter que fica no final da string lida pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte, ficando "deslocado"
// A função procura o final de string ('\0'), e coloca outro ('\0') a sobrepôr o caracter anterior,
// onde está o Enter, eliminando-o.
void retiraEnterString(char *S){
	while(*S!='\0')
		S++;
	*(--S)='\0';
}

// Função que vai retirar o CR ou LF que podem ficar nos caracteres finais da string lida pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte, ficando "deslocado"
// A função procura o CR ou LF e o primeiro que encontrar substitui-o pelo valor 0 ('\0'),
// o final de string ('\0'), forçando o final da string logo depois dos caracteres "normais" da string.
void subst_CR_ou_LF_por_NULL_String(char *S){
	char *ptrCurr;
	ptrCurr=S;
	//printf("\nCaracteres de S: ");
	while(*S!=10 && *S!=13 && *S!=0){
		//printf("%d ", *S);
		S++;
	}
	if(*S==13 || *S==10){
		//printf("\n*S1=[%d]", *S);
		*S=0;
		S=ptrCurr;
    	//printf("\nCaracteres de S1: ");
/*		while(*S!='\n' && *S!='\0'){
			printf("%d ", *S);
			S++;
		}*/
		S=ptrCurr;
		//printf("\nA2 Nome = [%s]", S);
	}
}

// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário - Versão 2
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
// Esta versão usa um ficheiro nomes.txt com 10000 nomes para ir buscar nomes para os utilizadores
int gerarFicheiro(char *nficheiro)
{
	int i, nUt;
	FILE *fTxt = fopen("nome.txt", "r");  // ponteiro para usar para ler o fich. com os nomes
	if (!fTxt){
		printf("\nErro na abertura do ficheiro \"nome.txt\"");
		return 0;
	}
	
	V_NOMES vectNomes[NUM_REGISTOS_GERAR + 1];  // vector para ficar com os nomes lidos do ficheiro .txt
	for(i=0; i<NUM_REGISTOS_GERAR; i++){
		fgets(vectNomes[i].nome, 70, fTxt);
		//while(fscanf(fTxt, "%s", buff)!="\n")
		//	strcpy(vectNomes[i].nome, buff);
		//fscanf(fTxt, "[^\n]", vectNomes[i].nome);
		// printf("\nT1 Nome %d = [%s]", i+1, vectNomes[i].nome);
		retiraEnterString(vectNomes[i].nome); // retira o /n lido pelo fgets()
	}
	/*	for(i=0; i<50; i++){
		printf("\nT2 Nome %d = [%s]", i+1, vectNomes[i].nome);
	} */
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	// char nomeUt[20];
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < NUM_REGISTOS_GERAR; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%31;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 0: strcpy(nomeUt, "Rui"); break;
			case 1: strcpy(nomeUt, "Joao"); break;
			case 2: strcpy(nomeUt, "Manuel"); break;
			case 3: strcpy(nomeUt, "Rui"); break;
			case 4: strcpy(nomeUt, "Alexandre"); break;
			case 5: strcpy(nomeUt, "Ricardo"); break;
			case 6: strcpy(nomeUt, "Diana"); break;
			case 7: strcpy(nomeUt, "Rafaela"); break;
			case 8: strcpy(nomeUt, "Dalila"); break;
			case 9: strcpy(nomeUt, "Bruna"); break;
			case 10: strcpy(nomeUt, "Marilyn"); break;
			case 11: strcpy(nomeUt, "Nicolau"); break;
			case 12: strcpy(nomeUt, "Rodrigo"); break;
			case 13: strcpy(nomeUt, "Carolina"); break;
			case 14: strcpy(nomeUt, "Mariana"); break;
			case 15: strcpy(nomeUt, "Helena"); break;
			case 16: strcpy(nomeUt, "Pedro"); break;
			case 17: strcpy(nomeUt, "Artur"); break;
			case 18: strcpy(nomeUt, "Paulo"); break;
			case 19: strcpy(nomeUt, "Hipocrates"); break;
			case 20: strcpy(nomeUt, "David"); break;
			case 21: strcpy(nomeUt, "Rafael"); break;
			case 22: strcpy(nomeUt, "Jorge"); break;
			case 23: strcpy(nomeUt, "Manuel"); break;
			case 24: strcpy(nomeUt, "Joana"); break;
			case 25: strcpy(nomeUt, "Teresa"); break;
			case 26: strcpy(nomeUt, "Joaquim"); break;
			case 27: strcpy(nomeUt, "Paulo"); break;
			case 28: strcpy(nomeUt, "Mariana"); break;
			case 29: strcpy(nomeUt, "Helena"); break;
			case 30: strcpy(nomeUt, "Ulisses"); break;
			default: strcpy(nomeUt, "UmQualquer"); break;
		}
		nUt=rand()%50000;
		// printf("\nNome: %s", vectNomes[i].nome);
		//getchar();
		sprintf(R->nome, "%s", vectNomes[i].nome);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		// printf("\nR->utilizador: %s", R->utilizador);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%12;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

// Função para mostrar o menu e aceitar a opção (a usar para as partes 1 e 2 da ficha 1)
int menu(void)
{
	int opcao;
	//system("cls") ou system("clear");
	printf("\n #---------------------------------------------------------#");
	printf("\n | (1) Ler de Ficheiro                                     |");
	printf("\n | (2) Copiar os dados originais para outro vector         |");
	printf("\n | (3) Ordenar vector copiado por número de acessos        |");
	printf("\n | (4) Libertar memória                                    |");
	printf("\n | (5) Listar utilizadores (vector original)               |");
	printf("\n | (6) Listar utilizadores (depois de ordenados)           |");
	printf("\n | (7) Contar num. utiliz. com último acesso num dado ano  |");
	printf("\n | (8) Pesquisar utilizador por código (pesquisa linear)   |");
	printf("\n | (9) Pesquisar utilizador por nome (pesquisa linear)     |");
	printf("\n | (10) Procurar a pessoa que fez mais acessos             |");
	printf("\n | (11) Determinar a soma de todas as 'joias'              |");
	printf("\n | (12) Determinar qual o mês em que houve mais acessos    |");
	printf("\n +---------------------------------------------------------+");
	printf("\n | (0) Sair                                                |");
	printf("\n #---------------------------------------------------------#");

	do {
		printf("\nQual a sua opcao: ");
		scanf("%d", &opcao);
	} while (opcao < 0 || opcao > 12);
	return opcao;
}
//----------------------------------------------------------------------------------------
// Função para mostrar o menu e aceitar a opção (versão 2, 
// já com as opções relativas à parte 2 e às alíneas b) e c) da parte "Extras"
//----------------------------------------------------------------------------------------
int menu_v2(void)
{
	int opcao;
	//system("cls") ou system("clear");
	printf("\n #---------------------------------------------------------#");
	printf("\n | (1) Ler de Ficheiro                                     |");
	printf("\n | (2) Copiar os dados originais para outro vector         |");
	printf("\n | (3) Ordenar vector copiado por número de acessos        |");
	printf("\n | (4) Libertar memória                                    |");
	printf("\n | (5) Listar utilizadores (vector original)               |");
	printf("\n | (6) Listar utilizadores (depois de ordenados)           |");
	printf("\n | (7) Contar num. utiliz. com último acesso num dado ano  |");
	printf("\n | (8) Pesquisar utilizador por código (pesquisa linear)   |");
	printf("\n | (9) Pesquisar utilizador por nome (pesquisa linear)     |");
	printf("\n | (10) Procurar a pessoa que fez mais acessos             |");
	printf("\n | (11) Determinar a soma de todas as 'joias'              |");
	printf("\n | (12) Determinar qual o mês em que houve mais acessos    |");
	printf("\n +---------------------------------------------------------+");
	printf("\n | (13) Ordenar p/ utiliz. p/ código (Selecção Directa)    |");
	printf("\n | (14) Ordenar p/ utiliz. p/ nome (Selecção Directa)      |");
	printf("\n | (15) Ordenar p/ utiliz. p/ nome (Inserção Directa)      |");
	printf("\n | (16) Ordenar p/ utiliz. p/ código (Shell Sort)          |");
	printf("\n | (17) Ordenar p/ utiliz. p/ nome (Shell Sort)            |");
	printf("\n | (18) Pesquisar utiliz. p/ nome (Pesq. bin. iterativa)   |");
	printf("\n | (19) Pesquisar utiliz. p/ codigo (Pesq. bin. recursiva) |");
	printf("\n | (20) Pesquisar utiliz. p/ nome (Pesq. bin. recursiva)   |");
	printf("\n +---------------------------------------------------------+");
	printf("\n | (0)  Sair                                               |");
	printf("\n #---------------------------------------------------------#");

	do {
		printf("\nQual a sua opcao: ");
		scanf("%d", &opcao);
	} while (opcao < 0 || opcao > 20);
	return opcao;
}


// Ex. 1, opção 1 - Ler ficheiro
// Versão 1
/*
 Função: lerFicheiro
 Parâmetros: ed - ponteiro para a estrutura de dados onde vão ser carregados os dados;
			 nficheiro – nome do ficheiro a ler
 Descrição: Dado o nome do ficheiro (parâmetro nficheiro),
			a função vai ler para memória (para a estrutura apontada por ed) os dados do ficheiro,
			colocando também em nElem o número de registos lidos
 Retorno: 0 (se houver erro); 1 (caso não haja erro)
 */
//---------------------------------------
int lerFicheiro(EDADOS *ed, char *nficheiro)  // versão da aula
{
	//AvisoParaAluno;
	int N;
	FILE *f = fopen(nficheiro, "rb");
	if(!f){
		perror("Erro na abertura do ficheiro");
		return 0;
	}
	fseek(f, 0, SEEK_END); // mover o ponteiro do ficheiro para o fim
	// Calcular o número de registos (N) que se encontram no ficheiro
	N = (int) ftell(f) / sizeof(REGISTO_UTILIZADORES);
	ed->nElem = N;
	ed->dados = (REGISTO_UTILIZADORES *)malloc(ed->nElem * sizeof(REGISTO_UTILIZADORES));
	fseek(f, 0, SEEK_SET); // Mover o ponteiro do ficheiro para o início
	// ler todos os dados do ficheiro para o bloco de memória apontado por ed->dados;
	fread(ed->dados, sizeof(REGISTO_UTILIZADORES), ed->nElem, f);
	// Se fosse pretendido mostar os registos lidos, um a um, ter-se-ia:
	//    REGISTO_UTILIZADORES *pinicio = ed->dados;
	/*for(int i=0; i<ed->nElem; i++)
	{
		printf("Registo leitura %d: data: %d/%d/%d\n", i+1, ed->dados[i].data_registo.dia, ed->dados[i].data_registo.mes, ed->dados[i].data_registo.ano);
		printf("Nome: %s\n", ed->dados[i].nome);
	}*/
	//ed->dados = pinicio;
	fclose(f);
	return 1;
}

// Função criarEDados que vai
// para criar a estrutura ED (do tipo EDADOS) e inicializá-la
//---------------------------------------
EDADOS *criarEDados(void)
{
	EDADOS *ED = (EDADOS *)malloc(sizeof(EDADOS));
	ED->nElem = 0;
	ED->dados = NULL;
	return ED;
}

// Função correspondente ao ex. 2, opção 2 do menu (duplicaDados) que vai usar a função criarEDados
// para criar a nova estrutura para guardar a cópia da estrutura de dados original
// Vai copiar os dados do vector origem (com os dados lidos do ficheiro)
// para um novo vector, usado depois para ser ordenado
//---------------------------------------
EDADOS * duplicaDados(EDADOS *edOrig)
{
	int i=0;
	if ((!edOrig) || (!edOrig->dados)) return NULL;// Retorna NULL, significando que não há dados.
	
	EDADOS * edDest;
	edDest = criarEDados();
	edDest->dados = (REGISTO_UTILIZADORES *)malloc(edOrig->nElem * sizeof(REGISTO_UTILIZADORES));
	edDest->nElem=edOrig->nElem;
	for(i=0; i<edOrig->nElem; i++) // copiar o vector original para o vector destino (a ordenar)
	{
		edDest->dados[i] = edOrig->dados[i];
	}
	return edDest;
}

/*
 Funcao: ordenarDados;
 Parâmetros: dados dos utilizadores (a cópia gerada com a função duplicaDados);
 Descrição: Permite ordenar o vector dos dados; utilizou-se o alg. BubbleSort;
 O vector dos dados recebido é ordenado, ficando portanto disponível na função chamante;
 Retorno: 0 (se houver erro); 1 (caso não haja erro);
 */
//---------------------------------------
int ordenarDados(EDADOS *ed)  // versão da aula
{
	int i,j;
	// Colocar aqui o código correspondente à função de ordenar dados
	if((!ed) || (!ed->dados)){
		printf("\nNão há dados para ordenar!");
		return 0;
	}
	// Vai usar-se o algoritmo bubble sort
	for(i=0; i<ed->nElem; i++){
		for(j=0; j< (ed->nElem-1-i); j++){
			if(ed->dados[j].numero_acessos > ed->dados[j+1].numero_acessos){
				REGISTO_UTILIZADORES aux = ed->dados[j];
				ed->dados[j] = ed->dados[j+1];
				ed->dados[j+1]=aux;
			}
		}
	}
	return 1;
}

/*
 Funcao: ordenarDados1 (de funcionalidade igual à ordenarDados, mas utilizando ponteiros na manipulação de dados);
 Parâmetros: dados dos utilizadores (a cópia gerada com a função duplicaDados);
 Descrição: Permite ordenar o vector dos dados; utilizou-se o alg. BubbleSort;
 O vector dos dados recebido é ordenado, ficando portanto disponível na função chamante;
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */
//---------------------------------------
int ordenarDados1(EDADOS *ed)  // versão com ponteiros
{
	int k;
	//AvisoParaAluno;
	if ((!ed) || (!ed->dados)) return 0;  // Retorna 0, significando que não há dados.
	
	for (k = 0; k < ed->nElem; k++)
	{
		for (int i = 0; i < (ed->nElem - 1 - k); i++)
		{
			if ((ed->dados+i)->numero_acessos > (ed->dados+i+1)->numero_acessos)
			{
				REGISTO_UTILIZADORES aux = *(ed->dados+i);
				*(ed->dados+i) = *(ed->dados+i+1);
				*(ed->dados+i + 1) = aux;
			}
		}
	}
	return 1;
}

// Função correspondente ao ex. 4, opção 4 do menu
// (libertar toda a memória alocada, relativa a uma det. estrutura).
// Função: libertarMemoria
// Parâmetro: ed - ponteiro para a estrutura de dados a ser libertada
// Retorno: 0 (se houver erro); 1 (caso não haja erro).
//---------------------------------------
int libertarMemoria(EDADOS *ed)
{
	// Colocar aqui o código correspondente à função requerida
	if(!ed)
		return 0; // Retorna 0, significando que não há memória alocada
	if(ed->dados !=NULL) // há dados no vector
		free(ed->dados); // liberta o bloco de memória do vector
	free(ed); // liberta a memória alocada para ed
	return 1;  // retorna 1, significando que a operação foi bem sucedida
}

// Ex. 5 e 6, opção 5 e 6.
// Nas opções 5 e 6 é invocada a função listarDados.
// Esta função vai percorrer o vector de utilizadores
// que está incluido no dado especificado pelo ponteiro ed e,
// para cada um dos elementos, vai invocar a função mostarRegisto
// (apresentada já a seguir, que apresenta no ecrã o utilizador
// correspondente ao ponteiro que lhe é passado como parâmetro.

// Esta função vai mostrar no ecran a informação correspondente a cada registo de utilizador
// dados é o ponteiro para o registo a mostrar
void mostrarRegisto(REGISTO_UTILIZADORES *dados)
{
	// Dica: Esta função não é mais do que uma sucessão de linhas
	// com printf(...), cada uma para mostar um atributo do utilizador
	// Sugere-se que a 1.ª linha seja uma linha com "----" para separar
	// a informação relativa a cada utilizador que já se inclui a seguir.
	
	printf("--------------------------------------------\n");
	printf("Utilizador = %s\n", dados->utilizador);
	printf("Nome = %s\n", dados->nome);
	printf("Password = %s\n", dados->password);
	printf("Data de Registo = %d/%d/%d\n", dados->data_registo.dia, dados->data_registo.mes, dados->data_registo.ano);
	printf("e-Mail = %s\n", dados->email);
	printf("Página Web Pessoal = %s\n", dados->pagina_web_pessoal);
	printf("Telemóvel = %d\n", dados->telemovel);
	printf("Número de Acessos = %d\n", dados->numero_acessos);
	printf("Data de Último Acesso = %d/%d/%d\n", dados->data_ultimo_acesso.dia, dados->data_ultimo_acesso.mes, dados->data_ultimo_acesso.ano);
}

/*
 Funcao: listarDados
 Parâmetros: ed - Dado que contém a informação do número de utilizadores
 existentes e também outra necessária ao acesso da informação respectiva;
 nRegAMostrar - número de registos que se pretende sejam mostrados
 (iniciando no primeiro (0));
 Descrição: Percorre os utilizadores (iniciando pelo 1.º) e,
 para cada utilizador, vai invocar a função mostarRegisto que
 vai apresentar no monitos a informação relativa ao utilizador.
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */
int listarDados(EDADOS *ed, int nRegAMostrar)
{
	int i;
	if ((!ed) || (!ed->dados)) return 0;  // Retorna 0, significando que não há dados.
	
	if (nRegAMostrar > ed->nElem)
		nRegAMostrar=ed->nElem;
	
	printf("\n--------------------------------------------\n");
	printf("\nOpção 5 ou 6 - Número de utilizadores a listar: %d\n", nRegAMostrar);
	
	for (i = 0; i < nRegAMostrar; i++)
	{
		mostrarRegisto(&(ed->dados[i])); // &((ed->dados[i]) é o endereço do utilizador a mostrar
	}
	return 1;
}

// Ex. 8, opção 7
/*
 Funcao: contarPessoasAcessoAno
 Parametros: ed - dados dos utilizadores; ano - ano a considerar para a contagem do 
				  número de pessoas que fizeram um último acesso nesse ano;
 Descrição: Vai contar o número de utilizadores que fizeram o último acesso no ano indicado pelo parâmetro ano.
			Mostra o núemro no ecrã e também retorna esse valor;
 Retorno: retorna o número de pessoas que fizeram o último acesso no ano indicado pelo parâmetro ano
		  ou -1, caso não haja dados.
 */

int contarPessoasAcessoAno(EDADOS *ed, int ano)
{
	if ((!ed) || (!ed->dados)) return 0;// Retorna 0, significando que não há dados.
	
	int cont = 0;
	for (int i = 0; i < ed->nElem; i++)
	{
		if (ed->dados[i].data_ultimo_acesso.ano == ano)
			cont++;
	}
	printf("\nOpção 7 - O número de pessoas que fizeram um último acesso no ano [%d] foi de [%d]\n", ano, cont);
	return cont;
}


// Ex. 9, opção 8
/*
 Funcao: pesquisaLinearPorCodigo
 Parametros: ed - dados dos utilizadores; codUtil - código do utilizador a procurar pesquisar e mostrar (se encontrado);
 Descrição: Vai procurar e mostrar a informação relativa ao utilizador especificado no parâmetro (se encontrado)
		    ou informa que o utilizador não existe;
 Retorno: retorna -1, se o utilizador não for ewncontrado e 1, de contrário.
 */
//-----------------------------
int pesquisaLinearCod(EDADOS *ed, char *codUtil)
{
	//AvisoParaAluno;
	int i;
	if ((!ed) || (!ed->dados)) return 0;// Retorna 0, significando que não há dados.
	for (i = 0; i < ed->nElem; i++)
	{
		// printf("\nTT1 Cod.Utilizador: [%s]\n", ed->dados[i].utilizador);
		// printf("\nTT2 Cod.Utilizador: [%s]\n", codUtil);

		if (strcmp(ed->dados[i].utilizador, codUtil) == 0)
		{
			printf("\nOpção 8 ------------------------------------\n");
			printf("Dados do utilizador de código %s:\n", ed->dados[i].utilizador);
			mostrarRegisto(&(ed->dados[i]));
			printf("\nDigite <Enter> para continuar...");
			getchar();
			return 1;
		}
	}
	printf("\nO utilizador de código %s não existe!\n", codUtil);
	printf("\nDigite <Enter> para continuar...");
	getchar();
	
	return -1;  // Retorna -1, significando que o utilizador não foi encontrado.
}

// Ex. 10, opção 9
/*
 Funcao: pesquisaLinearNome
 Parametros: ed - dados dos utilizadores; nomeUtil - nome do utilizador a procurar pesquisar e mostrar (se encontrado);
 Descrição: Vai procurar e mostrar a informação relativa ao utilizador especificado no parâmetro (se encontrado)
			ou informa que o utilizador não existe;
 Retorno: retorna -1, se o utilizador não for ewncontrado e 1, de contrário.
 */
//-----------------------------
int pesquisaLinearNome(EDADOS *ed, char *nomeUtil)
{
	//AvisoParaAluno;
	int i;
	if ((!ed) || (!ed->dados)) return 0;// Retorna 0, significando que não há dados.
	
	for (i = 0; i < ed->nElem; i++)
	{
		// printf("\nTT3 Nome do Utilizador: [%s]\n", ed->dados[i].nome);
		// printf("\nTT4 Nome do Utilizador: [%s]\n", nomeUtil);
		if (strcmp(ed->dados[i].nome, nomeUtil) == 0)
		{
			printf("\nOpção 9 ------------------------------------\n");
			printf("Dados do utilizador de nome [%s]:\n", ed->dados[i].nome);
			mostrarRegisto(&(ed->dados[i]));
			printf("\nDigite <Enter> para continuar...");
			getchar();
			//scanf(" %c", &op);
			return 1;
		}
	}
	printf("\nO utilizador de nome [%s], não existe!!!\n", nomeUtil);
	printf("\nDigite <Enter> para continuar...");
	getchar();
	return -1; // Retorna -1, significando que o utilizador não foi encontrado.
}

// Ex. 11, opção 10
/*
 Funcao: pessoaMaisAcessos
 Parametros: ed - dados dos utilizadores;
 Descrição: Vai procurar a pessoa que fez mais acessos e mostra o seu nome e o número de acessos efectuado;
 Retorno: retorna -1, se ed ou dados estiverem a NULL (há erro) e 1, de contrário (foi mostrada a pessoa e o número de acessos).
 */
//-----------------------------
int pessoaMaisAcessos(EDADOS *ed)
{
	int i;
	if ((!ed) || (!ed->dados)) return 0;  // Retorna 0, significando que não há dados.
	
	int pos = 0;
	int max = ed->dados[pos].numero_acessos;
	for (i = 1; i < ed->nElem; i++)
	{
		if (ed->dados[i].numero_acessos > max)
		{
			max = ed->dados[i].numero_acessos;
			pos = i;
		}
	}
	printf("\nOpção 10 - A pessoa que fez mais acessos foi %s, tendo efectuado %d acessos.\n",
												ed->dados[pos].nome, ed->dados[pos].numero_acessos);
	return 1;
}

// Ex. 12, opção 11
/*
 Funcao: somarJoias
 Parametros: ed - dados dos utilizadores;
 Descrição: Função para calcular e mostrar o valor da soma das joias entregues por todos os utilizadores;
 Retorno: retorna -1, se ed ou dados estiverem a NULL (há erro) e somaJoias, de contrário.
 */
//-----------------------------
float somarJoias(EDADOS *ed)
{
	int i;
	if ((!ed) || (!ed->dados)) return 0;// Retorna 0, significando que não há dados.
	
	float somaJoias=0.0f;
	for (i = 1; i < ed->nElem; i++)
	{
		somaJoias+=ed->dados[i].joia;
	}
	printf("Opção 11 - A soma das joias entregues pelos utilizadores é: %.2f€\n", somaJoias);
	return somaJoias;
}

// Ex. 13, opção 12
/*
 Funcao: mesMaisAcessos
 Parametros: ed - dados dos utilizadores;
 Descrição: função que calcula e mostra no ecrã o mês em que foram realizados mais acessos e o número de acessos respectivos;
 Retorno: retorna -1, se ed ou dados estiverem a NULL (há erro) e o mês em que ocorreram mais acessos
		  (sendo 1-Janeiro, ..., 12-Dezembro), de contrário.
 */
//-----------------------------
int mesMaisAcessos(EDADOS *ed)
{
	if ((!ed) || (!ed->dados)) return 0;// Retorna 0, significando que não há dados.
	
	int meses[12];
	for (int i = 0; i < 12; i++)
		meses[i] = 0;
	for (int i = 0; i < ed->nElem; i++)
		meses[ed->dados[i].data_ultimo_acesso.mes-1]++;
	
	int mes_maior = 0;
	for (int i = 1; i < 12; i++)
		if (meses[i] > meses[mes_maior])
			mes_maior = i;
	printf("Opção 12 - O Mes [%d] foi aquele em que foram realizados mais acessos, sendo o número de acesssos: %d\n",
		   mes_maior+1, meses[mes_maior]);
	return mes_maior + 1;
}

//----------------------------------------------------------------------------
// Funções para responder às alíneas b) e c da parte Extras ------------------
//----------------------------------------------------------------------------

// alínea b) da parte Extras - 1.º exemplo - Ordenação usando a selecção directa e ordenar por código,
//          								 ordenação ascendente ou descendente.
// Opção 13
void trocaElemVector(EDADOS *ed, int index1, int index2)
{
	REGISTO_UTILIZADORES aux;
	aux= ed->dados[index1];
	ed->dados[index1] = ed->dados[index2];
	ed->dados[index2] = aux;
}

void sortSelecaoDirectaPCod(EDADOS *ed, char tpOrd)
{
	if ((!ed) || (!ed->dados)) return;  // / Termina a execução da função, pois não há dados a ordenar.

	int i, j, pos;
	// vai ordenar o vector
	for (i = ed->nElem - 1; i > 0; i--)
	{
		pos = i;
		for (j = 0; j <= i - 1; j++)
		{
			if (tpOrd == 'a')
			{
				if (strcmp(ed->dados[j].utilizador, ed->dados[pos].utilizador)>0)
					pos = j;
			}
			else
				if (strcmp(ed->dados[j].utilizador, ed->dados[pos].utilizador)<0)
					pos = j;
		}
		trocaElemVector(ed, i, pos);
	}
}

//  alínea b) da parte Extras - 2.º exemplo - Ordenação usando a selecção directa e ordenar por nome,
//          								 ordenação ascendente ou descendente.
// Opção 14
void sortSelecaoDirectaPNome(EDADOS *ed, char tpOrd)
{
	if ((!ed) || (!ed->dados)) return;  // / Termina a execução da função, pois não há dados a ordenar.
	int i, j, pos;
	// vai ordenar o vector
	for (i = ed->nElem - 1; i > 0; i--)
	{
		pos = i;
		for (j = 0; j <= i - 1; j++)
		{
			if(tpOrd == 'a')
			{
				if (strcmp(ed->dados[j].nome, ed->dados[pos].nome)>0)
					pos = j;
			}
			else if (tpOrd == 'd')
				if (strcmp(ed->dados[j].nome, ed->dados[pos].nome)<0)
					pos = j;
		}
		trocaElemVector(ed, i, pos);
	}
}

//  alínea b) da parte Extras - 3.º exemplo - Ordenação usando a inserção directa e ordenar por nome,
//          								 ordenação ascendente ou descendente.
// Opção 15
void sortInsercaoDirectaPNome(EDADOS *ed, int tam, char tpOrd)
{
	if ((!ed) || (!ed->dados)) return;  // / Termina a execução da função, pois não há dados a ordenar.
	// vai ordenar o vector
	REGISTO_UTILIZADORES tmp;
	int i, j;
	for (i = 1; i < tam; i++)
	{
		tmp = ed->dados[i];
		j = i;
		if(tpOrd == 'a')
		{
			while (j > 0 && strcmp(ed->dados[j - 1].nome, tmp.nome)>0)
			{
				ed->dados[j] = ed->dados[j - 1];
				j--;
			}
		}
		else
		{
			while (j > 0 && strcmp(ed->dados[j - 1].nome, tmp.nome)<0)
			{
				ed->dados[j] = ed->dados[j - 1];
				j--;
			}
		}
		ed->dados[j] = tmp;
	}
}

/*
	void ShellSortV2(tabela vect, int N)
	{
		  if ((!ed) || (!ed->dados)) return;  // / Termina a execução da função, pois não há dados a ordenar.
 
		  int inner, h=1;
		  dado temp;
		  // procurar o maior valor h possivel
		  while (h <= N / 3)
			   h = h * 3 + 1;
		  while (h > 0)
		  {
			   for (int outer = h; outer <= N - 1; outer++)
			   {
				   temp = vector[outer];
				   inner = outer;
				   while ((inner > h - 1) && vector[inner - h] >= temp)
				   {
					   vector[inner] = vector[inner - h];
					   inner - = h;
					}
					vector[inner] = temp;
			   }
			   h = (h - 1) / 3;
		  }
	}
*/
	
	
	
/*
// método para ordenar um vector por nome pelo método ShellSort Versão 1 por nome
void ShellSortV1PNome(EDADOS *ed, int tam, char tpOrd)
{
    if ((!ed) || (!ed->dados)) return;  // / Termina a execução da função, pois não há dados a ordenar.
 
	int inner;
	REGISTO_UTILIZADORES temp;
	int h = 1;
	// find the largest  value possible
	while (h <= tam / 3)
		h = h * 3 + 1;
	while (h > 0)
	{
		for (int outer = h; outer <= tam - 1; outer++)
		{
			temp = ed->dados[outer];
			inner = outer;
			// while ((inner > h - 1) && vectP[inner - h].num >= temp.num)
			if(tpOrd == 'a')
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].nome, temp.nome)>0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			else
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].nome, temp.nome)<0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			ed->dados[inner] = temp;
		}
		h = (h - 1) / 3;
	}
}
*/
//  alínea b) da parte Extras - 4.º exemplo - Ordenação usando o algoritmo Shell Sort, ordenando por código,
//          								 ordenação ascendente ou descendente.
// Opção 16
// método para ordenar um vector por códigopelo método ShellSort Versão 1
void ShellSortV1PCod(EDADOS *ed, int tam, char tpOrd)
{
	if ((!ed) || (!ed->dados)) return; // Termina a execução da função, pois não há dados a ordenar.
	
	int inner;
	REGISTO_UTILIZADORES temp;
	int h = 1;
	// find the largest  value possible
	while (h <= tam / 3)
		h = h * 3 + 1;
	while (h > 0)
	{
		for (int outer = h; outer <= tam - 1; outer++)
		{
			temp = ed->dados[outer];
			inner = outer;
			// while ((inner > h - 1) && vectP[inner - h].num >= temp.num)
			if(tpOrd == 'a')
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].utilizador, temp.utilizador)>0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			else
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].utilizador, temp.utilizador)<0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			ed->dados[inner] = temp;
		}
		h = (h - 1) / 3;
	}
}

//  alínea b) da parte Extras - 5.º exemplo - Ordenação usando o algoritmo Shell Sort, ordenando por nome,
//          								 ordenação ascendente ou descendente.
// Opção 16
void ShellSortV1PNome(EDADOS *ed, int tam, char tpOrd)
{
	if ((!ed) || (!ed->dados)) return;// Termina a execução da função, pois que não há dados.
	
	int inner, h=1, outer=0;
	REGISTO_UTILIZADORES temp;
	// procurar o maior valor h possivel
	while (h <= tam / 3)
		h = h * 3 + 1;
	while (h>0)
	{
		for (outer = h; outer <= tam - 1; outer++)
		{
			temp = ed->dados[outer];
			inner = outer;
			if(tpOrd == 'a')
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].nome, temp.nome)>0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			else
			{
				while ((inner > h - 1) && strcmp(ed->dados[inner - h].nome, temp.nome)<0)
				{
					ed->dados[inner] = ed->dados[inner - h];
					inner -= h;
				}
			}
			ed->dados[inner] = temp;
		}
		h = (h - 1) / 3;
	}
}

//  alínea c) da parte Extras - 1.º exemplo -  Pesquisa de um vector de forma binária iterativa por nome
// Opção 18

int PesquisaBinariaPNome(EDADOS *ed, int tamVect, char *chave)
{
	int indInf = 0, indMeio, indSup = tamVect - 1;
	while (indSup>=indInf)
	{
		indMeio = (indInf + indSup) / 2;
		if (strcmp(ed->dados[indMeio].nome, chave)==0)
			return indMeio;
		else
		{
			if (strcmp(ed->dados[indMeio].nome, chave) <0)
				indInf = indMeio + 1;
			else
				indSup = indMeio -1;
		}
	}
	return -1;
}

//  Alínea c) da parte Extras - 1.º exemplo -  Pesquisa de um vector de forma binária iterativa por nome
//  versão que usa ponteiros
//  Opção 18 (trocar a função invocada no case 18: do main() - acrescentar "_v2").

int PesquisaBinariaPNome_v2(EDADOS *ed, int tamVect, char *chave)
{
	int indInf = 0, indMeio, indSup = tamVect - 1;
	while (indSup>=indInf)
	{
		indMeio = (indInf + indSup) / 2;
		if (strcmp((ed->dados+indMeio)->nome, chave)==0)
			return indMeio;
		else
		{
			if (strcmp((ed->dados+indMeio)->nome, chave) <0)
				indInf = indMeio + 1;
			else
				indSup = indMeio -1;
		}
	}
	return -1;
}

//  Alínea c) da parte Extras - 2.º exemplo -  Pesquisa de um vector de forma binária recursiva por codigo
//      									   (neste caso é um a string)
//  Opção 19

int PesquisaBinariaRecPCod(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave)
{
	if (indInf > indSup)
		return -1;
	else
	{
		int indMeio;
		indMeio = (int)(indInf + indSup) / 2;
		if ( strcmp(chave, ed->dados[indMeio].utilizador)<0)
			return PesquisaBinariaRecPCod(ed, ed->nElem, indInf, indMeio - 1, chave);
		else if (strcmp(ed->dados[indMeio].utilizador, chave)==0)
			return indMeio;
		else
			return PesquisaBinariaRecPCod(ed, ed->nElem, indMeio + 1, indSup, chave);
	}
}

//  Alínea c) da parte Extras - 3.º exemplo -  Pesquisa de um vector de forma binária recursiva por nome
//  Opção 20

int PesquisaBinariaRecPNome(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave)
{
	if (indInf > indSup)        return -1;
	else
	{
		int indMeio;
		indMeio = (int)(indInf + indSup) / 2;
		if ( strcmp(chave, ed->dados[indMeio].nome)<0)
			return PesquisaBinariaRecPNome(ed, ed->nElem, indInf, indMeio - 1, chave);
		else if (strcmp(ed->dados[indMeio].nome, chave)==0)
			return indMeio;
		else
			return PesquisaBinariaRecPNome(ed, ed->nElem, indMeio + 1, indSup, chave);
	}
}

//  Alínea c) da parte Extras - 3.º exemplo -  Pesquisa de um vector de forma binária recursiva por nome
//  Opção 20, mas é uma versão que usa ponteiros
//  Opção 20 (trocar a função invocada no case 20: do main() - acrescentar "_v2").
int PesquisaBinariaRecPNome_v2(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave)
{
	if (indInf > indSup)        
		return -1;
	else
	{
		int indMeio;
		indMeio = (int)(indInf + indSup) / 2;
		if ( strcmp(chave, (ed->dados+indMeio)->nome)<0)
			return PesquisaBinariaRecPNome(ed, ed->nElem, indInf, indMeio - 1, chave);
		else if (strcmp((ed->dados+indMeio)->nome, chave)==0)
			return indMeio;
		else
			return PesquisaBinariaRecPNome(ed, ed->nElem, indMeio + 1, indSup, chave);
	}
}


