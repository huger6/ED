//
//  prototiposFuncs.h
//  Ficha1_Part1&2
//
//  Created by Jorge Loureiro on 29/02/2024.
//

#ifndef prototiposFuncs_h
#define prototiposFuncs_h

#define limparBuffer while(getchar() != '\n' && getchar() != '\0');

int menu(void);
int lerFicheiro(EDADOS *ed, char *nficheiro);
EDADOS *criarEDados(void);
EDADOS * duplicaDados(EDADOS *edOrig);
int ordenarDados(EDADOS *ed);
int ordenarDados1(EDADOS *ed);
int libertarMemoria(EDADOS *ed);
void mostrarRegisto(REGISTO_UTILIZADORES *dados);
int listarDados(EDADOS *ed, int nRegAMostrar);
void gerarFicheiroSoParaTestes(char *nficheiro);
int gerarFicheiro(char *nficheiro);
void subst_CR_ou_LF_por_NULL_String(char *S);
int contarPessoasAcessoAno(EDADOS *ed, int ano);
int pesquisaLinearCod(EDADOS *ed, char *codUtil);
int pesquisaLinearNome(EDADOS *ed, char *nomeUtil);
int pessoaMaisAcessos(EDADOS *ed);
float somarJoias(EDADOS *ed);
int mesMaisAcessos(EDADOS *ed);
int menu_v2(void);

// Protótipos das funções relativas à Parte "Extras", alíneas b) e c)
void trocaElemVector(EDADOS *ed, int index1, int index2);
void sortSelecaoDirectaPCod(EDADOS *ed, char tpOrd);
void sortSelecaoDirectaPNome(EDADOS *ed, char tpOrd);
void sortInsercaoDirectaPNome(EDADOS *ed, int tam, char tpOrd);
void ShellSortV1PNome(EDADOS *ed, int tam, char tpOrd);
void ShellSortV1PCod(EDADOS *ed, int tam, char tpOrd);
int PesquisaBinariaPNome(EDADOS *ed, int tamVect, char *chave);
int PesquisaBinariaPNome_v2(EDADOS *ed, int tamVect, char *chave);
int PesquisaBinariaRecPCod(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave);
int PesquisaBinariaRecPNome(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave);
int PesquisaBinariaRecPNome_v2(EDADOS *ed, int tamVect, int indInf, int indSup, char *chave);

#endif /* prototiposFuncs_h */
