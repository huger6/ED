#include <stdio.h>
#include <stdlib.h>
#include "Est_Dados.h"

extern int Aleatorio(int min, int max);
//-----------------------------------

USER *LerFicheiro(char *ficheiro, int *Nusers)
{
    //printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    FILE *F = fopen(ficheiro, "rb");
    if (F == NULL) { *Nusers = -1; return NULL; }
    long posicao = ftell(F);
    //printf("Na abertura: \"cursor\" de \"%s\" em %ld\n",ficheiro, posicao);
    fseek(F, 0, SEEK_END);
    posicao = ftell(F);
    //printf("Posicionado no fim: \"cursor\" em %ld\n", posicao);
    *Nusers = posicao / sizeof(USER);
    USER *V = (USER *)malloc((*Nusers) * sizeof(USER));
    fseek(F, 0, SEEK_SET); // volta pro inicio
    //rewind(F);
    fread(V, sizeof(USER), *Nusers, F);
    fclose(F);
    return V;
}

USER *DuplicarDados(USER *Original, int Nusers)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return NULL;
}
void OrdenarDados(USER *Original, int N)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
}
void LibertarMemoria(USER *Original)
{
    //printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    if (Original)
        free(Original);
}
void ListarUtilizadores(USER *Original, int Nusers)
{
    //printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    for (int i = 0; i < Nusers; i++)
    {
        MostrarUSER(&(Original[i]));
    }
}
int ContarPessoasAcessosAno(USER *Original, int N, int ano)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return -1;
}
USER *PesquisarCod(USER *Original, int N, int codigo)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return NULL;
}
USER *PesquisarNome(USER *Original, int N, char *nome)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return NULL;
}
USER *PessoaMais_Acessos(USER *Original, int N)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return NULL;
}
float TotalJoias(USER *Original, int N)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return -1;
}
int MesMaisRegistos(USER *Original, int N)
{
    printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    return -1;
}
void GerarFicheiro_So_Para_Testes(char *nficheiro)
{
    //printf("Tenho de fazer a funcao <%s>\n", __FUNCTION__);
    int Nusers = Aleatorio(3, 10);
    printf("Nusers = %d\n", Nusers);
    USER *V = (USER *)malloc(Nusers * sizeof(USER));
    for (int i = 0; i < Nusers; i++)
    {
        V[i].data_registo.ano = Aleatorio(2020, 2025);
        V[i].data_registo.mes = Aleatorio(1, 12);
        V[i].data_registo.dia = Aleatorio(1, 31);
        V[i].numero_acessos = Aleatorio(0, 10);
        sprintf(V[i].nome, "Luis-%d", Aleatorio(100, 500));
        sprintf(V[i].utilizador, "Luis---%d", Aleatorio(100, 500));

        MostrarUSER(&(V[i]));
    }
    // Gravar em Ficheiro Binario
    FILE *F = fopen(nficheiro, "wb");
    size_t tam_user = sizeof(USER);
    printf("tam_user = %d\n", tam_user);
    fwrite(V, sizeof(USER), Nusers, F);
    fclose(F);
}

void MostrarUSER(USER *X)
{
    if (!X) return;
    printf("USER:\n");
    printf("\t NOME: [%s]\n", X->nome);
    printf("\t UTILIZADOR: %s\n", X->utilizador);
    //--------
}
