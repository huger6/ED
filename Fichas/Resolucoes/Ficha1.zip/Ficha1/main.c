#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Est_Dados.h"

int main()
{
    printf("Ficha 1\n");
    srand(time(NULL));
    USER *VD = NULL;
    int NUSERS = 0;
    //GerarFicheiro_So_Para_Testes("utilizadores.dat");
    VD = LerFicheiro("utilizadores.dat", &NUSERS);
    OrdenarDados(VD, NUSERS);
    ListarUtilizadores(VD, NUSERS);

    LibertarMemoria(VD);
    return 0;
}
