#ifndef EST_DADOS_H_INCLUDED
#define EST_DADOS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int dia;
    int mes;
    int ano;
}DATA;

typedef struct
{
    char nome[50];
    char utilizador[20];
    char password[20];
    float joia;
    DATA data_registo;
    char email[30];
    char pagina_web_pessoal[50];
    int telemovel;
    int numero_acessos;
    DATA data_ultimo_acesso;
}REGISTO_UTILIZADORES, USER;

USER *LerFicheiro(char *ficheiro, int *Nusers);
//int LerFicheiro(char *ficheiro, USER *Dados, int *Nusers);
USER *DuplicarDados(USER *Original, int Nusers);
void OrdenarDados(USER *Original, int N);
void LibertarMemoria(USER *Original);
void ListarUtilizadores(USER *Original, int Nusers);
int ContarPessoasAcessosAno(USER *Original, int N, int ano);
USER *PesquisarCod(USER *Original, int N, int codigo);
USER *PesquisarNome(USER *Original, int N, char *nome);
USER *PessoaMais_Acessos(USER *Original, int N);
float TotalJoias(USER *Original, int N);
int MesMaisRegistos(USER *Original, int N);
void GerarFicheiro_So_Para_Testes(char *nficheiro);

void MostrarUSER(USER *X);

#endif // EST_DADOS_H_INCLUDED
