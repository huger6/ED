
#include "Palavra.h"

Palavra *CriarPalavra(char *txt)
{
    if (strlen(txt) > MAX_PALAVRA) return NULL;
    Palavra *Pal = (Palavra *)malloc(sizeof(Palavra));
    if (!Pal) return NULL;
    //Pal->TEXTO = (char *)malloc((strlen(txt) + 1)*sizeof(char));
    strcpy(Pal->TEXTO, txt);
    return Pal;
}
void MostrarPalavra(Palavra *P)
{
    //printf("TEXTO [%s]\n", P->TEXTO);
    fprintf(stdout, "TEXTO [%s]\n", P->TEXTO);
}
void DestruirPalavra(Palavra *P)
{
    if (!P) return;
    //free (P->TEXTO);
    free(P);
}
// Se forem iguais return 1, sen�o 0
int IguaisPalavras(Palavra *P1, Palavra *P2)
{
    if (!P1 && !P2) return 1;
    if (!P1) return 0;
    if (!P2) return 0;
    if (strcmp(P1->TEXTO, P2->TEXTO) == 0)
        return 1;
    return 0;
}

int IguaisPalavraTexto(Palavra *P1, char *txt)
{
    if (!P1 && !txt) return 1;
    if (!P1) return 0;
    if (!txt) return 0;
    if (strcmp(P1->TEXTO, txt) == 0)
        return 1;
    return 0;
}

int MemoriaPalavra(Palavra *P)
{
    return sizeof(*P);
}

int MemoriaDesperdicioPalavra(Palavra *P)
{
    return MAX_PALAVRA - strlen(P->TEXTO);
}
