#ifndef PALAVRA_H_INCLUDED
#define PALAVRA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCESSO   1
#define INSUCESSO 0
#define MAX_PALAVRA 50

typedef struct
{
    char TEXTO[MAX_PALAVRA+1];
    //char *TEXTO;
}Palavra;

Palavra *CriarPalavra(char *txt);
void MostrarPalavra(Palavra *P);
void DestruirPalavra(Palavra *P);
int IguaisPalavras(Palavra *P1, Palavra *P2);
int IguaisPalavraTexto(Palavra *P1, char *txt);
int MemoriaPalavra(Palavra *P);
int MemoriaDesperdicioPalavra(Palavra *P);


#endif // PALAVRA_H_INCLUDED
