#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "Palavra.h"

typedef struct no
{
    Palavra *Info;
    struct no *Prox;
}NO, ELEMENTO;

typedef struct
{
    char Lingua[3];
    int NEL;
    NO *Inicio;
}Lista, *ptLista;

Lista *CriarLista(char *ling);
int AddInicio(Lista *L, Palavra *Pal);
int AddFim(Lista *L, Palavra *Pal);
void Listar(Lista *L);
Palavra *PesquisarPalavra(Lista *L, char *txt);
void DestruirLista(ptLista L);
int Elementos_Repetidos(Lista *L);
int MemoriaOcupada(Lista *L);
int MemoriaDesperdicada(Lista *L);


#endif // LISTA_H_INCLUDED
