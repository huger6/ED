#include "Lista.h"

Lista *CriarLista(char *ling)
{
    Lista *L = (Lista *)malloc(sizeof(Lista));
    L->Inicio = NULL;
    L->NEL = 0;
    strcpy(L->Lingua, ling);
    return L;
}
int AddInicio(Lista *L, Palavra *Pal)
{
    NO *Aux = (NO *)malloc(sizeof(NO));
    Aux->Info = Pal;
    Aux->Prox = L->Inicio;
    L->Inicio = Aux;
    L->NEL++;
    return SUCESSO;
}
int AddFim(Lista *L, Palavra *Pal)
{
    NO *Aux = (NO *)malloc(sizeof(NO));
    Aux->Info = Pal;
    Aux->Prox = NULL;
    /*
    if (!L->Inicio)
    {
        L->Inicio = Aux;
        L->NEL++;
        return SUCESSO;
    }*/
    NO *P = L->Inicio;
    NO *Ant = NULL;
    while(P)
    {
        Ant = P;
        P = P->Prox;
    }
    // Neste momento P � NULL e Ant est� no �ltimo!
    if (!Ant) // Caso do inicio
        L->Inicio = Aux;
    else
        Ant->Prox = Aux;
    L->NEL++;
    return INSUCESSO;
}
void Listar(Lista *L)
{
    if (!L) return;
    NO *P = L->Inicio;
    while(P)
    {
        MostrarPalavra(P->Info);
        P = P->Prox;
    }
}
Palavra *PesquisarPalavra(Lista *L, char *txt)
{
    if (!L) return NULL;
    if (!txt) return NULL;
    NO *P = L->Inicio;
    while(P)
    {
        if (IguaisPalavraTexto(P->Info, txt) == 1)
            return P->Info;
        P = P->Prox;
    }
    return NULL;
}
void DestruirLista(ptLista L)
{

}
int Elementos_Repetidos(Lista *L)
{

    return INSUCESSO;
}

int MemoriaOcupada(Lista *L)
{
    int Mem = 0;
    Mem += sizeof(*L);
    NO *P = L->Inicio;
    while(P)
    {
        Mem += sizeof(NO);
        Mem += MemoriaPalavra(P->Info);
        P = P->Prox;
    }
    return Mem;
}
int MemoriaDesperdicada(Lista *L)
{
    int Mem = 0;
    NO *P = L->Inicio;
    while(P)
    {
        Mem += MemoriaDesperdicioPalavra(P->Info);
        P = P->Prox;
    }
    return Mem;
}

