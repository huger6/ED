#include <stdio.h>
#include <stdlib.h>

#include "Lista.h"

int main()
{
    printf("Hello world!\n");

    Lista *L = CriarLista("PT");
    Palavra *Pal = CriarPalavra("ola");
    AddInicio(L, Pal);
    AddInicio(L, CriarPalavra("Ole "));
    AddInicio(L, CriarPalavra("JoseMiguel"));
    AddInicio(L, CriarPalavra("Ole"));
    Listar(L);
    int mem_ocupada = MemoriaOcupada(L);
    int mem_desperdicio = MemoriaDesperdicada(L);
    printf("mem_ocupada = %d\n", mem_ocupada);
    printf("mem_desperdicio = %d\n", mem_desperdicio);

    DestruirLista(L);

    return 0;
}
