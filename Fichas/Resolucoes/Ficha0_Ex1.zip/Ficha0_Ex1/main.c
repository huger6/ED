#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/** \brief
 *
 * \param min int
 * \param max int
 * \return int
 *
 */
int Aleatorio(int min, int max)
{
    // ain da nao feita
    int valor = min + rand() % (max - min + 1);
    return valor;
}
int *CriarPreencherMatriz(int M, int N)
{
   // printf("Um dia vou fazer...CriarPreencherMatriz.\n");
    int *Mat = (int *)malloc(M * N * sizeof(int));
    for (int i = 0; i < M*N; i++)
        Mat[i] = Aleatorio(0, 3);
    return Mat;
}


/** \brief Permite mostrar a matriz
 *
 * \param Mat int* : Matriz de entrada
 * \param M int : Numero de Linhas
 * \param N int : Numero de colunas
 * \return void
 * \author : Alunos de EI
 *
 */
void MostrarMatriz(int *Mat, int M, int N)
{
   // printf("Um dia vou fazer...MostrarMatriz.\n");
   if (!Mat) { printf("Oh pa cuidado a matriz e NULA!\n"); return; }
   int cont = 0;
   for (int i = 0; i < M; i++)
   {
        for (int j = 0; j < N; j++)
            printf(" %d", Mat[cont++]);

       printf("\n");
   }
}
/** \brief Liberta a memoria alocada da matriz
 *
 * \param Mat int*
 * \return void
 *
 */
void DestruirMatriz(int *Mat)
{
    //printf("Um dia vou fazer...DestruirMatriz.\n");
    if (Mat != NULL) free(Mat);
}

int Esparsa(int *Matriz, int M, int N, float percentagem)
{
    //printf("Um dia vou fazer...Esparsa\n");
    float cont_zeros = 0.0f;
    int dim = M * N;
    for (int i = 0; i < dim; i++)
        if (Matriz[i] == 0) cont_zeros++;
    float p_zeros = cont_zeros / dim;
    if (p_zeros > percentagem)
        return 1;
    return 0;
}
int SomaMatriz(int *Matriz, int M, int N)
{
    int S = 0;
    int i = 0;
    int Tam = M * N;
    for (i = 0; i < Tam; i++)
        S += Matriz[i];
    return S;
}
int main()
{
    printf("Ficha0_Ex1!\n");
    srand(time(NULL));
    int *MAT = NULL;
    int Linhas = 5;
    int Colunas = 3;
    MAT = CriarPreencherMatriz(Linhas, Colunas);
    MostrarMatriz(MAT, Linhas, Colunas);
    int ESP = Esparsa(MAT, Linhas, Colunas, 0.3f);
    printf("ESPARCA = %d\n", ESP);
    DestruirMatriz(MAT);
    return 0;
}
