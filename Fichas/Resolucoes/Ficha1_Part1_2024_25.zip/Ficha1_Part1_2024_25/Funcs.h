//
//  Funcs.h
//  Ficha1_Part1_2024_25
//
//  Created by Jorge Loureiro on 26/02/2025.
//

#ifndef Funcs_h
#define Funcs_h

int menu(void);
int lerFicheiro(EDADOS *ed, char *nficheiro);
EDADOS *criarEDados(void);
EDADOS * duplicaDados(EDADOS *edOrig);
int ordenarDados(EDADOS *ed);
int ordenarDados1(EDADOS *ed);
int libertarMemoria(EDADOS *ed);
int listarDados(EDADOS *ed, int nRegAMostrar);
int gerarFicheiroSoParaTestes(char *nficheiro);
int gerarFicheiro(char *nficheiro);

#endif /* Funcs_h */
