//
//  funcs.c
//  Ficha1_Part1_2024_25
//
//  Created by Jorge Loureiro on 27/02/2025.
//

#include "Structs.h"
#include "Includes.h"
#define NUM_REGISTOS_GERAR 10000


// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
// Não usada nesta versão preliminar do Projecto
//--------------------------------------
int gerarFicheiroSoParaTestes(char *nficheiro)
{
	int N=NUM_REGISTOS_GERAR;  // número de registos a serem gerados e depois gravados no ficheiro
	// int nCli;
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < N; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%31;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 1: strcpy(nomeUt, "Joao_Coelho"); break;
			case 2: strcpy(nomeUt, "Manuel_Abrantes"); break;
			case 3: strcpy(nomeUt, "Rui_Ferreira"); break;
			case 4: strcpy(nomeUt, "Alexandre_Pereira"); break;
			case 5: strcpy(nomeUt, "Ricardo_Leao"); break;
			case 6: strcpy(nomeUt, "Diana_Loureiro"); break;
			case 7: strcpy(nomeUt, "Rafaela_Tomas"); break;
			case 8: strcpy(nomeUt, "Dalila_do_Carmo"); break;
			case 9: strcpy(nomeUt, "Bruna_Lombardi"); break;
			case 10: strcpy(nomeUt, "Marilyn_Monroe"); break;
			case 11: strcpy(nomeUt, "Nicolau_da_Viola"); break;
			case 12: strcpy(nomeUt, "Rodrigo_Leao"); break;
			case 13: strcpy(nomeUt, "Carolina_Micaelis"); break;
			case 14: strcpy(nomeUt, "Mariana_Castelo"); break;
			case 15: strcpy(nomeUt, "Helena_Coelho"); break;
			case 16: strcpy(nomeUt, "Pedro_Mota"); break;
			case 17: strcpy(nomeUt, "Artur_Manuel"); break;
			case 18: strcpy(nomeUt, "Paulo_Albuquerque"); break;
			case 19: strcpy(nomeUt, "Hipocrates_Jurado"); break;
			case 20: strcpy(nomeUt, "David_Golias"); break;
			case 21: strcpy(nomeUt, "Rafael_Boino"); break;
			case 22: strcpy(nomeUt, "Jorge_Albuquerque"); break;
			case 23: strcpy(nomeUt, "Manuel_Cardoso"); break;
			case 24: strcpy(nomeUt, "Joana_Ferreira"); break;
			case 25: strcpy(nomeUt, "Teresa_do_Rosario"); break;
			case 26: strcpy(nomeUt, "Joaquim_Tome"); break;
			case 27: strcpy(nomeUt, "Paulo_Ribeiro"); break;
			case 28: strcpy(nomeUt, "Mariana_do_Chao"); break;
			case 29: strcpy(nomeUt, "Helena_de_Micenas"); break;
			case 30: strcpy(nomeUt, "Ulisses_o_Grego"); break;
		}
		sprintf(R->nome, "%s - %d", nomeUt, rand()%10000);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%7;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%14;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

int geraChar(void){
	int nRand;
	do{
		nRand=rand()%123;
	} while(nRand>=33 && nRand <=122);
	printf("\nRand=%d", nRand);
	return nRand;
}

// Função que vai retirar o Enter que fica no final da string lida pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte, ficando "deslocado"
// A função procura o final de string ('\0'), e coloca outro ('\0') a sobrepôr o caracter anterior,
// onde está o Enter, eliminando-o.
void retiraEnterString(char *S){
	while(*S!='\0')
		S++;
	*(--S)='\0';
}

// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário - Versão 2
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
// Esta versão usa um ficheiro nomes.txt com 10000 nomes para ir buscar nomes para os utilizadores
//--------------------------------------
int gerarFicheiro(char *nficheiro)
{
	int i, nUt;
	FILE *fTxt = fopen("nome.txt", "r");  // ponteiro para usar para ler o fich. com os nomes
	if (!fTxt){
		printf("\nErro na abertura do ficheiro \"nome.txt\"");
		return 0;
	}
	
	V_NOMES vectNomes[NUM_REGISTOS_GERAR + 1];  // vector para ficar com os nomes lidos do ficheiro .txt
	for(i=0; i<NUM_REGISTOS_GERAR; i++){
		fgets(vectNomes[i].nome, 70, fTxt);
		retiraEnterString(vectNomes[i].nome); // retira o /n lido pelo fgets()
	}
	//for(i=0; i<50; i++){
	//	printf("\nNome %d = %s", i+1, vectNomes[i].nome);
	//}
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	// char nomeUt[20];
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < NUM_REGISTOS_GERAR; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%21;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 1: strcpy(nomeUt, "Joao"); break;
			/*case 1:
				strncpy(nomeUt, vectNomes[i].nome, 19);
				nomeUt[19]='\0';
				printf("\nNomeUt: %s", nomeUt);
				break;
			 */
			case 2: strcpy(nomeUt, "Manuel"); break;
			case 3: strcpy(nomeUt, "Rui"); break;
			case 4: strcpy(nomeUt, "Alexandre"); break;
			case 5: strcpy(nomeUt, "Ricardo"); break;
			case 6: strcpy(nomeUt, "Diana"); break;
			case 7: strcpy(nomeUt, "Rafaela"); break;
			case 8: strcpy(nomeUt, "Dalila"); break;
			case 9: strcpy(nomeUt, "Bruna"); break;
			case 10: strcpy(nomeUt, "Marilyn"); break;
			case 11: strcpy(nomeUt, "Nicolau"); break;
			case 12: strcpy(nomeUt, "Rodrigo"); break;
			case 13: strcpy(nomeUt, "Carolina"); break;
			case 14: strcpy(nomeUt, "Mariana"); break;
			case 15: strcpy(nomeUt, "Helena"); break;
			case 16: strcpy(nomeUt, "Pedro"); break;
			case 17: strcpy(nomeUt, "Artur"); break;
			case 18: strcpy(nomeUt, "Paulo"); break;
			case 19: strcpy(nomeUt, "Hipocrates"); break;
			case 20: strcpy(nomeUt, "David"); break;
		}
		nUt=rand()%50000;
		// printf("\nNome: %s", vectNomes[i].nome);
		//getchar();
		sprintf(R->nome, "%s", vectNomes[i].nome);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		// printf("\nR->utilizador: %s", R->utilizador);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%12;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

// Função para mostrar o menu e aceitar a opção
int menu(void)
{
	int opcao;
	//system("cls") ou system("clear");
	printf("\n #---------------------------------------------------------#");
	printf("\n | (1) Ler de Ficheiro                                     |");
	printf("\n | (2) Copiar os dados originais para outro vector         |");
	printf("\n | (3) Ordenar vector copiado por número de acessos        |");
	printf("\n | (4) Libertar memória                                    |");
	printf("\n | (5) Listar utilizadores (vector original)               |");
	printf("\n | (6) Listar utilizadores (depois de ordenados)           |");
	printf("\n +---------------------------------------------------------+");
	printf("\n | (0) Sair                                                |");
	printf("\n #---------------------------------------------------------#");

	do {
		printf("\nQual a sua opcao: ");
		scanf("%d", &opcao);
	} while (opcao < 0 || opcao > 6);
	return opcao;
}

// Ex. 1, opção 1 - Ler ficheiro
// Versão 1
/*
 Função: lerFicheiro
 Parâmetros: ed - ponteiro para a estrutura de dados onde vão ser carregados os dados;
			 nficheiro – nome do ficheiro a ler
 Descrição: Dado o nome do ficheiro (parâmetro nficheiro),
			a função vai ler para memória (para a estrutura apontada por ed) os dados do ficheiro,
			colocando também em nElem o número de registos lidos
 Retorno: 0 (se houver erro); 1 (caso não haja erro)
 */
//---------------------------------------
int lerFicheiro(EDADOS *ed, char *nficheiro)  // versão da aula
{
	// Colocar aqui o código correspondente à função requerida
	int N;
	FILE *f=fopen(nficheiro, "rb");
	if(!f){
		perror("Erro na abertura do ficheiro");
		return 0;
	}
	fseek(f, 0, SEEK_END);
	N=(int)ftell(f)/sizeof(REGISTO_UTILIZADORES);
	ed->nElem = N;
	ed->dados = (REGISTO_UTILIZADORES *) malloc(ed->nElem*sizeof(REGISTO_UTILIZADORES));
	fseek(f, 0, SEEK_SET);
	fread(ed->dados, sizeof(REGISTO_UTILIZADORES),ed->nElem,f);
	fclose(f);
	return 1;
}


// Função criarEDados que vai criar a estrutura ED (do tipo EDADOS) e inicializá-la
//---------------------------------------
EDADOS *criarEDados(void)
{
	EDADOS *ED = (EDADOS *)malloc(sizeof(EDADOS));
	ED->nElem = 0;
	ED->dados = NULL;
	return ED;
}

// Função correspondente ao ex. 2, opção 2 do menu (duplicaDados) que vai usar a função criarEDados
// para criar a nova estrutura para guardar a cópia da estrutura de dados original
// Vai copiar os dados do vector origem (com os dados lidos do ficheiro)
// para um novo vector, usado depois para ser ordenado
EDADOS * duplicaDados(EDADOS *edOrig)
{
	// Colocar aqui o código correspondente à função requerida
	int i;
	EDADOS * edDest=NULL;
	edDest = criarEDados();  	// instrução que permita criar o dado edDest;
	// Instrução que aloca os dados para o vector para a cópia dos dados
	/Users/jorgealexandredealbuquerqueloureiro/Google Drive/ED2024_25/FichasTP&PL/Ficha1/Ficha1_Part1_2024_25/Ficha1_Part1_2024_25_Base/Ficha1_Part1_2024_25_Base/Funcs.h	edDest->dados = (REGISTO_UTILIZADORES *) malloc(edOrig->nElem * sizeof(REGISTO_UTILIZADORES));
	
	// Colocar infra as instruções que permitam copiar os dados do dado origem
	// para o dado cópia (dica: usar um cilo opara o efeito)
	edDest->nElem = edOrig->nElem;
	for(i=0; i<edOrig->nElem; i++){
		edDest->dados[i] = edOrig->dados[i];
	}
	return edDest;  // retorna o dado com a copia dos dados efectuada}
}

/*
 Funcao: ordenarDados;
 Parâmetros: dados dos utilizadores (a cópia gerada com a função duplicaDados);
 Descrição: Permite ordenar o vector dos dados; utilizou-se o alg. BubbleSort;
 O vector dos dados recebido é ordenado, ficando portanto disponível na função chamante;
 Retorno: 0 (se houver erro); 1 (caso não haja erro);
 */
//---------------------------------------
int ordenarDados(EDADOS *ed)  // versão da aula
{
	int i,j;
	// Colocar aqui o código correspondente à função de ordenar dados
	if((!ed) || (!ed->dados)){
		printf("\nNão há dados para ordenar!");
		return 0;
	}
	// Vai usar-se o algoritmo bubble sort
	for(i=0; i<ed->nElem; i++){
		for(j=0; j< (ed->nElem-1-i); j++){
			if(ed->dados[j].numero_acessos > ed->dados[j+1].numero_acessos){
				REGISTO_UTILIZADORES aux = ed->dados[j];
				ed->dados[j] = ed->dados[j+1];
				ed->dados[j+1]=aux;
			}
		}
	}
	return 1;
}

// Função correspondente ao ex. 4, opção 4 do menu
// (libertar toda a memória alocada, relativa a uma det. estrutura).
// Função: libertarMemoria
// Parâmetro: ed - ponteiro para a estrutura de dados a ser libertada
// Retorno: 0 (se houver erro); 1 (caso não haja erro).
//---------------------------------------
int libertarMemoria(EDADOS *ed)
{
	/* Colocar a seguir a estes comentários o código
	 correspondente à função requerida.
	 Dicas:
	 1) Não esquecer de verificar se os dados
	    que se supõe serem destruídos existem (neste caso deverão ser 2).
	 2) Para cada um que exista, escrever a instrução
	    que liberte a memoria que foi alocada para ele.
	 3) No final, se a operação for bem sucedida, retornar 1.
	*/
	if(!ed)
		return 0;
	if(ed->dados !=NULL) // há dados no vector
		free(ed->dados);
	free(ed);
	return 1;
}

// Ex. 5 e 6, opção 5 e 6.
// Nas opções 5 e 6 é invocada a função listarDados.
// Esta função vai percorrer o vector de utilizadores
// que está incluido no dado especificado pelo ponteiro ed e,
// para cada um dos elementos, vai invocar a função mostarRegisto
// (apresentada já a seguir, que apresenta no ecrã o utilizador
// correspondente ao ponteiro que lhe é passado como parâmetro.


// Esta função vai mostrar no ecran a informação correspondente a cada registo de utilizador
// dados é o ponteiro para o registo a mostrar
void mostrarRegisto(REGISTO_UTILIZADORES *dados)
{
	// Dica: Esta função não é mais do que uma sucessão de linhas
	// com printf(...), cada uma para mostar um atributo do utilizador
	// Sugere-se que a 1.ª linha seja uma linha com "----" para separar
	// a informação relativa a cada utilizador.
	printf("----------------------------------------\n");
	printf("Utilizador: %s\n", dados->utilizador);
	printf("Nome: %s\n", dados->nome);
	printf("Password: %s\n", dados->password);
	printf("Data de Registo: %d/%d/%d\n", dados->data_registo.dia, dados->data_registo.mes, dados->data_registo.ano);
	printf("e-Mail: %s\n", dados->email);
	printf("Página Web Pessoal: %s\n", dados->pagina_web_pessoal);
	printf("Telemóvel: %d\n", dados->telemovel);
	printf("Número de acessos: %d\n", dados->numero_acessos);
	printf("Data de último acesso: %d/%d/%d\n", dados->data_ultimo_acesso.dia, dados->data_ultimo_acesso.mes, dados->data_ultimo_acesso.ano);
}

/*
 Funcao: listarDados
 Parâmetros: ed - Dado que contém a informação do número de utilizadores
 existentes e também outra necessária ao acesso da informação respectiva;
 nRegAMostrar - número de registos que se pretende sejam mostrados
 (iniciando no primeiro (0));
 Descrição: Percorre os utilizadores (iniciando pelo 1.º) e,
 para cada utilizador, vai invocar a função mostarRegisto que
 vai apresentar no monitos a informação relativa ao utilizador.
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */
int listarDados(EDADOS *ed, int nRegAMostrar)
{
	/* Colocar a seguir a estes comentários o código
	 correspondente a esta função.
	 Dicas:
	 1) Não esquecer de verificar se o ponteiro passado como parâmetro
		tem um valor atribuído e o mesmo para o ponteiro que integra a estrutura EDADOS;
	 2) Verificar se o nRegAMostar é válido, ou seja deve ser, no máximo,
		igual ao número de utilizadores existentes no vector;
	 3) Usar um ciclo que vá percorrer todos os utilizadores;
	 4) Para cada elemento, invocar a função mostarRegisto, com os argumento adequados;
	 5) No final, se a operação for bem sucedida, retornar 1.
	*/
		
	int i;
	if(!(ed) || (!ed->dados)) return 0; // não há qq. utilizador
	if(nRegAMostrar > ed->nElem)
		nRegAMostrar = ed->nElem;
	for(i=0; i<nRegAMostrar; i++){
		mostrarRegisto(&(ed->dados[i]));
	}
	return 1;
}
