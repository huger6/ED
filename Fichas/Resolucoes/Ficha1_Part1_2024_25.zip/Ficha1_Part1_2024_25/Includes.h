//
//  Includes.h
//  Ficha1_Part1_2024_25
//
//  Created by Jorge Loureiro on 26/02/2025.
//

#ifndef Includes_h
#define Includes_h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <locale.h>

#endif /* Includes_h */
