//
//  funcs.c
//  Ficha1_Part1_2023_24
//
//  Created by Jorge Loureiro on 27/02/2024.
//

#include "tiposIncludes.h"
#define NUM_REGISTOS_GERAR 1000


// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e gravar um com os dados dos utilizadores
//--------------------------------------
int gerarFicheiroSoParaTestes(char *nficheiro)
{
	int N=NUM_REGISTOS_GERAR;  // número de registos a serem gerados e depois gravados no ficheiro
	// int nCli;
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < N; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%31;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 1: strcpy(nomeUt, "Joao_Coelho"); break;
			case 2: strcpy(nomeUt, "Manuel_Abrantes"); break;
			case 3: strcpy(nomeUt, "Rui_Ferreira"); break;
			case 4: strcpy(nomeUt, "Alexandre_Pereira"); break;
			case 5: strcpy(nomeUt, "Ricardo_Leao"); break;
			case 6: strcpy(nomeUt, "Diana_Loureiro"); break;
			case 7: strcpy(nomeUt, "Rafaela_Tomas"); break;
			case 8: strcpy(nomeUt, "Dalila_do_Carmo"); break;
			case 9: strcpy(nomeUt, "Bruna_Lombardi"); break;
			case 10: strcpy(nomeUt, "Marilyn_Monroe"); break;
			case 11: strcpy(nomeUt, "Nicolau_da_Viola"); break;
			case 12: strcpy(nomeUt, "Rodrigo_Leao"); break;
			case 13: strcpy(nomeUt, "Carolina_Micaelis"); break;
			case 14: strcpy(nomeUt, "Mariana_Castelo"); break;
			case 15: strcpy(nomeUt, "Helena_Coelho"); break;
			case 16: strcpy(nomeUt, "Pedro_Mota"); break;
			case 17: strcpy(nomeUt, "Artur_Manuel"); break;
			case 18: strcpy(nomeUt, "Paulo_Albuquerque"); break;
			case 19: strcpy(nomeUt, "Hipocrates_Jurado"); break;
			case 20: strcpy(nomeUt, "David_Golias"); break;
			case 21: strcpy(nomeUt, "Rafael_Boino"); break;
			case 22: strcpy(nomeUt, "Jorge_Albuquerque"); break;
			case 23: strcpy(nomeUt, "Manuel_Cardoso"); break;
			case 24: strcpy(nomeUt, "Joana_Ferreira"); break;
			case 25: strcpy(nomeUt, "Teresa_do_Rosario"); break;
			case 26: strcpy(nomeUt, "Joaquim_Tome"); break;
			case 27: strcpy(nomeUt, "Paulo_Ribeiro"); break;
			case 28: strcpy(nomeUt, "Mariana_do_Chao"); break;
			case 29: strcpy(nomeUt, "Helena_de_Micenas"); break;
			case 30: strcpy(nomeUt, "Ulisses_o_Grego"); break;
		}
		sprintf(R->nome, "%s - %d", nomeUt, rand()%10000);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%14;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

// Função que vai retirar o Enter que fica no final da string lida pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte, ficando "deslocado"
// A função procura o final de string ('\0'), e coloca outro ('\0') a sobrepôr o caracter anterior,
// onde está o Enter, eliminando-o.
void retiraEnterString(char *S){
	while(*S!='\0')
		S++;
	*(--S)='\0';
}

int gerarFicheiro(char *nficheiro)
{
	int N=NUM_REGISTOS_GERAR;  // número de registos a serem gerados e depois gravados no ficheiro
	int i, nUt;
	FILE *fTxt = fopen("nome.txt", "r");  // ponteiro para usar para ler o fich. com os nomes
	
	V_NOMES vectNomes[10001];  // vector para ficar com os nomes lidos do ficheiro .txt
	for(i=0; i<10000; i++){
		fgets(vectNomes[i].nome, 70, fTxt);
		retiraEnterString(vectNomes[i].nome); // retira 0 /n lido pelo fgets()
	}
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	// char nomeUt[20];
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < N; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%21;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 1: strcpy(nomeUt, "Joao"); break;
			/*case 1:
				strncpy(nomeUt, vectNomes[i].nome, 19);
				nomeUt[19]='\0';
				printf("\nNomeUt: %s", nomeUt);
				break;
			 */
			case 2: strcpy(nomeUt, "Manuel"); break;
			case 3: strcpy(nomeUt, "Rui"); break;
			case 4: strcpy(nomeUt, "Alexandre"); break;
			case 5: strcpy(nomeUt, "Ricardo"); break;
			case 6: strcpy(nomeUt, "Diana"); break;
			case 7: strcpy(nomeUt, "Rafaela"); break;
			case 8: strcpy(nomeUt, "Dalila"); break;
			case 9: strcpy(nomeUt, "Bruna"); break;
			case 10: strcpy(nomeUt, "Marilyn"); break;
			case 11: strcpy(nomeUt, "Nicolau"); break;
			case 12: strcpy(nomeUt, "Rodrigo"); break;
			case 13: strcpy(nomeUt, "Carolina"); break;
			case 14: strcpy(nomeUt, "Mariana"); break;
			case 15: strcpy(nomeUt, "Helena"); break;
			case 16: strcpy(nomeUt, "Pedro"); break;
			case 17: strcpy(nomeUt, "Artur"); break;
			case 18: strcpy(nomeUt, "Paulo"); break;
			case 19: strcpy(nomeUt, "Hipocrates"); break;
			case 20: strcpy(nomeUt, "David"); break;
		}
		nUt=rand()%50000;
		// printf("\nNome: %s", vectNomes[i].nome);
		//getchar();
		sprintf(R->nome, "%s", vectNomes[i].nome);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		// printf("\nR->utilizador: %s", R->utilizador);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%12;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

// Função para mostrar o menu e aceitar a opção
int menu(void)
{
	int opcao;
	//system("cls") ou system("clear");
	printf("\n #---------------------------------------------------------#");
	printf("\n | (1) Ler de Ficheiro                                     |");
	printf("\n | (2) Copiar os dados originais para outro vector         |");
	printf("\n | (3) Ordenar vector copiado por número de acessos        |");
	printf("\n | (4) Libertar memória                                    |");
	printf("\n | (5) Listar utilizadores (vector original)               |");
	printf("\n | (6) Listar utilizadores (depois de ordenados)           |");
	printf("\n +---------------------------------------------------------+");
	printf("\n | (0) Sair                                                |");
	printf("\n #---------------------------------------------------------#");

	do {
		printf("\nQual a sua opcao: ");
		scanf("%d", &opcao);
	} while (opcao < 0 || opcao > 6);
	return opcao;
}

// Ex. 1, opção 1 - Ler ficheiro
// Versão 1
/*
 Função: lerFicheiro
 Parâmetros: ed - ponteiro para a estrutura de dados onde vão ser carregados os dados;
			 nficheiro – nome do ficheiro a ler
 Descrição: Dado o nome do ficheiro (parâmetro nficheiro),
			a função vai ler para memória (para a estrutura apontada por ed) os dados do ficheiro,
			colocando também em nElem o número de registos lidos
 Retorno: 0 (se houver erro); 1 (caso não haja erro)
 */
//---------------------------------------
int lerFicheiro(EDADOS *ed, char *nficheiro)  // versão da aula
{
	//AvisoParaAluno;
	int N;
	FILE *F = fopen(nficheiro, "rb");
	if (!F) return 0;
	fseek(F, 0, SEEK_END); // mover o ponteiro do ficheiro para o fim
	// Calcular o número de registos (N) que se encontram no ficheiro
	N = (int) ftell(F) / sizeof(REGISTO_UTILIZADORES);
	//printf("TAMANHO = %ld", N);
	ed->nElem = N;
	ed->dados = (REGISTO_UTILIZADORES *)malloc(ed->nElem * sizeof(REGISTO_UTILIZADORES));
	fseek(F, 0, SEEK_SET); // Mover o ponteiro do ficheiro para o início
	// ler todos os dados do ficheiro para o bloco de memória apontado por ed->dados;
	fread(ed->dados, sizeof(REGISTO_UTILIZADORES), ed->nElem, F);
	// Se fosse pretendido mostar os registos lidos, um a um, ter-se-ia:
	//    REGISTO_UTILIZADORES *pinicio = ed->Dados;
	/*for(int i=0; i<ed->NEL; i++)
	{
		printf("Registo leitura %d: data: %d/%d/%d\n", i+1, ed->Dados[i].data_registo.dia, ed->Dados[i].data_registo.mes, ed->Dados[i].data_registo.ano);
		printf("Nome: %s\n", ed->Dados[i].nome);
	}*/
	//ed->Dados = pinicio;
	fclose(F);
	return 1;
}

// Função correspondente ao ex. 2, opção 2 do menu (duplicaDados) que vai usar a função criarEDados
// para criar a nova estrutura com a cópia da estrutura xde dados original
// Vai copiar os dados do vector origem (com os dados lidos do ficheiro) para um novo vector usado depois para ser ordenado

//---------------------------------------
EDADOS *criarEDados(void)
{
	EDADOS *ED = (EDADOS *)malloc(sizeof(EDADOS));
	ED->nElem = 0;
	ED->dados = NULL;
	return ED;
}

EDADOS * duplicaDados(EDADOS *edOrig)
{
	int i=0;
	EDADOS * edDest;
	edDest = criarEDados();
	edDest->dados = (REGISTO_UTILIZADORES *)malloc(edOrig->nElem * sizeof(REGISTO_UTILIZADORES));
	edDest->nElem=edOrig->nElem;
	for(i=0; i<edOrig->nElem; i++) // copiar o vector original para o vector destino (a ordenar)
	{
		edDest->dados[i] = edOrig->dados[i];
	}
	return edDest;
}

/*
 Funcao: ordenarDados;
 Parâmetros: dados dos utilizadores (a cópia gerada com a função duplicaDados);
 Descrição: Permite ordenar o vector dos dados; utilizou-se o alg. BubbleSort;
 O vector dos dados recebido é ordenado, ficando portanto disponível na função chamante;
 Retorno: 0 (se houver erro); 1 (caso não haja erro);
 */
//---------------------------------------
int ordenarDados(EDADOS *ed)  // versão da aula
{
	int k;
	if (!ed) return 0;
	if (!ed->dados) return 0;
	//------- Fazer código -------
	
	
	return 1;
}

/*
 Funcao: ordenarDados1 (de funcionalidade igual à ordenarDados, mas utilizando ponteiros na manipulação de dados);
 Parâmetros: dados dos utilizadores (a cópia gerada com a função duplicaDados);
 Descrição: Permite ordenar o vector dos dados; utilizou-se o alg. BubbleSort;
 O vector dos dados recebido é ordenado, ficando portanto disponível na função chamante;
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */
//---------------------------------------
int ordenarDados1(EDADOS *ed)  // versão com ponteiros
{
	int k;
	if (!ed) return 0;
	if (!ed->dados) return 0;
	//------- Fazer código -------
	
	
	return 1;
}

// Função correspondente ao ex. 4, opção 4 do menu (libertar toda a memória alocada, relativa a uma det. estrutura)
// Função: libertarMemoria
// Parâmetro: ed - ponteiro para a estrutura de dados oa ser libertada
// Retorno: 0 (se houver erro); 1 (caso não haja erro)
//---------------------------------------
int libertarMemoria(EDADOS *ed)
{
	//------- Fazer código -------
	
	return 1;
}

// Ex. 5 e 6, opção 5 e 6, atendendo ao ponteiro (aqui o ponteiro *ed) que lhe é passado como argumento, ao ser invocada a função listarDados
/*
 Funcao: listarDados
 Parametros: ed - Dados dos utilizadores; nRegAMostrar - número de registos que se pretende sejam mosytrados (iniciando no primeiro (0))
 Descrição: Permite Listar os dados dos utilizadores
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */

// Esta função vai mostrar no ecran a informação correspondente a cada registo de utilizador
// dados é o ponteiro para o registo a mostrar
void mostrarRegisto(REGISTO_UTILIZADORES *dados)
{
	printf("--------------------------------------------\n");
	printf("Utilizador = %s\n", dados->utilizador);
	printf("Nome = %s\n", dados->nome);
	printf("Password = %s\n", dados->password);
	printf("Data de Registo = %d/%d/%d\n", dados->data_registo.dia, dados->data_registo.mes, dados->data_registo.ano);
	printf("e-Mail = %s\n", dados->email);
	printf("Página Web Pessoal = %s\n", dados->pagina_web_pessoal);
	printf("Telemóvel = %d\n", dados->telemovel);
	printf("Número de Acessos = %d\n", dados->numero_acessos);
	printf("Data de Último Acesso = %d/%d/%d\n", dados->data_ultimo_acesso.dia, dados->data_ultimo_acesso.mes, dados->data_ultimo_acesso.ano);
}
int listarDados(EDADOS *ed, int nRegAMostrar)
{
	int i;
	if ((!ed) || (!ed->dados)) return 0;
	if (nRegAMostrar > ed->nElem)
		nRegAMostrar=ed->nElem;
	
	printf("\n--------------------------------------------\n");
	printf("\nNúmero de utilizadores a listar: %d\n", nRegAMostrar);
	
	for (i = 0; i < nRegAMostrar; i++)
	{
		mostrarRegisto(&(ed->dados[i])); // &((ed->dados[i]) é o endereço do registo a mostrar
	}
	return 1;
}
