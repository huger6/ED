//
//  main.c
//  Ficha1_Extensao_2024_25_Base
//
//  Created by Jorge Loureiro on 06/03/2025.
//

#include "Structs.h"

#include "Includes.h"

#include "Funcs.h"

#define GERAR_FICHEIRO 1
#define NUM_REGISTOS_GERAR 10000


extern int strICaseCmp(char *str1, char *str2);


int main(void)
{
	setlocale(LC_ALL,"Portuguese"); /* para usar caracteres acentuados   */
	// variáveis para time.h
	clock_t start, end;
	double elapsed=0.0;
	//
	//ponteiro para struct que armazena data e hora
	struct tm *data_hora_atual;
	//variável do tipo time_t para armazenar o tempo em segundos
	time_t segundos;
	//obtendo o tempo em segundos
	time(&segundos);
	//para converter de segundos para o tempo local, utiliza-se a função localtime
	data_hora_atual = localtime(&segundos);

	int vectCopia=0; // se existe o vector edCopia
	int opcao;
	FILE *F=NULL;
	EDADOS *edOrig=NULL, *edCopia=NULL; // edOrig - Estrutura de dados com os dados originais (lidos do ficheiro);
	edOrig = criarEDados();   // é criada a estrutura da dados origem
	// edCopia - Estrutura de dados copiados da etOrig, usada depois para as ordenações
	// gerar os dados e gravá-los no ficheiro
	if(GERAR_FICHEIRO){  // se GERAR_FICHEIRO = 1, devem ser gerados os dados dos utilizadores e gravados no ficheiro
		// depois do fich. ter os dados que se pretendem, colocar GERAR_FICHEIRO a 0.
		// gerarFicheiroSoParaTestes("Utilizadores.dat"); // Função criada para gerar os dados
		// dos utilizadores, neste caso, gerando todos os campos do utilizador, criando strings
		// concatenando strings pré-determinadas e rand()s ou rand()s (para campos numéricos).
		gerarFicheiro("Utilizadores.dat"); // // Função criada para gerar os dados dos utilizadores
		// Neste caso, lendo o fich. nome.txt com um pouco mais de 10000 nomes para utilizar como
		// nome dos nomes dos utilizadores, sendo os restantes campos gerados criando
		// string concatenando strings pré-determinadas e rand()s ou rand()s (para campos numéricos).
	}
	do {
		opcao = menu();
		switch(opcao) {
			case 1:  // Ler ficheiro binário "utilizadores.dat"
					 // para o ponteiro vOrig (estrutura V_NOME)
			{
				/*
				 printf("Ficha 1 - Ficheiros Binarios, ord. pesquisas!\n");
				 srand(time(NULL));
				 GerarFicheiro_So_Para_Testes("dados.dat");
				 EDados *ED = (EDados *)malloc(1 * sizeof(EDados));
				 LerFicheiro(ED, "dados.dat");
				 */
				
				// Start measuring time
				start = clock();
				
				lerFicheiro(edOrig, (char *) "Utilizadores.dat");
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				
				fprintf(F,"Acao................................;Hora de Início (HH:MM:SS); Tempo de execucao.\n");
				fprintf(F, "Acao.................................................\n");
				fprintf(F, "Execução do Programa na Data (AAAA/MM/DD): ;%4d/%2d/%2d\n",data_hora_atual->tm_year+1900, data_hora_atual->tm_mon+1, data_hora_atual->tm_mday);
				fprintf(F, "Executada para ler um fich. com um máximo de utilizadores de ; %d\n", NUM_REGISTOS_GERAR);
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao. \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Leitura do ficheiro Utilizadores.dat;%2d:%2d:%2d;Executada em %f segundos.\n",
						data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				fclose(F);
				break;
			}
			case 2:  // Copiar os dados lidos do ficheiro "utilizadores.dat" para o vector vOrig,
					 // para outro vector (vCopia)
			{
				if (vectCopia == 1) // se o vectCopia existir, ele é apagado, recriado e
									//depois são copiados os dados do vectOrig
				{
					libertarMemoria(edCopia);
					vectCopia=0;
				}
				
				// Start measuring time
				start = clock();
				
				edCopia = criarEDados();
				edCopia = duplicaDados(edOrig);  // copiar os dados para a estrutura edCopia
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Cópia do vector lido do fich. ......;%2d:%2d:%2d;Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				
				vectCopia=1; // já foi criado o edCopia e copiados os dados para ele
				break;
				
			}
			case 3: // Listar utilizadores (vector original vOrig)
					// que contem a informação dos utilizadores lidos do ficheiro.
			{
				// Start measuring time
				start = clock();
				
				listarDados(edOrig, edOrig->nElem);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Listar %d utiliz. lidos do fich. ;%2d:%2d:%2d;Executada em %f segundos. \n", edOrig->nElem, data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				break;
			}
			case 4: // Listar utilizadores (vector copiado vCopia)
					// que vai ser utilizado para ser executada sobre ele a opção 6 e posterior
					// listagem (opção 4)
			{
				// Start measuring time
				start = clock();
				
				if(vectCopia)
				{
					listarDados(edCopia, edCopia->nElem);
					// Stop measuring time and calculate the elapsed time
					end = clock();
					elapsed = (double) (end - start)/CLOCKS_PER_SEC;
					
					// Abrir o fich. para append
					F = fopen("Performance.csv", "a");
					time(&segundos);
					data_hora_atual = localtime(&segundos);
					
					fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
					//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
					fprintf(F, "Listar %d utiliz. do vect. copia. ;%2d:%2d:%2d;Executada em %f segundos. \n", edCopia->nElem, data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);
				}
				else
				{
					printf("\nNão existem os dados cópia !! ");
					printf("\nProceda à sua criação e liste depois.");
					limparBuffer;
					printf("\nDigite <Enter> para continuar...");
					getchar();
				}
				break;
			}
				
			case 5: // Gravar para XML os dados do vector dos USERS
			{
				// Start measuring time
				start = clock();
				
				gravarXML(edOrig, "fich_xml.xml");

				// Stop measuring time and calculate the elapsed time
				end = clock();
				
				elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Gravar fich. XML - nome fich_xml.xml;%2d:%2d:%2d;Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);

				fclose(F);
				break;
			}
				
			case 6: // Converter os nomes dos utiliz. p/ maiúsc. (vect. cop.)
			{
				// Start measuring time
				start = clock();
				
				toLetrasGrandes(edCopia);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Conv. nome dos utiliz. p/ maiúsculas;%2d:%2d:%2d;Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);

				fclose(F);
				break;
			}
				
			case 7: // Listar os utiliz. que contêm no nome uma dada string (especificada pelo
					// utilizador e depois passada como argumento para a função).
			{
				char sobrenome[70];
				printf("Qual o subnome que se pretende procurar nos nomes dos Utilizadores? ");
				limparBuffer;  // só para limpar o buffer do teclado
				fgets(sobrenome, 70, stdin);
				subst_CR_ou_LF_por_NULL_String(sobrenome);
				// Start measuring time
				start = clock();
				
				int cont = listarUsersContains(edOrig, sobrenome);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				printf("\nO subnome [%s] está %d vezes no nome dos Utilizadores.\n", sobrenome, cont);
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Listar utiliz. cujo nome tem subnome;%2d:%2d:%2d;Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);

				fclose(F);
				break;
			}
				
			case 8: // Mostrar qual é o subnome dos nomes que é mais comum
			{
				// Start measuring time
				start = clock();
				
				char *nome_Mais_Comum = nomeMaisComum(edOrig);
				
				// Stop measuring time and calculate the elapsed time
				end = clock();
				double elapsed = (double) (end - start)/CLOCKS_PER_SEC;
				
				// Abrir o fich. para append
				F = fopen("Performance.csv", "a");
				time(&segundos);
				data_hora_atual = localtime(&segundos);
				
				fprintf(F, "Acao................................;Hora de Início (HH:MM:SS);Tempo de execucao......... \n");
				//fprintf(F, "%s;%f\n", __FUNCTION__, elapsed);
				fprintf(F, "Qual o subnome dos nomes mais comum?;%2d:%2d:%2d;Executada em %f segundos. \n", data_hora_atual->tm_hour, data_hora_atual->tm_min, data_hora_atual->tm_sec, elapsed);

				fclose(F);
				
				if (nome_Mais_Comum)
				{
					printf("\nO Nome_Mais_Comum = [%s]\n", nome_Mais_Comum);
					free (nome_Mais_Comum);
				}
				else
					printf("\nO Nome_Mais_Comum = [NULL]\n");
				
				break;
			}
				
			case 0:
			{
				printf("\n ###### FIM ######\n");
				break;
			}
				
			default:
			{
				break;
			}
		}
	} while( opcao != 0 );
	
	// Só para Debug da função strICaseCmp (strcmp case insensitive)
	// char strTeste1[10]="aBaBaBaB";
	// char strTeste2[10]="AbAbAbAb";
	//printf("\nA comparação entre strTeste1 e strTeste2 devolveu o valor: [%d]\n",
	//											strICaseCmp(strTeste1, strTeste2));
	
	// destruir as estruturas de dados criadas para guardar os dados em memória
	if (vectCopia==1)  // se a estrutura de dados copia de utilizadores para foi criada
		libertarMemoria(edCopia);
	libertarMemoria(edOrig);
	return 0;
}

