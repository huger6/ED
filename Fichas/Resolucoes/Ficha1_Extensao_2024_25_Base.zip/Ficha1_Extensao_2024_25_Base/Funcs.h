//
//  Funcs.h
//  Ficha1_Extensao_2024_25_Base
//
//  Created by Jorge Loureiro on 06/03/2025.
//

#ifndef Funcs_h
#define Funcs_h

#define limparBuffer while(getchar() != '\n' && getchar() != '\0');

int menu(void);
int lerFicheiro(EDADOS *ed, char *nficheiro);
EDADOS *criarEDados(void);
EDADOS * duplicaDados(EDADOS *edOrig);
int libertarMemoria(EDADOS *ed);
void mostrarRegisto(REGISTO_UTILIZADORES *dados);
int listarDados(EDADOS *ed, int nRegAMostrar);
// void gerarFicheiroSoParaTestes(char *nficheiro);
int gerarFicheiro(char *nficheiro);
void subst_CR_ou_LF_por_NULL_String(char *S);

int Aleatorio(int min, int max);
int LerInteiro(char *txt);
void gravarUSER_XML(FILE *F, USER *X);
int gravarXML(EDADOS *ed, char *ficheiro); // opção 5
int toLetrasGrandes(EDADOS *ed); // opção 6
int listarUsersContains(EDADOS *ed, char *subnome);  // opção 7
char *nomeMaisComum(EDADOS *ed); // opção 8

#endif /* Funcs_h */
