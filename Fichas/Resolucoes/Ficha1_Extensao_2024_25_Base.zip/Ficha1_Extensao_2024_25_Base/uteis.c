//
//  uteis.c
//  Ficha1_Extensao_2024_25_Base
//
//  Created by Jorge Loureiro on 06/03/2025.
//

#include "Includes.h"


#define MAX_NOME 70
#define SUCESSO   1
#define INSUCESSO 0

#define limparBuffer while(getchar() != '\n' && getchar() != '\0');


typedef struct vNomes{
	char nome[70];
} V_NOMES;

int Aleatorio(int min, int max)
{
	return min + rand() % (max - min + 1);
}

int Factorial(int N)
{
	if (N == 0) return 1;
	return N * Factorial(N-1);
}

int LerInteiro(char *txt)
{
	int x;
	printf("%s : ", txt);
	scanf("%d", &x);
	return x;
}

// Função que converte em maiúsculas o conteúdo da string S.
void converterPMaiuscula(char *s)
{
	int i = 0;
	while (s[i] != '\0')
	{
		s[i] = toupper(s[i]);
		i++;
	}
}

// Função que converte em minúsculas o conteúdo da string S.
void converterPMinuscula(char *s)
{
	int i = 0;
	while (s[i] != '\0')
	{
		s[i] = tolower(s[i]);
		i++;
	}
}

// Função que efectua a comparação entre a string str1 e str2, sendo "case insensitive".
// Funcionalidade identica às funções não standard stricmp() e strcasecmp().
int strICaseCmp(char *str1, char *str2){
	int resComp=0; // para guardar o resultado da comparação entre as 2 strings e fazer depois o return
	// str1Cop e str2Cop são criadas para que o conteúdo
	// original de str1 e str2 não sejam alterados
	char *str1Cop = (char *) malloc((strlen(str1)+1)*sizeof(char));
	strcpy(str1Cop, str1);
	converterPMaiuscula(str1Cop);  // ou converterPMinuscula(str1Cop)
	char *str2Cop = (char *) malloc((strlen(str2)+1)*sizeof(char));
	strcpy(str2Cop, str2);
	converterPMaiuscula(str2Cop);  // ou converterPMinuscula(str2Cop)
	resComp = strcmp(str1Cop, str2Cop);  // Como há que fazer o free de str1Cop e str2Cop,
	free (str1Cop);						 // resComp fica com o resultado da comparação
	free (str2Cop);						 // para depois ser retornado.
	return resComp;
}

// Função que vai devolver o número de registos de um fich.cujo nome é especificado
// Parâmetros: nomeFich - nome do ficheiro; tpFich - tipo do ficheiro (b-binário; t-texto);
// tamRegisto - tamanho (em bytes) de cada registo do ficheiro
int retNumRegFich(char *nomeFich, char tpFich, int tamRegisto)
{
	// V_NOMES NomeUt;  // dado que vai servir para ficar com cada nome lido do ficheiro .txt
	char strNome[71];
	int nRegUt=0; // número de registos no ficheiro
	FILE *F=NULL;
	if(tpFich=='b'){
		F = fopen(nomeFich, "rb");
		if (!F){
			printf("\nErro na abertura do ficheiro %s!", nomeFich);
			limparBuffer;
			printf("\nDigite <Enter> para continuar...");
			getchar();
			return INSUCESSO;
		}
		else
		{
			fseek(F, 0, SEEK_END); // Mover o ponteiro do ficheiro para o fim do ficheiro
			// Calcular o número de registos (N) que se encontram no ficheiro
			// n = (int) ftell(F) / sizeof(REGISTO_UTILIZADORES);
			nRegUt = (int) ftell(F) / tamRegisto;
			printf("\nO número de registos que estão no fich. %s é de: %d", nomeFich, nRegUt);
			return nRegUt;
		}
	}
	else
	{
		F = fopen(nomeFich, "r");
		if (!F){
			printf("\nErro na abertura do ficheiro %s!", nomeFich);
			limparBuffer;
			printf("\nDigite <Enter> para continuar...");
			getchar();
			return INSUCESSO;
		}
		else
		{
			do
			{
				fgets(strNome, MAX_NOME, F);
				nRegUt += 1;
				printf("\nContar RegUt: %d, Nome:[%s]", nRegUt, strNome);
			}
			while (!feof(F));
			return nRegUt;
		}
	}
}
