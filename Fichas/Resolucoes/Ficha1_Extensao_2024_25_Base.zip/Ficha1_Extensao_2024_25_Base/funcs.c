//
//  funcs.c
//  Ficha1_Extensao_2024_25_Base
//
//  Created by Jorge Loureiro on 06/03/2025.
//

#include "Structs.h"
#include "Includes.h"

#define MAX_NOME 70
#define SUCESSO   1
#define INSUCESSO 0

#define limparBuffer while(getchar() != '\n' && getchar() != '\0');
#define NUM_REGISTOS_GERAR 10000

extern void converterPMaiuscula(char *s);

// Função que vai retirar o CR ou LF que podem ficar nos caracteres finais
// da string lida pela função fgets() e que, ao ser mostrada pela função printf(),
// coloca o cursor na linha seguinte, ficando "deslocado".
// A função procura o CR ou LF e o primeiro que encontrar
// e substitui-o pelo valor 0 ('\0'), que representa o final de string ('\0').
// Portanto, vai colocar o final da string logo
// depois dos caracteres "normais" da string.
void subst_CR_ou_LF_por_NULL_String(char *S){
	char *ptrCurr;
	ptrCurr=S; // guarda o endereço actual do ponteiro da string S
	while(*S!=10 && *S!=13 && *S!=0){
		S++;
	}
	if(*S==13 || *S==10){
		*S=0;
		S=ptrCurr; // repõe o endereço inicial do ponteiro da string S
	}
}

// Função que vai retirar o Enter que fica no final da string lida pela função fgets()
// e que, ao ser mostrada pela função printf(), coloca o cursor na linha seguinte, ficando "deslocado"
// A função procura o final de string ('\0'), e coloca outro ('\0') a sobrepôr o caracter anterior,
// onde está o Enter, eliminando-o.
void retiraEnterString(char *S){
	while(*S!='\0')
		S++;
	*(--S)='\0';
}

// Função usada para gerar os dados dos utilizadores e gravar o ficheiro binário - Versão 2
// Criada, pois que, não sendo fornecido o ficheiro, é necessário criar e
// gravar um com os dados dos utilizadores.
// Esta versão usa um ficheiro nomes.txt com 10000 nomes
// para ir buscar nomes para os utilizadores
int gerarFicheiro(char *nficheiro)
{
	int i, nUt;
	FILE *fTxt = fopen("nome.txt", "r");  // ponteiro para usar para ler o fich. com os nomes
	if (!fTxt){
		printf("\nErro na abertura do ficheiro \"nome.txt\"");
		return 0;
	}
	
	V_NOMES vectNomes[NUM_REGISTOS_GERAR + 1];  // vector para ficar com os nomes lidos do ficheiro .txt
	for(i=0; i<NUM_REGISTOS_GERAR; i++){
		fgets(vectNomes[i].nome, 70, fTxt);
		//while(fscanf(fTxt, "%s", buff)!="\n")
		//	strcpy(vectNomes[i].nome, buff);
		//fscanf(fTxt, "[^\n]", vectNomes[i].nome);
		// printf("\nT1 Nome %d = [%s]", i+1, vectNomes[i].nome);
		retiraEnterString(vectNomes[i].nome); // retira o /n lido pelo fgets()
	}
	/*	for(i=0; i<50; i++){
		printf("\nT2 Nome %d = [%s]", i+1, vectNomes[i].nome);
	} */
		
	time_t t;
	srand((unsigned)time(&t));
	// srand((unsigned)time(NULL)); // Iniciar o gerador de aleatorios
	int nRand=0;
	// char nomeUt[20];
	char nomeUt[20];
	FILE *F = fopen(nficheiro, "wb");
	if (!F) return 0;
	for (int i = 0; i < NUM_REGISTOS_GERAR; i++)
	{
		REGISTO_UTILIZADORES *R = (REGISTO_UTILIZADORES *)malloc(sizeof(REGISTO_UTILIZADORES));
		nRand=rand()%31;
		// printf("\nRand=%d", nRand);
		switch(nRand){
			case 0: strcpy(nomeUt, "Rui"); break;
			case 1: strcpy(nomeUt, "Joao"); break;
			case 2: strcpy(nomeUt, "Manuel"); break;
			case 3: strcpy(nomeUt, "Rui"); break;
			case 4: strcpy(nomeUt, "Alexandre"); break;
			case 5: strcpy(nomeUt, "Ricardo"); break;
			case 6: strcpy(nomeUt, "Diana"); break;
			case 7: strcpy(nomeUt, "Rafaela"); break;
			case 8: strcpy(nomeUt, "Dalila"); break;
			case 9: strcpy(nomeUt, "Bruna"); break;
			case 10: strcpy(nomeUt, "Marilyn"); break;
			case 11: strcpy(nomeUt, "Nicolau"); break;
			case 12: strcpy(nomeUt, "Rodrigo"); break;
			case 13: strcpy(nomeUt, "Carolina"); break;
			case 14: strcpy(nomeUt, "Mariana"); break;
			case 15: strcpy(nomeUt, "Helena"); break;
			case 16: strcpy(nomeUt, "Pedro"); break;
			case 17: strcpy(nomeUt, "Artur"); break;
			case 18: strcpy(nomeUt, "Paulo"); break;
			case 19: strcpy(nomeUt, "Hipocrates"); break;
			case 20: strcpy(nomeUt, "David"); break;
			case 21: strcpy(nomeUt, "Rafael"); break;
			case 22: strcpy(nomeUt, "Jorge"); break;
			case 23: strcpy(nomeUt, "Manuel"); break;
			case 24: strcpy(nomeUt, "Joana"); break;
			case 25: strcpy(nomeUt, "Teresa"); break;
			case 26: strcpy(nomeUt, "Joaquim"); break;
			case 27: strcpy(nomeUt, "Paulo"); break;
			case 28: strcpy(nomeUt, "Mariana"); break;
			case 29: strcpy(nomeUt, "Helena"); break;
			case 30: strcpy(nomeUt, "Ulisses"); break;
			default: strcpy(nomeUt, "UmQualquer"); break;
		}
		nUt=rand()%50000;
		// printf("\nNome: %s", vectNomes[i].nome);
		//getchar();
		sprintf(R->nome, "%s", vectNomes[i].nome);
		sprintf(R->utilizador, "UT%d", rand()%50000);
		// printf("\nR->utilizador: %s", R->utilizador);
		sprintf(R->password, "%s-%d", nomeUt, rand()%10000000);
		R->joia = 100.0f + i*1.0/100;
		R->data_registo.dia = rand() % 28+1;
		R->data_registo.mes = rand() % 12+1;
		R->data_registo.ano = 2017+i%5;
		sprintf(R->email, "email...%s-%d", nomeUt, i);
		sprintf(R->pagina_web_pessoal, "pagina web-%s-%d", nomeUt, i);
		R->telemovel = 930000000+rand()%1000000+1;
		R->numero_acessos = rand()%10000;
		R->data_ultimo_acesso.mes = rand() % 12+1;
		if(R->data_ultimo_acesso.mes==2)
			R->data_ultimo_acesso.dia = rand() % 28+1;
		else if(R->data_ultimo_acesso.mes==4 || R->data_ultimo_acesso.mes==6 ||
				R->data_ultimo_acesso.mes==9 || R->data_ultimo_acesso.mes==11)
			R->data_ultimo_acesso.dia = rand() % 30 + 1;
			else
				R->data_ultimo_acesso.dia = rand() % 31+1;
		R->data_ultimo_acesso.ano = 2010+i%12;
		fwrite(R, sizeof(REGISTO_UTILIZADORES), 1, F);
		free(R);
	}
	fclose(F);
	return 1;
}

// Função para mostrar o menu e aceitar a opção
int menu(void)
{
	int opcao;
	//system("cls") ou system("clear");
	printf("\n\n #------------------------------------------------------------#");
	printf("\n | (1) Ler de Ficheiro                                        |");
	printf("\n | (2) Copiar os dados originais para outro vector            |");
	printf("\n | (3) Listar utilizadores (vector original)                  |");
	printf("\n | (4) Listar utilizadores (vector copiado)                   |");
	printf("\n | (5) Gravar para XML os dados do vector                     |");
	printf("\n | (6) Converter os nomes dos utiliz. p/ maiúsc. (vect. cop.) |");
	printf("\n | (7) Listar os utiliz. que contêm no nome uma dada string   |");
	printf("\n | (8) Mostrar qual é o subnome dos nomes que é mais comum    |");
	printf("\n +------------------------------------------------------------+");
	printf("\n | (0) Sair                                                   |");
	printf("\n #------------------------------------------------------------#");

	do {
		printf("\nQual a sua opcao: ");
		scanf("%d", &opcao);
	} while (opcao < 0 || opcao > 8);
	return opcao;
}


// Ex. 1, opção 1 - Ler ficheiro
// Versão 1
/*
 Função: lerFicheiro
 Parâmetros: ed - ponteiro para a estrutura de dados onde vão ser carregados os dados;
			 nficheiro – nome do ficheiro a ler
 Descrição: Dado o nome do ficheiro (parâmetro nficheiro),
			a função vai ler para memória (para a estrutura apontada por ed) os dados do ficheiro,
			colocando também em nElem o número de registos lidos
 Retorno: 0 (se houver erro); 1 (caso não haja erro)
 */
//---------------------------------------
int lerFicheiro(EDADOS *ed, char *nficheiro)  // versão da aula
{
	//AvisoParaAluno;
	int N;
	FILE *f = fopen(nficheiro, "rb");
	if(!f){
		perror("Erro na abertura do ficheiro");
		return 0;
	}
	fseek(f, 0, SEEK_END); // mover o ponteiro do ficheiro para o fim
	// Calcular o número de registos (N) que se encontram no ficheiro
	N = (int) ftell(f) / sizeof(REGISTO_UTILIZADORES);
	ed->nElem = N;
	ed->dados = (REGISTO_UTILIZADORES *)malloc(ed->nElem * sizeof(REGISTO_UTILIZADORES));
	fseek(f, 0, SEEK_SET); // Mover o ponteiro do ficheiro para o início
	// ler todos os dados do ficheiro para o bloco de memória apontado por ed->dados;
	fread(ed->dados, sizeof(REGISTO_UTILIZADORES), ed->nElem, f);
	// Se fosse pretendido mostar os registos lidos, um a um, ter-se-ia:
	//    REGISTO_UTILIZADORES *pinicio = ed->dados;
	/*for(int i=0; i<ed->nElem; i++)
	{
		printf("Registo leitura %d: data: %d/%d/%d\n", i+1, ed->dados[i].data_registo.dia, ed->dados[i].data_registo.mes, ed->dados[i].data_registo.ano);
		printf("Nome: %s\n", ed->dados[i].nome);
	}*/
	//ed->dados = pinicio;
	fclose(f);
	return 1;
}

// Função criarEDados que vai criar a estrutura ED
// (do tipo EDADOS) e inicializá-la
//---------------------------------------
EDADOS *criarEDados(void)
{
	EDADOS *ED = (EDADOS *)malloc(sizeof(EDADOS));
	ED->nElem = 0;
	ED->dados = NULL;
	return ED;
}

// Função correspondente ao ex. 2, opção 2 do menu (duplicaDados) que vai usar a função criarEDados
// para criar a nova estrutura para guardar a cópia da estrutura de dados original
// Vai copiar os dados do vector origem (com os dados lidos do ficheiro)
// para um novo vector, usado depois para ser ordenado
//---------------------------------------
EDADOS * duplicaDados(EDADOS *edOrig)
{
	int i=0;
	if ((!edOrig) || (!edOrig->dados)) return NULL;// Retorna NULL, significando que não há dados.
	
	EDADOS * edDest;
	edDest = criarEDados();
	edDest->dados = (REGISTO_UTILIZADORES *)malloc(edOrig->nElem * sizeof(REGISTO_UTILIZADORES));
	edDest->nElem=edOrig->nElem;
	for(i=0; i<edOrig->nElem; i++) // copiar o vector original para o vector destino (a ordenar)
	{
		edDest->dados[i] = edOrig->dados[i];
	}
	return edDest;
}

// Função utilizada para libertar toda a memória alocada, relativa a uma det. estrutura
// Função: libertarMemoria
// Parâmetro: ed - ponteiro para a estrutura de dados a ser libertada
// Retorno: 0 (se houver erro); 1 (caso não haja erro).
//---------------------------------------
int libertarMemoria(EDADOS *ed)
{
	// Colocar aqui o código correspondente à função requerida
	if(!ed)
		return 0; // Retorna 0, significando que não há memória alocada
	if(ed->dados !=NULL) // há dados no vector
		free(ed->dados); // liberta o bloco de memória do vector
	free(ed); // liberta a memória alocada para ed
	return 1;  // retorna 1, significando que a operação foi bem sucedida
}

// Ex. 3 e 4, opção 3 e 4.
// Nas opções 3 e 4 é invocada a função listarDados.
// Esta função vai percorrer o vector de utilizadores
// que está incluido no dado especificado pelo ponteiro ed e,
// para cada um dos elementos, vai invocar a função mostarRegisto
// (apresentada já a seguir, que apresenta no ecrã o utilizador
// correspondente ao ponteiro que lhe é passado como parâmetro.


// Esta função vai mostrar no ecran a informação correspondente
// a cada registo de utilizador dados é o ponteiro para o registo a mostrar.
void mostrarRegisto(REGISTO_UTILIZADORES *dados)
{
	// Dica: Esta função não é mais do que uma sucessão de linhas
	// com printf(...), cada uma para mostar um atributo do utilizador
	// Sugere-se que a 1.ª linha seja uma linha com "----" para separar
	// a informação relativa a cada utilizador que já se inclui a seguir.
	
	printf("-------------------------------------------------------\n");
	printf("Utilizador = %s\n", dados->utilizador);
	printf("Nome = %s\n", dados->nome);
	printf("Password = %s\n", dados->password);
	printf("Jóia = %.2f€\n", dados->joia);
	printf("Data de Registo = %d/%d/%d\n", dados->data_registo.dia, dados->data_registo.mes, dados->data_registo.ano);
	printf("e-Mail = %s\n", dados->email);
	printf("Página Web Pessoal = %s\n", dados->pagina_web_pessoal);
	printf("Telemóvel = %d\n", dados->telemovel);
	printf("Número de Acessos = %d\n", dados->numero_acessos);
	printf("Data de Último Acesso = %d/%d/%d\n", dados->data_ultimo_acesso.dia, dados->data_ultimo_acesso.mes, dados->data_ultimo_acesso.ano);
}

/*
 Funcao: listarDados
 Parâmetros: ed - Dado que contém a informação do número de utilizadores
 existentes e também outra necessária ao acesso da informação respectiva;
 nRegAMostrar - número de registos que se pretende sejam mostrados
 (iniciando no primeiro (0));
 Descrição: Percorre os utilizadores (iniciando pelo 1.º) e,
 para cada utilizador, vai invocar a função mostarRegisto que
 vai apresentar no monitos a informação relativa ao utilizador.
 Retorno: 0 (se houver erro); 1 (caso não haja erro).
 */

int listarDados(EDADOS *ed, int nRegAMostrar)
{
	int i;
	if ((!ed) || (!ed->dados)) return 0;  // Retorna 0, significando que não há dados.
	
	if (nRegAMostrar > ed->nElem)
		nRegAMostrar=ed->nElem;
	
	printf("\n-------------------------------------------------------");
	printf("\nOpção 3 ou 4 - Número de utilizadores a listar: %d", ed->nElem);
	
	for (i = 0; i < nRegAMostrar; i++)
	{
		mostrarRegisto(&(ed->dados[i])); // &((ed->dados[i]) é o endereço do registo a mostrar
	}
	return 1;
}

//
//-------------- Funcs solicitadas "mesmo" na ficha "Extensão"------------
//
// Funções utilizadas para responder ao exercício 1, opção 5 do menu;
//
// A função infra (data_para_xml) é uma função auxiliar da função gravaUser_xml, que gera
// e grava as linhas do ficheiro, para cada membro tipo DATA da struct USER.
//
void data_para_xml(FILE *file, DATA data, char *tag)
{
	printf("\nFuncionalidade auxiliar da opção 5 (questão 1) ainda não implementada!");
	printf("\nDigite <Enter> para continuar...");
	getchar();
	
	// Colocar, infra, o código correspondente à execução do indicado nos
	// comentários desta função

	
	
	
	
}

// Função que gera e grava as linhas do ficheiro, para o utilizador especificado em X.
// Invoca a função dataParaXml para criar as linhas do ficheiro,
// para cada membro tipo DATA da struct USER.
void gravarUSER_XML(FILE *F, USER *X)
{
	printf("\nFuncionalidade auxiliar da opção 5 (exercício 1) ainda não implementada!");
	printf("\nDigite <Enter> para continuar...");
	getchar();

	// Colocar, infra, o código correspondente à execução do indicado nos
	// comentários desta função

}

// Função que gera e grava as linhas do ficheiro, para o utilizador especificado em X.
	// Invoca a função dataParaXml para criar as linhas do ficheiro,.
	// para cada membro tipo DATA da struct USER.
int gravarXML(EDADOS *ed, char *ficheiro)
{
	if (!ed) return INSUCESSO;
	if (!ed->dados) return INSUCESSO;
	
	/*
	 Dicas:
	 Procurar informação quanto conversão de um ficheiro em formato XML
	 1. Primeiro, convém perceber o que é um fich. XML e a diferença relativamente ao html;
	 2. Devem depois quais são as tags importantes e onde devem ser usadas;
	 3. Talvez seja de procurar um exemplo de aplicação a um caso real e perceber como
		é transformada cada componente de informação necessária para que
	    no fich. XML se possa saber qual a infdormação que está em cada bloco e, assim,
		se possa efectuar a  operação inversa, ou seja ler o fich. XML e recuperar a
		informação lá guardada (neste caso, poder carregar o vector, usando um fich. XML.
	 */
	
	
	printf("\nFuncionalidade da opção 5 (exercício 1) ainda não implementada!");
	printf("\nDigite <Enter> para continuar...");
	getchar();

	// Colocar, infra, o código correspondente à execução do indicado nos
	// comentários desta função
	
	
	return INSUCESSO;
}

// Função que responde ao exercício 2 da ficha, opção 6 do menu.
// Invoca a função converterMaiusculas para converter o nome
// de cada utilizador para letras maiúsculas.
int toLetrasGrandes(EDADOS *ed)
{
	if (!ed) return 0;
	if (!ed->dados) return 0;
	for (int i = 0; i < ed->nElem; i++)
		converterPMaiuscula(ed->dados[i].nome);
	return 1;
}

// Função que responde ao exercício 3 da ficha, opção 7 do menu
// (Listar os utiliz. que contêm no nome um dado subnome, devendo ser "case insensitive").
// A Função vai pesquisar o vector com os utilizadores e mostar aqueles cujo nome
// contêm um subnome especificado no parâmetro subnome, sendo a operação "case insensitive".
// Calcula também o número total de utilizadores que satisfazem
// a condição e retorna o seu valor (variável cont).
int listarUsersContains(EDADOS *ed, char *subNome)
{
	if (!ed) return -1;
	if (!ed->dados) return -1;
	
	printf("\nFuncionalidade da opção 7 (exercício 3) ainda não implementada!");
	printf("\nDigite <Enter> para continuar...");
	getchar();

	// Colocar, infra, o código correspondente à execução do indicado nos
	// comentários desta função
	int cont = 0;
	
	

	return cont;
}

// Função que responde ao exercício 5 da ficha, opção 8 do menu -
// Mostrar qual é o subnome dos nomes que é mais comum.
// A Função vai pesquisar o vector com os utilizadores e encontar o subnome
// mais comum, ou seja, vai percorrer todos os nomes e para cada subnome
// encontrado, vai calcular o número de vezes que cada um ocorre em todos
// os nomes dos utilizadores existentes no vector.
// Mostra a tabela com os subnomes e número de ocorrências de cada um.
char *nomeMaisComum(EDADOS *ed)
{
	if (!ed) return NULL;
	if (!ed->dados) return NULL;
	int NRegistos = 0;
	Registo *Tabela = NULL;
	char *copiaNome = (char *)malloc(MAX_NOME * sizeof(char));
	for (int i = 0; i < ed->nElem; i++)
	{
		strcpy(copiaNome, ed->dados[i].nome);
		// Há que partir a string copiaNome pelo espaço
		char *token = strtok(copiaNome, " ");
		// loop through the string to extract all other tokens
		while( token != NULL )
		{
			// Para debug, mostar cada token
			// printf( "[%s]\n", token ); //printing each token
			
			// Agora vai ter de se actualizar o contador deste token, ou seja,
			// há que pesquisar este token na estrutura auxiliar Tabela
			// e colocar em posicaoRegisto o índice onde está o token,
			// se o token for encontrado em Tabela.
			int posicaoRegisto = -1;
			for (int j = 0;j < NRegistos; j++)
				//if (stricmp(Tabela[j].str, token) == 0)
				if (strcmp(Tabela[j].str, token) == 0)
				{
					posicaoRegisto = j;
					break;
				}
			// Se o token não for encontrado em Tabela (posicaoRegisto = -1)
			// isso quer dizer que não foi encontrado o subnome e, assim,
			// vai ter de ser inserido na tabela!
			// Mas, ATENÇÃO, antes há que realocar a Tabela!
			if (posicaoRegisto == -1)
			{
				Tabela = (Registo *)realloc(Tabela, (NRegistos + 1) * sizeof(Registo));
				Tabela[NRegistos].cont = 1;
				Tabela[NRegistos].str = (char *)malloc((strlen(token) + 1)*sizeof(char));
				strcpy(Tabela[NRegistos].str, token);
				NRegistos++;
			}
			else
				// o token foi encontrado -> há que incrementar o número de ocorrências
				Tabela[posicaoRegisto].cont++;
			//printf("token = [%s] posicao_registo = %d NRegistos = %d\n",
			//       token, posicao_registo, NRegistos);
			//system("pause");
			token = strtok(NULL, " ");
		}
	}
	free (copiaNome);
	printf("Fim do While\n");
	// Para Debug; Mostrar a tabela
	// for (int i = 0; i < NRegistos; i++)
	//	printf("[%s] : Cont = %d\n", Tabela[i].str, Tabela[i].cont);
	
	// determina a posição da tabela onde ocorre o subnome com mais ocorrências
	int posMaximo = 0;
	for (int i = 0; i < NRegistos; i++)
		if (Tabela[i].cont > Tabela[posMaximo].cont)
			posMaximo = i;

	char *Retorno = (char *)malloc(strlen((Tabela[posMaximo].str) + 1)*sizeof(char));
	strcpy(Retorno, Tabela[posMaximo].str);
	for (int i = 0; i < NRegistos; i++)
		free(Tabela[i].str);
	free(Tabela);
	
	return Retorno;
}
