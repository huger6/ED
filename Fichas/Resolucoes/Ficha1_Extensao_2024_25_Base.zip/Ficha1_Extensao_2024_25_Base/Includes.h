//
//  Includes.h
//  Ficha1_Extensao_2024_25_Base
//
//  Created by Jorge Loureiro on 06/03/2025.
//

#ifndef Includes_h
#define Includes_h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

#endif /* Includes_h */

